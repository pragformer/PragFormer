for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register const IndexPacket * restrict indexes;
  register const IndexPacket * restrict reconstruct_indexes;
  register const PixelPacket * restrict p;
  register const PixelPacket * restrict q;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  q = GetCacheViewVirtualPixels(reconstruct_view, 0, y, reconstruct_image->columns, 1, exception);
  if ((p == ((const PixelPacket *) 0)) || (q == ((const PixelPacket *) 0)))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewVirtualIndexQueue(image_view);
  reconstruct_indexes = GetCacheViewVirtualIndexQueue(reconstruct_view);
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    distortion += ((area * (((double) 1.0) / ((double) QuantumRange))) * (GetPixelRed(p) - image_statistics[RedChannel].mean)) * (GetPixelRed(q) - reconstruct_statistics[RedChannel].mean);
    distortion += ((area * (((double) 1.0) / ((double) QuantumRange))) * (GetPixelGreen(p) - image_statistics[GreenChannel].mean)) * (GetPixelGreen(q) - reconstruct_statistics[GreenChannel].mean);
    distortion += ((area * (((double) 1.0) / ((double) QuantumRange))) * (GetPixelBlue(p) - image_statistics[BlueChannel].mean)) * (q->blue - reconstruct_statistics[BlueChannel].mean);
    if (image->matte != MagickFalse)
      distortion += ((area * (((double) 1.0) / ((double) QuantumRange))) * (GetPixelOpacity(p) - image_statistics[OpacityChannel].mean)) * (GetPixelOpacity(q) - reconstruct_statistics[OpacityChannel].mean);

    if ((image->colorspace == CMYKColorspace) && (reconstruct_image->colorspace == CMYKColorspace))
      distortion += ((area * (((double) 1.0) / ((double) QuantumRange))) * (GetPixelIndex(indexes + x) - image_statistics[BlackChannel].mean)) * (GetPixelIndex(reconstruct_indexes + x) - reconstruct_statistics[BlackChannel].mean);

    p++;
    q++;
  }

}
