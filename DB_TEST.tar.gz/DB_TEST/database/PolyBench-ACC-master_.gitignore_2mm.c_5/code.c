for (i = 0; i < ni; i++)
  for (j = 0; j < nl; j++)
  D[i][j] = (((double) i) * (j + 2)) / nk;

