for (j = 0; j < POLYBENCH_LOOP_BOUND(4000, m); j++)
{
  stddev[j] = 0.0;
  for (i = 0; i < POLYBENCH_LOOP_BOUND(4000, n); i++)
    stddev[j] += (data[i][j] - mean[j]) * (data[i][j] - mean[j]);

  stddev[j] /= float_n;
  stddev[j] = sqrt(stddev[j]);
  stddev[j] = (stddev[j] <= eps) ? (1.0) : (stddev[j]);
}
