for (i = 0; i < ((ssize_t) ((2 * width) - 1)); i++)
{
  if (projection[i] > max_projection)
  {
    skew = (i - ((ssize_t) width)) + 1;
    max_projection = projection[i];
  }

}
