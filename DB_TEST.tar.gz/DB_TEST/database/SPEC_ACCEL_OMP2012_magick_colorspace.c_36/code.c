for (; i <= ((ssize_t) MaxMap); i++)
{
  x_map[i].x = 0.2201118963486454 * ((1.099f * ((MagickRealType) i)) - 0.099f);
  y_map[i].x = 0.4321260306242638 * ((1.099f * ((MagickRealType) i)) - 0.099f);
  z_map[i].x = 0.08392226148409894 * ((1.099f * ((MagickRealType) i)) - 0.099f);
  x_map[i].y = (-0.1348122097479598) * ((1.099f * ((MagickRealType) i)) - 0.099f);
  y_map[i].y = (-0.2646647729834528) * ((1.099f * ((MagickRealType) i)) - 0.099f);
  z_map[i].y = 0.3994769827314126 * ((1.099f * ((MagickRealType) i)) - 0.099f);
  x_map[i].z = 0.3848476530332144 * ((1.099f * ((MagickRealType) i)) - 0.099f);
  y_map[i].z = (-0.3222618720834477) * ((1.099f * ((MagickRealType) i)) - 0.099f);
  z_map[i].z = (-0.06258578094976668) * ((1.099f * ((MagickRealType) i)) - 0.099f);
}
