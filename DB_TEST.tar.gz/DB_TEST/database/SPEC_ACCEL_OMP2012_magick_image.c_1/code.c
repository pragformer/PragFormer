for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register IndexPacket * restrict indexes;
  register PixelPacket * restrict q;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  q = QueueCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    SetPixelPacket(image, background, q, indexes + x);
    q++;
  }

  if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
    status = MagickFalse;

}

inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}

