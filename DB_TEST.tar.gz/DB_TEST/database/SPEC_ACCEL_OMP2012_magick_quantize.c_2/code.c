for (y = 0; y < ((ssize_t) image->rows); y++)
{
  CubeInfo cube;
  register IndexPacket * restrict indexes;
  register PixelPacket * restrict q;
  register ssize_t x;
  ssize_t count;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  cube = *cube_info;
  for (x = 0; x < ((ssize_t) image->columns); x += count)
  {
    RealPixelPacket pixel;
    register const NodeInfo *node_info;
    register ssize_t i;
    size_t id;
    size_t index;
    for (count = 1; (x + count) < ((ssize_t) image->columns); count++)
      if (IsSameColor(image, q, q + count) == MagickFalse)
      break;


    AssociateAlphaPixel(&cube, q, &pixel);
    node_info = cube.root;
    for (index = 8 - 1; ((ssize_t) index) > 0; index--)
    {
      id = ColorToNodeId(&cube, &pixel, index);
      if (node_info->child[id] == ((NodeInfo *) 0))
        break;

      node_info = node_info->child[id];
    }

    cube.target = pixel;
    cube.distance = (MagickRealType) (((4.0 * (QuantumRange + 1.0)) * (QuantumRange + 1.0)) + 1.0);
    ClosestColor(image, &cube, node_info->parent);
    index = cube.color_number;
    for (i = 0; i < ((ssize_t) count); i++)
    {
      if (image->storage_class == PseudoClass)
        SetPixelIndex((indexes + x) + i, index);

      if (cube.quantize_info->measure_error == MagickFalse)
      {
        SetPixelRGB(q, image->colormap + index);
        if (cube.associate_alpha != MagickFalse)
          SetPixelOpacity(q, image->colormap[index].opacity);

      }

      q++;
    }

  }

  if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_AssignImageColors)
    proceed = SetImageProgress(image, "Assign/Image", (MagickOffsetType) y, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static MagickBooleanType IsSameColor(const Image *image, const PixelPacket *p, const PixelPacket *q)
{
  if (((GetPixelRed(p) != GetPixelRed(q)) || (GetPixelGreen(p) != GetPixelGreen(q))) || (GetPixelBlue(p) != GetPixelBlue(q)))
    return MagickFalse;

  if ((image->matte != MagickFalse) && (GetPixelOpacity(p) != GetPixelOpacity(q)))
    return MagickFalse;

  return MagickTrue;
}


inline static void AssociateAlphaPixel(const CubeInfo *cube_info, const PixelPacket *pixel, RealPixelPacket *alpha_pixel)
{
  MagickRealType alpha;
  if ((cube_info->associate_alpha == MagickFalse) || (pixel->opacity == ((Quantum) 0UL)))
  {
    alpha_pixel->red = (MagickRealType) GetPixelRed(pixel);
    alpha_pixel->green = (MagickRealType) GetPixelGreen(pixel);
    alpha_pixel->blue = (MagickRealType) GetPixelBlue(pixel);
    alpha_pixel->opacity = (MagickRealType) GetPixelOpacity(pixel);
    return;
  }

  alpha = (MagickRealType) ((((double) 1.0) / ((double) QuantumRange)) * (QuantumRange - GetPixelOpacity(pixel)));
  alpha_pixel->red = alpha * GetPixelRed(pixel);
  alpha_pixel->green = alpha * GetPixelGreen(pixel);
  alpha_pixel->blue = alpha * GetPixelBlue(pixel);
  alpha_pixel->opacity = (MagickRealType) GetPixelOpacity(pixel);
}


inline static size_t ColorToNodeId(const CubeInfo *cube_info, const RealPixelPacket *pixel, size_t index)
{
  size_t id;
  id = (size_t) ((((ScaleQuantumToChar(ClampToUnsignedQuantum(GetPixelRed(pixel))) >> index) & 0x01) | (((ScaleQuantumToChar(ClampToUnsignedQuantum(GetPixelGreen(pixel))) >> index) & 0x01) << 1)) | (((ScaleQuantumToChar(ClampToUnsignedQuantum(GetPixelBlue(pixel))) >> index) & 0x01) << 2));
  if (cube_info->associate_alpha != MagickFalse)
    id |= ((ScaleQuantumToChar(ClampToUnsignedQuantum(GetPixelOpacity(pixel))) >> index) & 0x1) << 3;

  return id;
}


static void ClosestColor(const Image *image, CubeInfo *cube_info, const NodeInfo *node_info)
{
  register ssize_t i;
  size_t number_children;
  number_children = (cube_info->associate_alpha == MagickFalse) ? (8UL) : (16UL);
  for (i = 0; i < ((ssize_t) number_children); i++)
    if (node_info->child[i] != ((NodeInfo *) 0))
    ClosestColor(image, cube_info, node_info->child[i]);


  if (node_info->number_unique != 0)
  {
    MagickRealType pixel;
    register MagickRealType alpha;
    register MagickRealType beta;
    register MagickRealType distance;
    register PixelPacket * restrict p;
    register RealPixelPacket * restrict q;
    p = image->colormap + node_info->color_number;
    q = &cube_info->target;
    alpha = 1.0;
    beta = 1.0;
    if (cube_info->associate_alpha != MagickFalse)
    {
      alpha = (MagickRealType) ((((double) 1.0) / ((double) QuantumRange)) * GetPixelAlpha(p));
      beta = (MagickRealType) ((((double) 1.0) / ((double) QuantumRange)) * GetPixelAlpha(q));
    }

    pixel = (alpha * GetPixelRed(p)) - (beta * GetPixelRed(q));
    distance = pixel * pixel;
    if (distance <= cube_info->distance)
    {
      pixel = (alpha * GetPixelGreen(p)) - (beta * GetPixelGreen(q));
      distance += pixel * pixel;
      if (distance <= cube_info->distance)
      {
        pixel = (alpha * GetPixelBlue(p)) - (beta * GetPixelBlue(q));
        distance += pixel * pixel;
        if (distance <= cube_info->distance)
        {
          pixel = alpha - beta;
          distance += pixel * pixel;
          if (distance <= cube_info->distance)
          {
            cube_info->distance = distance;
            cube_info->color_number = node_info->color_number;
          }

        }

      }

    }

  }

}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

