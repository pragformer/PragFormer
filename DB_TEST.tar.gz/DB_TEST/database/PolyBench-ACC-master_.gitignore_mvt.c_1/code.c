for (i = 0; i < POLYBENCH_LOOP_BOUND(4000, n); i++)
  for (j = 0; j < POLYBENCH_LOOP_BOUND(4000, n); j++)
  x2[i] = x2[i] + (A[j][i] * y_2[j]);

