for (i = 0; i < prm->Natom; i++)
{
  xi = x[dim * i];
  yi = x[(dim * i) + 1];
  zi = x[(dim * i) + 2];
  if (dim == 4)
  {
    wi = x[(dim * i) + 3];
  }

  ri = rborn[i] - 0.09;
  ri1i = 1. / ri;
  sumi = 0.0;
  for (k = 0; k < (lpears[i] + upears[i]); k++)
  {
    if (pearlist[i] == NULL)
    {
      fprintf(nabout, "NULL pair list entry in egb loop 1, taskid = %d\n", mytaskid);
      fflush(nabout);
    }

    j = pearlist[i][k];
    xij = xi - x[dim * j];
    yij = yi - x[(dim * j) + 1];
    zij = zi - x[(dim * j) + 2];
    r2 = ((xij * xij) + (yij * yij)) + (zij * zij);
    if (dim == 4)
    {
      wij = wi - x[(dim * j) + 3];
      r2 += wij * wij;
    }

    if (r2 > rgbmaxpsmax2)
      continue;

    dij1i = 1.0 / sqrt(r2);
    dij = r2 * dij1i;
    sj = fs[j] * (rborn[j] - 0.09);
    sj2 = sj * sj;
    if (dij > (rgbmax + sj))
      continue;

    if (dij > (rgbmax - sj))
    {
      uij = 1. / (dij - sj);
      sumi -= (0.125 * dij1i) * (((1.0 + ((2.0 * dij) * uij)) + (rgbmax2i * ((r2 - ((4.0 * rgbmax) * dij)) - sj2))) + (2.0 * log((dij - sj) * rgbmax1i)));
    }
    else
      if (dij > (4.0 * sj))
    {
      dij2i = dij1i * dij1i;
      tmpsd = sj2 * dij2i;
      dumbo = 0.33333333333333333333 + (tmpsd * (0.4 + (tmpsd * (0.42857142857142857143 + (tmpsd * (0.44444444444444444444 + (tmpsd * 0.45454545454545454545)))))));
      sumi -= ((sj * tmpsd) * dij2i) * dumbo;
    }
    else
      if (dij > (ri + sj))
    {
      sumi -= 0.5 * ((sj / (r2 - sj2)) + ((0.5 * dij1i) * log((dij - sj) / (dij + sj))));
    }
    else
      if (dij > fabs(ri - sj))
    {
      theta = ((0.5 * ri1i) * dij1i) * ((r2 + (ri * ri)) - sj2);
      uij = 1. / (dij + sj);
      sumi -= 0.25 * (((ri1i * (2. - theta)) - uij) + (dij1i * log(ri * uij)));
    }
    else
      if (ri < sj)
    {
      sumi -= 0.5 * (((sj / (r2 - sj2)) + (2. * ri1i)) + ((0.5 * dij1i) * log((sj - dij) / (sj + dij))));
    }





  }

  if (gb == 1)
  {
    reff[i] = 1.0 / (ri1i + sumi);
    if (reff[i] < 0.0)
      reff[i] = 30.0;

  }
  else
  {
    psi[i] = (-ri) * sumi;
    reff[i] = 1.0 / (ri1i - (tanh(((gbalpha - (gbbeta * psi[i])) + ((gbgamma * psi[i]) * psi[i])) * psi[i]) / rborn[i]));
  }

  if (gb_debug)
    fprintf(nabout, "%d\t%15.7f\t%15.7f\n", i + 1, rborn[i], reff[i]);

}
