for (q = name + (strlen(name) - 1); q > name; q--)
{
  if ((*q) == ')')
    break;

  if ((*q) == '.')
  {
    *q = '\0';
    break;
  }

}
