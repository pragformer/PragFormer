for (; n >= 0; n--)
  graphic_context[n] = DestroyDrawInfo(graphic_context[n]);

DrawInfo *DestroyDrawInfo(DrawInfo *draw_info)
{
  if (draw_info->debug != MagickFalse)
    (void) LogMagickEvent(TraceEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 817, "...");

  assert(draw_info != ((DrawInfo *) 0));
  assert(draw_info->signature == 0xabacadabUL);
  if (draw_info->primitive != ((char *) 0))
    draw_info->primitive = DestroyString(draw_info->primitive);

  if (draw_info->text != ((char *) 0))
    draw_info->text = DestroyString(draw_info->text);

  if (draw_info->geometry != ((char *) 0))
    draw_info->geometry = DestroyString(draw_info->geometry);

  if (draw_info->tile != ((Image *) 0))
    draw_info->tile = DestroyImage(draw_info->tile);

  if (draw_info->fill_pattern != ((Image *) 0))
    draw_info->fill_pattern = DestroyImage(draw_info->fill_pattern);

  if (draw_info->stroke_pattern != ((Image *) 0))
    draw_info->stroke_pattern = DestroyImage(draw_info->stroke_pattern);

  if (draw_info->font != ((char *) 0))
    draw_info->font = DestroyString(draw_info->font);

  if (draw_info->metrics != ((char *) 0))
    draw_info->metrics = DestroyString(draw_info->metrics);

  if (draw_info->family != ((char *) 0))
    draw_info->family = DestroyString(draw_info->family);

  if (draw_info->encoding != ((char *) 0))
    draw_info->encoding = DestroyString(draw_info->encoding);

  if (draw_info->density != ((char *) 0))
    draw_info->density = DestroyString(draw_info->density);

  if (draw_info->server_name != ((char *) 0))
    draw_info->server_name = (char *) RelinquishMagickMemory(draw_info->server_name);

  if (draw_info->dash_pattern != ((double *) 0))
    draw_info->dash_pattern = (double *) RelinquishMagickMemory(draw_info->dash_pattern);

  if (draw_info->gradient.stops != ((StopInfo *) 0))
    draw_info->gradient.stops = (StopInfo *) RelinquishMagickMemory(draw_info->gradient.stops);

  if (draw_info->clip_mask != ((char *) 0))
    draw_info->clip_mask = DestroyString(draw_info->clip_mask);

  draw_info->signature = ~0xabacadabUL;
  draw_info = (DrawInfo *) RelinquishMagickMemory(draw_info);
  return draw_info;
}

