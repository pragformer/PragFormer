for (i = 0; i < n; i++)
{
  A[i] = (((double) i) + 2) / n;
  B[i] = (((double) i) + 3) / n;
}
