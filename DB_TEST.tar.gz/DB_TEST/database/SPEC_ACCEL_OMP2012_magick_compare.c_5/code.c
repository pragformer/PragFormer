for (i = 0; i <= ((ssize_t) CompositeChannels); i++)
  distortion[i] /= ((double) image->columns) * image->rows;
