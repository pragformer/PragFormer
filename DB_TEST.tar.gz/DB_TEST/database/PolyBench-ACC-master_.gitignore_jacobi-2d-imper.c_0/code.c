for (i = 1; i < (POLYBENCH_LOOP_BOUND(1000, n) - 1); i++)
  for (j = 1; j < (POLYBENCH_LOOP_BOUND(1000, n) - 1); j++)
  B[i][j] = 0.2 * ((((A[i][j] + A[i][j - 1]) + A[i][1 + j]) + A[1 + i][j]) + A[i - 1][j]);

