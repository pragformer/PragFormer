for (i = 0; i < ((ssize_t) number_threads); i++)
{
  pixels[i] = (RealPixelPacket *) AcquireQuantumMemory(count, 2 * (sizeof(*(*pixels))));
  if (pixels[i] == ((RealPixelPacket *) 0))
    return DestroyPixelThreadSet(pixels);

}

static RealPixelPacket **DestroyPixelThreadSet(RealPixelPacket **pixels)
{
  register ssize_t i;
  assert(pixels != ((RealPixelPacket **) 0));
  for (i = 0; i < ((ssize_t) GetOpenMPMaximumThreads()); i++)
    if (pixels[i] != ((RealPixelPacket *) 0))
    pixels[i] = (RealPixelPacket *) RelinquishMagickMemory(pixels[i]);


  pixels = (RealPixelPacket **) RelinquishMagickMemory(pixels);
  return pixels;
}

