for (i = 0; i < POLYBENCH_LOOP_BOUND(4000, n); i++)
{
  tmp[i] = 0;
  y[i] = 0;
  for (j = 0; j < POLYBENCH_LOOP_BOUND(4000, n); j++)
  {
    tmp[i] = (A[i][j] * x[j]) + tmp[i];
    y[i] = (B[i][j] * x[j]) + y[i];
  }

  y[i] = (alpha * tmp[i]) + (beta * y[i]);
}
