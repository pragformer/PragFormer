for (i = 0; i < 4; i++)
{
  extent[i].x += x_shear * extent[i].y;
  extent[i].y += y_shear * extent[i].x;
  if (rotate != MagickFalse)
    extent[i].x += x_shear * extent[i].y;

  extent[i].x += ((double) (*image)->columns) / 2.0;
  extent[i].y += ((double) (*image)->rows) / 2.0;
}
