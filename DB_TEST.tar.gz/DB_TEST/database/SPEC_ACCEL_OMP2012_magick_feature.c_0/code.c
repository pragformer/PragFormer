for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register const IndexPacket * restrict indexes;
  register const PixelPacket * restrict p;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  if (p == ((const PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewVirtualIndexQueue(image_view);
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    grays[ScaleQuantumToMap(GetPixelRed(p))].red = ScaleQuantumToMap(GetPixelRed(p));
    grays[ScaleQuantumToMap(GetPixelGreen(p))].green = ScaleQuantumToMap(GetPixelGreen(p));
    grays[ScaleQuantumToMap(GetPixelBlue(p))].blue = ScaleQuantumToMap(GetPixelBlue(p));
    if (image->colorspace == CMYKColorspace)
      grays[ScaleQuantumToMap(GetPixelIndex(indexes + x))].index = ScaleQuantumToMap(GetPixelIndex(indexes + x));

    if (image->matte != MagickFalse)
      grays[ScaleQuantumToMap(GetPixelOpacity(p))].opacity = ScaleQuantumToMap(GetPixelOpacity(p));

    p++;
  }

}
