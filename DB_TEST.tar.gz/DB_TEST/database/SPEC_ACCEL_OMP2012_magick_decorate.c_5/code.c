for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register IndexPacket * restrict frame_indexes;
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  q = QueueCacheViewAuthenticPixels(frame_view, 0, frame_info->y + y, frame_image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  frame_indexes = GetCacheViewAuthenticIndexQueue(frame_view);
  for (x = 0; x < ((ssize_t) frame_info->outer_bevel); x++)
  {
    SetPixelPacket(frame_image, &highlight, q, frame_indexes);
    q++;
    frame_indexes++;
  }

  for (x = 0; x < ((ssize_t) (frame_info->x - bevel_width)); x++)
  {
    SetPixelPacket(frame_image, &matte, q, frame_indexes);
    q++;
    frame_indexes++;
  }

  for (x = 0; x < ((ssize_t) frame_info->inner_bevel); x++)
  {
    SetPixelPacket(frame_image, &shadow, q, frame_indexes);
    q++;
    frame_indexes++;
  }

  if ((image->compose != CopyCompositeOp) && ((image->compose != OverCompositeOp) || (image->matte != MagickFalse)))
    for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    SetPixelPacket(frame_image, &interior, q, frame_indexes);
    q++;
    frame_indexes++;
  }

  else
  {
    register const IndexPacket *indexes;
    register const PixelPacket *p;
    p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
    if (p == ((const PixelPacket *) 0))
    {
      status = MagickFalse;
      continue;
    }

    indexes = GetCacheViewVirtualIndexQueue(image_view);
    (void) CopyMagickMemory(q, p, image->columns * (sizeof(*p)));
    if ((image->colorspace == CMYKColorspace) && (frame_image->colorspace == CMYKColorspace))
    {
      (void) CopyMagickMemory(frame_indexes, indexes, image->columns * (sizeof(*indexes)));
      frame_indexes += image->columns;
    }

    q += image->columns;
  }

  for (x = 0; x < ((ssize_t) frame_info->inner_bevel); x++)
  {
    SetPixelPacket(frame_image, &highlight, q, frame_indexes);
    q++;
    frame_indexes++;
  }

  width = ((frame_info->width - frame_info->x) - image->columns) - bevel_width;
  for (x = 0; x < ((ssize_t) width); x++)
  {
    SetPixelPacket(frame_image, &matte, q, frame_indexes);
    q++;
    frame_indexes++;
  }

  for (x = 0; x < ((ssize_t) frame_info->outer_bevel); x++)
  {
    SetPixelPacket(frame_image, &shadow, q, frame_indexes);
    q++;
    frame_indexes++;
  }

  if (SyncCacheViewAuthenticPixels(frame_view, exception) == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_FrameImage)
    proceed = SetImageProgress(image, "Frame/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

