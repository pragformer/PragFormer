for (i = 0; i < 4; i++)
{
  register ssize_t y;
  for (y = 0; y < ((ssize_t) number_grays); y++)
  {
    register ssize_t x;
    for (x = 0; x < ((ssize_t) number_grays); x++)
    {
      channel_features[RedChannel].angular_second_moment[i] += cooccurrence[x][y].direction[i].red * cooccurrence[x][y].direction[i].red;
      channel_features[GreenChannel].angular_second_moment[i] += cooccurrence[x][y].direction[i].green * cooccurrence[x][y].direction[i].green;
      channel_features[BlueChannel].angular_second_moment[i] += cooccurrence[x][y].direction[i].blue * cooccurrence[x][y].direction[i].blue;
      if (image->colorspace == CMYKColorspace)
        channel_features[BlackChannel].angular_second_moment[i] += cooccurrence[x][y].direction[i].index * cooccurrence[x][y].direction[i].index;

      if (image->matte != MagickFalse)
        channel_features[OpacityChannel].angular_second_moment[i] += cooccurrence[x][y].direction[i].opacity * cooccurrence[x][y].direction[i].opacity;

      sum[y].direction[i].red += cooccurrence[x][y].direction[i].red;
      sum[y].direction[i].green += cooccurrence[x][y].direction[i].green;
      sum[y].direction[i].blue += cooccurrence[x][y].direction[i].blue;
      if (image->colorspace == CMYKColorspace)
        sum[y].direction[i].index += cooccurrence[x][y].direction[i].index;

      if (image->matte != MagickFalse)
        sum[y].direction[i].opacity += cooccurrence[x][y].direction[i].opacity;

      correlation.direction[i].red += (x * y) * cooccurrence[x][y].direction[i].red;
      correlation.direction[i].green += (x * y) * cooccurrence[x][y].direction[i].green;
      correlation.direction[i].blue += (x * y) * cooccurrence[x][y].direction[i].blue;
      if (image->colorspace == CMYKColorspace)
        correlation.direction[i].index += (x * y) * cooccurrence[x][y].direction[i].index;

      if (image->matte != MagickFalse)
        correlation.direction[i].opacity += (x * y) * cooccurrence[x][y].direction[i].opacity;

      channel_features[RedChannel].inverse_difference_moment[i] += cooccurrence[x][y].direction[i].red / (((y - x) * (y - x)) + 1);
      channel_features[GreenChannel].inverse_difference_moment[i] += cooccurrence[x][y].direction[i].green / (((y - x) * (y - x)) + 1);
      channel_features[BlueChannel].inverse_difference_moment[i] += cooccurrence[x][y].direction[i].blue / (((y - x) * (y - x)) + 1);
      if (image->colorspace == CMYKColorspace)
        channel_features[IndexChannel].inverse_difference_moment[i] += cooccurrence[x][y].direction[i].index / (((y - x) * (y - x)) + 1);

      if (image->matte != MagickFalse)
        channel_features[OpacityChannel].inverse_difference_moment[i] += cooccurrence[x][y].direction[i].opacity / (((y - x) * (y - x)) + 1);

      density_xy[(y + x) + 2].direction[i].red += cooccurrence[x][y].direction[i].red;
      density_xy[(y + x) + 2].direction[i].green += cooccurrence[x][y].direction[i].green;
      density_xy[(y + x) + 2].direction[i].blue += cooccurrence[x][y].direction[i].blue;
      if (image->colorspace == CMYKColorspace)
        density_xy[(y + x) + 2].direction[i].index += cooccurrence[x][y].direction[i].index;

      if (image->matte != MagickFalse)
        density_xy[(y + x) + 2].direction[i].opacity += cooccurrence[x][y].direction[i].opacity;

      channel_features[RedChannel].entropy[i] -= cooccurrence[x][y].direction[i].red * log10(cooccurrence[x][y].direction[i].red + MagickEpsilon);
      channel_features[GreenChannel].entropy[i] -= cooccurrence[x][y].direction[i].green * log10(cooccurrence[x][y].direction[i].green + MagickEpsilon);
      channel_features[BlueChannel].entropy[i] -= cooccurrence[x][y].direction[i].blue * log10(cooccurrence[x][y].direction[i].blue + MagickEpsilon);
      if (image->colorspace == CMYKColorspace)
        channel_features[IndexChannel].entropy[i] -= cooccurrence[x][y].direction[i].index * log10(cooccurrence[x][y].direction[i].index + MagickEpsilon);

      if (image->matte != MagickFalse)
        channel_features[OpacityChannel].entropy[i] -= cooccurrence[x][y].direction[i].opacity * log10(cooccurrence[x][y].direction[i].opacity + MagickEpsilon);

      density_x[x].direction[i].red += cooccurrence[x][y].direction[i].red;
      density_x[x].direction[i].green += cooccurrence[x][y].direction[i].green;
      density_x[x].direction[i].blue += cooccurrence[x][y].direction[i].blue;
      if (image->colorspace == CMYKColorspace)
        density_x[x].direction[i].index += cooccurrence[x][y].direction[i].index;

      if (image->matte != MagickFalse)
        density_x[x].direction[i].opacity += cooccurrence[x][y].direction[i].opacity;

      density_y[y].direction[i].red += cooccurrence[x][y].direction[i].red;
      density_y[y].direction[i].green += cooccurrence[x][y].direction[i].green;
      density_y[y].direction[i].blue += cooccurrence[x][y].direction[i].blue;
      if (image->colorspace == CMYKColorspace)
        density_y[y].direction[i].index += cooccurrence[x][y].direction[i].index;

      if (image->matte != MagickFalse)
        density_y[y].direction[i].opacity += cooccurrence[x][y].direction[i].opacity;

    }

    mean.direction[i].red += y * sum[y].direction[i].red;
    sum_squares.direction[i].red += (y * y) * sum[y].direction[i].red;
    mean.direction[i].green += y * sum[y].direction[i].green;
    sum_squares.direction[i].green += (y * y) * sum[y].direction[i].green;
    mean.direction[i].blue += y * sum[y].direction[i].blue;
    sum_squares.direction[i].blue += (y * y) * sum[y].direction[i].blue;
    if (image->colorspace == CMYKColorspace)
    {
      mean.direction[i].index += y * sum[y].direction[i].index;
      sum_squares.direction[i].index += (y * y) * sum[y].direction[i].index;
    }

    if (image->matte != MagickFalse)
    {
      mean.direction[i].opacity += y * sum[y].direction[i].opacity;
      sum_squares.direction[i].opacity += (y * y) * sum[y].direction[i].opacity;
    }

  }

  channel_features[RedChannel].correlation[i] = (correlation.direction[i].red - (mean.direction[i].red * mean.direction[i].red)) / (sqrt(sum_squares.direction[i].red - (mean.direction[i].red * mean.direction[i].red)) * sqrt(sum_squares.direction[i].red - (mean.direction[i].red * mean.direction[i].red)));
  channel_features[GreenChannel].correlation[i] = (correlation.direction[i].green - (mean.direction[i].green * mean.direction[i].green)) / (sqrt(sum_squares.direction[i].green - (mean.direction[i].green * mean.direction[i].green)) * sqrt(sum_squares.direction[i].green - (mean.direction[i].green * mean.direction[i].green)));
  channel_features[BlueChannel].correlation[i] = (correlation.direction[i].blue - (mean.direction[i].blue * mean.direction[i].blue)) / (sqrt(sum_squares.direction[i].blue - (mean.direction[i].blue * mean.direction[i].blue)) * sqrt(sum_squares.direction[i].blue - (mean.direction[i].blue * mean.direction[i].blue)));
  if (image->colorspace == CMYKColorspace)
    channel_features[IndexChannel].correlation[i] = (correlation.direction[i].index - (mean.direction[i].index * mean.direction[i].index)) / (sqrt(sum_squares.direction[i].index - (mean.direction[i].index * mean.direction[i].index)) * sqrt(sum_squares.direction[i].index - (mean.direction[i].index * mean.direction[i].index)));

  if (image->matte != MagickFalse)
    channel_features[OpacityChannel].correlation[i] = (correlation.direction[i].opacity - (mean.direction[i].opacity * mean.direction[i].opacity)) / (sqrt(sum_squares.direction[i].opacity - (mean.direction[i].opacity * mean.direction[i].opacity)) * sqrt(sum_squares.direction[i].opacity - (mean.direction[i].opacity * mean.direction[i].opacity)));

}
