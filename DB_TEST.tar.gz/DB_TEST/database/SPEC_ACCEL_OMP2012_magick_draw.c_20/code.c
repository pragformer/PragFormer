for (i = 1; i < ((ssize_t) number_vertices); i++)
{
  dx = primitive_info[i].point.x - primitive_info[i - 1].point.x;
  dy = primitive_info[i].point.y - primitive_info[i - 1].point.y;
  maximum_length = hypot((double) dx, dy);
  if (length == 0.0)
  {
    n++;
    if (draw_info->dash_pattern[n] == 0.0)
      n = 0;

    length = scale * (draw_info->dash_pattern[n] + ((n == 0) ? (-0.5) : (0.5)));
  }

  for (total_length = 0.0; (total_length + length) < maximum_length;)
  {
    total_length += length;
    if ((n & 0x01) != 0)
    {
      dash_polygon[0] = primitive_info[0];
      dash_polygon[0].point.x = (double) (primitive_info[i - 1].point.x + ((dx * total_length) / maximum_length));
      dash_polygon[0].point.y = (double) (primitive_info[i - 1].point.y + ((dy * total_length) / maximum_length));
      j = 1;
    }
    else
    {
      if ((j + 1) > ((ssize_t) (2 * number_vertices)))
        break;

      dash_polygon[j] = primitive_info[i - 1];
      dash_polygon[j].point.x = (double) (primitive_info[i - 1].point.x + ((dx * total_length) / maximum_length));
      dash_polygon[j].point.y = (double) (primitive_info[i - 1].point.y + ((dy * total_length) / maximum_length));
      dash_polygon[j].coordinates = 1;
      j++;
      dash_polygon[0].coordinates = (size_t) j;
      dash_polygon[j].primitive = UndefinedPrimitive;
      status |= DrawStrokePolygon(image, clone_info, dash_polygon);
    }

    n++;
    if (draw_info->dash_pattern[n] == 0.0)
      n = 0;

    length = scale * (draw_info->dash_pattern[n] + ((n == 0) ? (-0.5) : (0.5)));
  }

  length -= maximum_length - total_length;
  if ((n & 0x01) != 0)
    continue;

  dash_polygon[j] = primitive_info[i];
  dash_polygon[j].coordinates = 1;
  j++;
}

static MagickBooleanType DrawStrokePolygon(Image *image, const DrawInfo *draw_info, const PrimitiveInfo *primitive_info)
{
  DrawInfo *clone_info;
  MagickBooleanType closed_path;
  MagickBooleanType status;
  PrimitiveInfo *stroke_polygon;
  register const PrimitiveInfo *p;
  register const PrimitiveInfo *q;
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 4640, "    begin draw-stroke-polygon");

  clone_info = CloneDrawInfo((ImageInfo *) 0, draw_info);
  clone_info->fill = draw_info->stroke;
  clone_info->stroke.opacity = (Quantum) TransparentOpacity;
  clone_info->stroke_width = 0.0;
  clone_info->fill_rule = NonZeroRule;
  status = MagickTrue;
  for (p = primitive_info; p->primitive != UndefinedPrimitive; p += p->coordinates)
  {
    stroke_polygon = TraceStrokePolygon(draw_info, p);
    status = DrawPolygonPrimitive(image, clone_info, stroke_polygon);
    stroke_polygon = (PrimitiveInfo *) RelinquishMagickMemory(stroke_polygon);
    q = (p + p->coordinates) - 1;
    closed_path = ((q->point.x == p->point.x) && (q->point.y == p->point.y)) ? (MagickTrue) : (MagickFalse);
    if ((draw_info->linecap == RoundCap) && (closed_path == MagickFalse))
    {
      DrawRoundLinecap(image, draw_info, p);
      DrawRoundLinecap(image, draw_info, q);
    }

  }

  clone_info = DestroyDrawInfo(clone_info);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 4664, "    end draw-stroke-polygon");

  return status;
}

