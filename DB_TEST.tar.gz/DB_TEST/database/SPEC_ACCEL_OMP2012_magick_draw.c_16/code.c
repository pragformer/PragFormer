for (i = 1; i < ((ssize_t) polygon_info->number_edges); i++)
{
  if (polygon_info->edges[i].bounds.x1 < ((double) bounds.x1))
    bounds.x1 = polygon_info->edges[i].bounds.x1;

  if (polygon_info->edges[i].bounds.y1 < ((double) bounds.y1))
    bounds.y1 = polygon_info->edges[i].bounds.y1;

  if (polygon_info->edges[i].bounds.x2 > ((double) bounds.x2))
    bounds.x2 = polygon_info->edges[i].bounds.x2;

  if (polygon_info->edges[i].bounds.y2 > ((double) bounds.y2))
    bounds.y2 = polygon_info->edges[i].bounds.y2;

}
