for (k = 1; k <= 12; k++)
{
  ene[0] += ene[k];
}
