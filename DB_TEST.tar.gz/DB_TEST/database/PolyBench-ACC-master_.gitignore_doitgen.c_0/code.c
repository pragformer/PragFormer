for (r = 0; r < POLYBENCH_LOOP_BOUND(128, nr); r++)
  for (q = 0; q < POLYBENCH_LOOP_BOUND(128, nq); q++)
{
  for (p = 0; p < POLYBENCH_LOOP_BOUND(128, np); p++)
  {
    sum[r][q][p] = 0;
    for (s = 0; s < POLYBENCH_LOOP_BOUND(128, np); s++)
      sum[r][q][p] = sum[r][q][p] + (A[r][q][s] * C4[s][p]);

  }

  for (p = 0; p < POLYBENCH_LOOP_BOUND(128, nr); p++)
    A[r][q][p] = sum[r][q][p];

}

