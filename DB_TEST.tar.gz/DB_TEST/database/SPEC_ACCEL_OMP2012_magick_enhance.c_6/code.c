for (i = 0; i < ((ssize_t) image->colors); i++)
{
  if (((channel & RedChannel) != 0) && (white.red != black.red))
    image->colormap[i].red = ClampToQuantum(equalize_map[ScaleQuantumToMap(image->colormap[i].red)].red);

  if (((channel & GreenChannel) != 0) && (white.green != black.green))
    image->colormap[i].green = ClampToQuantum(equalize_map[ScaleQuantumToMap(image->colormap[i].green)].green);

  if (((channel & BlueChannel) != 0) && (white.blue != black.blue))
    image->colormap[i].blue = ClampToQuantum(equalize_map[ScaleQuantumToMap(image->colormap[i].blue)].blue);

  if (((channel & OpacityChannel) != 0) && (white.opacity != black.opacity))
    image->colormap[i].opacity = ClampToQuantum(equalize_map[ScaleQuantumToMap(image->colormap[i].opacity)].opacity);

}

inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}

