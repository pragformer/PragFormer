for (i = 0; i < ny; i++)
{
  fprintf(stderr, "%0.2lf ", s[i]);
  if ((i % 20) == 0)
    fprintf(stderr, "\n");

}
