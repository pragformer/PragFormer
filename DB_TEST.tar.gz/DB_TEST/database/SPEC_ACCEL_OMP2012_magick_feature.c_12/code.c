for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register const IndexPacket * restrict indexes;
  register const PixelPacket * restrict p;
  register ssize_t x;
  ssize_t i;
  ssize_t offset;
  ssize_t u;
  ssize_t v;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, -((ssize_t) distance), y, image->columns + (2 * distance), distance + 1, exception);
  if (p == ((const PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewVirtualIndexQueue(image_view);
  p += distance;
  indexes += distance;
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    for (i = 0; i < 4; i++)
    {
      switch (i)
      {
        case 0:

        default:
        {
          offset = (ssize_t) distance;
          break;
        }

        case 1:
        {
          offset = (ssize_t) (image->columns + (2 * distance));
          break;
        }

        case 2:
        {
          offset = (ssize_t) ((image->columns + (2 * distance)) - distance);
          break;
        }

        case 3:
        {
          offset = (ssize_t) ((image->columns + (2 * distance)) + distance);
          break;
        }

      }

      u = 0;
      v = 0;
      while (grays[u].red != ScaleQuantumToMap(GetPixelRed(p)))
        u++;

      while (grays[v].red != ScaleQuantumToMap(GetPixelRed(p + offset)))
        v++;

      cooccurrence[u][v].direction[i].red++;
      cooccurrence[v][u].direction[i].red++;
      u = 0;
      v = 0;
      while (grays[u].green != ScaleQuantumToMap(GetPixelGreen(p)))
        u++;

      while (grays[v].green != ScaleQuantumToMap(GetPixelGreen(p + offset)))
        v++;

      cooccurrence[u][v].direction[i].green++;
      cooccurrence[v][u].direction[i].green++;
      u = 0;
      v = 0;
      while (grays[u].blue != ScaleQuantumToMap(GetPixelBlue(p)))
        u++;

      while (grays[v].blue != ScaleQuantumToMap((p + offset)->blue))
        v++;

      cooccurrence[u][v].direction[i].blue++;
      cooccurrence[v][u].direction[i].blue++;
      if (image->colorspace == CMYKColorspace)
      {
        u = 0;
        v = 0;
        while (grays[u].index != ScaleQuantumToMap(GetPixelIndex(indexes + x)))
          u++;

        while (grays[v].index != ScaleQuantumToMap(GetPixelIndex((indexes + x) + offset)))
          v++;

        cooccurrence[u][v].direction[i].index++;
        cooccurrence[v][u].direction[i].index++;
      }

      if (image->matte != MagickFalse)
      {
        u = 0;
        v = 0;
        while (grays[u].opacity != ScaleQuantumToMap(GetPixelOpacity(p)))
          u++;

        while (grays[v].opacity != ScaleQuantumToMap((p + offset)->opacity))
          v++;

        cooccurrence[u][v].direction[i].opacity++;
        cooccurrence[v][u].direction[i].opacity++;
      }

    }

    p++;
  }

}
