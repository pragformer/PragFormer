for (j = 0; j < ((ssize_t) polygon_info->number_edges); j++, p++)
{
  if (y <= ((p->bounds.y1 - mid) - 0.5))
    break;

  if (y > ((p->bounds.y2 + mid) + 0.5))
  {
    (void) DestroyEdge(polygon_info, (size_t) j);
    continue;
  }

  if ((x <= ((p->bounds.x1 - mid) - 0.5)) || (x > ((p->bounds.x2 + mid) + 0.5)))
    continue;

  i = (ssize_t) MagickMax((double) p->highwater, 1.0);
  for (; i < ((ssize_t) p->number_points); i++)
  {
    if (y <= ((p->points[i - 1].y - mid) - 0.5))
      break;

    if (y > ((p->points[i].y + mid) + 0.5))
      continue;

    if (p->scanline != y)
    {
      p->scanline = y;
      p->highwater = (size_t) i;
    }

    q = (p->points + i) - 1;
    delta.x = (q + 1)->x - q->x;
    delta.y = (q + 1)->y - q->y;
    beta = (delta.x * (x - q->x)) + (delta.y * (y - q->y));
    if (beta < 0.0)
    {
      delta.x = x - q->x;
      delta.y = y - q->y;
      distance = (delta.x * delta.x) + (delta.y * delta.y);
    }
    else
    {
      alpha = (delta.x * delta.x) + (delta.y * delta.y);
      if (beta > alpha)
      {
        delta.x = x - (q + 1)->x;
        delta.y = y - (q + 1)->y;
        distance = (delta.x * delta.x) + (delta.y * delta.y);
      }
      else
      {
        alpha = 1.0 / alpha;
        beta = (delta.x * (y - q->y)) - (delta.y * (x - q->x));
        distance = (alpha * beta) * beta;
      }

    }

    beta = 0.0;
    if (p->ghostline == MagickFalse)
    {
      alpha = mid + 0.5;
      if (((*stroke_opacity) < 1.0) && (distance <= ((alpha + 0.25) * (alpha + 0.25))))
      {
        alpha = mid - 0.5;
        if (distance <= ((alpha + 0.25) * (alpha + 0.25)))
          *stroke_opacity = 1.0;
        else
        {
          beta = 1.0;
          if (distance != 1.0)
            beta = sqrt((double) distance);

          alpha = (beta - mid) - 0.5;
          if ((*stroke_opacity) < ((alpha - 0.25) * (alpha - 0.25)))
            *stroke_opacity = (alpha - 0.25) * (alpha - 0.25);

        }

      }

    }

    if (((fill == MagickFalse) || (distance > 1.0)) || (subpath_opacity >= 1.0))
      continue;

    if (distance <= 0.0)
    {
      subpath_opacity = 1.0;
      continue;
    }

    if (distance > 1.0)
      continue;

    if (beta == 0.0)
    {
      beta = 1.0;
      if (distance != 1.0)
        beta = sqrt(distance);

    }

    alpha = beta - 1.0;
    if (subpath_opacity < (alpha * alpha))
      subpath_opacity = alpha * alpha;

  }

}

static size_t DestroyEdge(PolygonInfo *polygon_info, const size_t edge)
{
  assert(edge < polygon_info->number_edges);
  polygon_info->edges[edge].points = (PointInfo *) RelinquishMagickMemory(polygon_info->edges[edge].points);
  polygon_info->number_edges--;
  if (edge < polygon_info->number_edges)
    (void) CopyMagickMemory(polygon_info->edges + edge, (polygon_info->edges + edge) + 1, ((size_t) (polygon_info->number_edges - edge)) * (sizeof(*polygon_info->edges)));

  return polygon_info->number_edges;
}


inline static double MagickMax(const double x, const double y)
{
  if (x > y)
    return x;

  return y;
}

