for (i = 0; i < ni; i++)
  for (j = 0; j < nj; j++)
  for (k = 0; j < nk; k++)
{
  A[i][j][k] = ((i % 12) + (2 * (j % 7))) + (3 * (k % 13));
}


