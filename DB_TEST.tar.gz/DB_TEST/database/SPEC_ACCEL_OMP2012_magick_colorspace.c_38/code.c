for (i = 0; i < ((ssize_t) image->colors); i++)
{
  MagickPixelPacket pixel;
  red = ScaleQuantumToMap(image->colormap[i].red);
  green = ScaleQuantumToMap(image->colormap[i].green);
  blue = ScaleQuantumToMap(image->colormap[i].blue);
  pixel.red = ((x_map[red].x + y_map[green].x) + z_map[blue].x) + primary_info.x;
  pixel.green = ((x_map[red].y + y_map[green].y) + z_map[blue].y) + primary_info.y;
  pixel.blue = ((x_map[red].z + y_map[green].z) + z_map[blue].z) + primary_info.z;
  image->colormap[i].red = ScaleMapToQuantum(pixel.red);
  image->colormap[i].green = ScaleMapToQuantum(pixel.green);
  image->colormap[i].blue = ScaleMapToQuantum(pixel.blue);
}
