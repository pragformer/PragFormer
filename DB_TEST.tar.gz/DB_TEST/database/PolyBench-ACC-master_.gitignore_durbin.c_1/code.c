for (i = 0; i < POLYBENCH_LOOP_BOUND(4000, n); i++)
  out[i] = y[i][POLYBENCH_LOOP_BOUND(4000, n) - 1];
