for (y = (ssize_t) (image->rows - raise_info->height); y < ((ssize_t) image->rows); y++)
{
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  for (x = 0; x < ((ssize_t) (image->rows - y)); x++)
  {
    SetPixelRed(q, ClampToQuantum(QuantumScale * ((((MagickRealType) GetPixelRed(q)) * ScaleCharToQuantum(190)) + (((MagickRealType) foreground) * (QuantumRange - ScaleCharToQuantum(190))))));
    SetPixelGreen(q, ClampToQuantum(QuantumScale * ((((MagickRealType) GetPixelGreen(q)) * ScaleCharToQuantum(190)) + (((MagickRealType) foreground) * (QuantumRange - ScaleCharToQuantum(190))))));
    SetPixelBlue(q, ClampToQuantum(QuantumScale * ((((MagickRealType) GetPixelBlue(q)) * ScaleCharToQuantum(190)) + (((MagickRealType) foreground) * (QuantumRange - ScaleCharToQuantum(190))))));
    q++;
  }

  for (; x < ((ssize_t) (image->columns - (image->rows - y))); x++)
  {
    SetPixelRed(q, ClampToQuantum(QuantumScale * ((((MagickRealType) GetPixelRed(q)) * ScaleCharToQuantum(135)) + (((MagickRealType) background) * (QuantumRange - ScaleCharToQuantum(135))))));
    SetPixelGreen(q, ClampToQuantum(QuantumScale * ((((MagickRealType) GetPixelGreen(q)) * ScaleCharToQuantum(135)) + (((MagickRealType) background) * (QuantumRange - ScaleCharToQuantum(135))))));
    SetPixelBlue(q, ClampToQuantum(QuantumScale * ((((MagickRealType) GetPixelBlue(q)) * ScaleCharToQuantum(135)) + (((MagickRealType) background) * (QuantumRange - ScaleCharToQuantum(135))))));
    q++;
  }

  for (; x < ((ssize_t) image->columns); x++)
  {
    SetPixelRed(q, ClampToQuantum(QuantumScale * ((((MagickRealType) GetPixelRed(q)) * ScaleCharToQuantum(190)) + (((MagickRealType) background) * (QuantumRange - ScaleCharToQuantum(190))))));
    SetPixelGreen(q, ClampToQuantum(QuantumScale * ((((MagickRealType) GetPixelGreen(q)) * ScaleCharToQuantum(190)) + (((MagickRealType) background) * (QuantumRange - ScaleCharToQuantum(190))))));
    SetPixelBlue(q, ClampToQuantum(QuantumScale * ((((MagickRealType) GetPixelBlue(q)) * ScaleCharToQuantum(190)) + (((MagickRealType) background) * (QuantumRange - ScaleCharToQuantum(190))))));
    q++;
  }

  if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_RaiseImage)
    proceed = SetImageProgress(image, "Raise/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

