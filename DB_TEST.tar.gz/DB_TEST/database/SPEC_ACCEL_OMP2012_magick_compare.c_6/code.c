for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register const IndexPacket * restrict indexes;
  register const IndexPacket * restrict reconstruct_indexes;
  register const PixelPacket * restrict p;
  register const PixelPacket * restrict q;
  register ssize_t x;
  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  q = GetCacheViewVirtualPixels(reconstruct_view, 0, y, reconstruct_image->columns, 1, exception);
  if ((p == ((const PixelPacket *) 0)) || (q == ((const PixelPacket *) 0)))
  {
    status = MagickFalse;
    break;
  }

  indexes = GetCacheViewVirtualIndexQueue(image_view);
  reconstruct_indexes = GetCacheViewVirtualIndexQueue(reconstruct_view);
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    MagickRealType distance;
    if ((channel & OpacityChannel) != 0)
    {
      if (image->matte != MagickFalse)
        alpha = (MagickRealType) ((((double) 1.0) / ((double) QuantumRange)) * GetPixelAlpha(p));

      if (reconstruct_image->matte != MagickFalse)
        beta = (MagickRealType) ((((double) 1.0) / ((double) QuantumRange)) * GetPixelAlpha(q));

    }

    if ((channel & RedChannel) != 0)
    {
      distance = fabs((alpha * GetPixelRed(p)) - (beta * GetPixelRed(q)));
      distortion[RedChannel] += distance;
      distortion[CompositeChannels] += distance;
      mean_error += distance * distance;
      if (distance > maximum_error)
        maximum_error = distance;

      area++;
    }

    if ((channel & GreenChannel) != 0)
    {
      distance = fabs((alpha * GetPixelGreen(p)) - (beta * GetPixelGreen(q)));
      distortion[GreenChannel] += distance;
      distortion[CompositeChannels] += distance;
      mean_error += distance * distance;
      if (distance > maximum_error)
        maximum_error = distance;

      area++;
    }

    if ((channel & BlueChannel) != 0)
    {
      distance = fabs((alpha * GetPixelBlue(p)) - (beta * GetPixelBlue(q)));
      distortion[BlueChannel] += distance;
      distortion[CompositeChannels] += distance;
      mean_error += distance * distance;
      if (distance > maximum_error)
        maximum_error = distance;

      area++;
    }

    if (((channel & OpacityChannel) != 0) && (image->matte != MagickFalse))
    {
      distance = fabs(((double) GetPixelOpacity(p)) - GetPixelOpacity(q));
      distortion[OpacityChannel] += distance;
      distortion[CompositeChannels] += distance;
      mean_error += distance * distance;
      if (distance > maximum_error)
        maximum_error = distance;

      area++;
    }

    if ((((channel & IndexChannel) != 0) && (image->colorspace == CMYKColorspace)) && (reconstruct_image->colorspace == CMYKColorspace))
    {
      distance = fabs((alpha * GetPixelIndex(indexes + x)) - (beta * GetPixelIndex(reconstruct_indexes + x)));
      distortion[BlackChannel] += distance;
      distortion[CompositeChannels] += distance;
      mean_error += distance * distance;
      if (distance > maximum_error)
        maximum_error = distance;

      area++;
    }

    p++;
    q++;
  }

}
