for (i = 0; i < prm->Natom; i++)
{
  sumdeijda[soff + i] = 0.0;
}
