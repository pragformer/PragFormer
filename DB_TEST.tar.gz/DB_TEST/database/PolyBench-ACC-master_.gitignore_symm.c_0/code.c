for (i = 0; i < POLYBENCH_LOOP_BOUND(1024, ni); i++)
  for (j = 0; j < POLYBENCH_LOOP_BOUND(1024, nj); j++)
{
  acc = 0;
  for (k = 0; k < (j - 1); k++)
  {
    C[k][j] += (alpha * A[k][i]) * B[i][j];
    acc += B[k][j] * A[k][i];
  }

  C[i][j] = ((beta * C[i][j]) + ((alpha * A[i][i]) * B[i][j])) + (alpha * acc);
}

