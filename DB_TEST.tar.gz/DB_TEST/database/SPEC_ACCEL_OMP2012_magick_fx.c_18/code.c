for (p++; (*p) != '\0';)
{
  if ((*p) == '[')
    level++;
  else
    if ((*p) == ']')
  {
    level--;
    if (level == 0)
      break;

  }


  *(q++) = *(p++);
}
