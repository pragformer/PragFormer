for (j = 0; j < POLYBENCH_LOOP_BOUND(1000, ny); j++)
  ey[0][j] = _fict_[t];
