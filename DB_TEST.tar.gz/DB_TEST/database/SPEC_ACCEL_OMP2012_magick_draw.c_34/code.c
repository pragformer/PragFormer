for (i = 0; primitive_info[i].primitive != UndefinedPrimitive; i++)
  ;
