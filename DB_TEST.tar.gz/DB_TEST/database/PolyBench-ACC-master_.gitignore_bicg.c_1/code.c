for (i = 0; i < POLYBENCH_LOOP_BOUND(4000, nx); i++)
{
  q[i] = 0;
  for (j = 0; j < POLYBENCH_LOOP_BOUND(4000, ny); j++)
  {
    s[j] = s[j] + (r[i] * A[i][j]);
    q[i] = q[i] + (A[i][j] * p[j]);
  }

}
