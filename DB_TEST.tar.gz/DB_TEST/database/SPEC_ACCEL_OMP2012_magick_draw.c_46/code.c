for (p = primitive_info; angle.x < angle.y; angle.x += step)
{
  point.x = (cos(fmod(angle.x, DegreesToRadians(360.0))) * stop.x) + start.x;
  point.y = (sin(fmod(angle.x, DegreesToRadians(360.0))) * stop.y) + start.y;
  TracePoint(p, point);
  p += p->coordinates;
}

inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static void TracePoint(PrimitiveInfo *primitive_info, const PointInfo point)
{
  primitive_info->coordinates = 1;
  primitive_info->point = point;
}

