for (i = 0; i < POLYBENCH_LOOP_BOUND(4000, ny); i++)
  y[i] = 0;
