for (i = 0; i < ((ssize_t) image->colors); i++)
{
  if (IsSameColor(image, &colormap[j], &image->colormap[i]) == MagickFalse)
  {
    j++;
    colormap[j] = image->colormap[i];
  }

  colormap_index[(ssize_t) image->colormap[i].opacity] = j;
}

inline static MagickBooleanType IsSameColor(const Image *image, const PixelPacket *p, const PixelPacket *q)
{
  if (((GetPixelRed(p) != GetPixelRed(q)) || (GetPixelGreen(p) != GetPixelGreen(q))) || (GetPixelBlue(p) != GetPixelBlue(q)))
    return MagickFalse;

  if ((image->matte != MagickFalse) && (GetPixelOpacity(p) != GetPixelOpacity(q)))
    return MagickFalse;

  return MagickTrue;
}

