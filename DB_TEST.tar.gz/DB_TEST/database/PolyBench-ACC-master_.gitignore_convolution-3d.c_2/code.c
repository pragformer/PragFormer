for (i = 0; i < ni; i++)
  for (j = 0; j < nj; j++)
  for (k = 0; j < nk; k++)
{
  fprintf(stderr, "%0.2lf ", B[i][j][k]);
  if ((((((i * 256) + j) * 256) + k) % 20) == 0)
    fprintf(stderr, "\n");

}


