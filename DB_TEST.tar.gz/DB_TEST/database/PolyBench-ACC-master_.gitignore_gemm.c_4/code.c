for (i = 0; i < ni; i++)
  for (j = 0; j < nj; j++)
{
  fprintf(stderr, "%0.2lf ", C[i][j]);
  if ((((i * ni) + j) % 20) == 0)
    fprintf(stderr, "\n");

}

