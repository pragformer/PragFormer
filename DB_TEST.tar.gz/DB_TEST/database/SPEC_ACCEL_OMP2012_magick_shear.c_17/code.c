for (y = 0; y < ((ssize_t) height); y++)
{
  MagickPixelPacket pixel;
  MagickPixelPacket source;
  MagickPixelPacket destination;
  MagickRealType area;
  MagickRealType displacement;
  register IndexPacket * restrict indexes;
  register IndexPacket * restrict shear_indexes;
  register PixelPacket * restrict p;
  register PixelPacket * restrict q;
  register ssize_t i;
  ShearDirection direction;
  ssize_t step;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewAuthenticPixels(image_view, 0, y_offset + y, image->columns, 1, exception);
  if (p == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  p += x_offset;
  indexes += x_offset;
  displacement = degrees * ((MagickRealType) (y - (height / 2.0)));
  if (displacement == 0.0)
    continue;

  if (displacement > 0.0)
    direction = RIGHT;
  else
  {
    displacement *= -1.0;
    direction = LEFT;
  }

  step = (ssize_t) floor((double) displacement);
  area = (MagickRealType) (displacement - step);
  step++;
  pixel = background;
  GetMagickPixelPacket(image, &source);
  GetMagickPixelPacket(image, &destination);
  switch (direction)
  {
    case LEFT:
    {
      if (step > x_offset)
        break;

      q = p - step;
      shear_indexes = indexes - step;
      for (i = 0; i < ((ssize_t) width); i++)
      {
        if ((x_offset + i) < step)
        {
          SetMagickPixelPacket(image, ++p, ++indexes, &pixel);
          q++;
          shear_indexes++;
          continue;
        }

        SetMagickPixelPacket(image, p, indexes, &source);
        MagickPixelCompositeAreaBlend(&pixel, (MagickRealType) pixel.opacity, &source, (MagickRealType) GetPixelOpacity(p), area, &destination);
        SetPixelPacket(image, &destination, q++, shear_indexes++);
        SetMagickPixelPacket(image, p++, indexes++, &pixel);
      }

      MagickPixelCompositeAreaBlend(&pixel, (MagickRealType) pixel.opacity, &background, (MagickRealType) background.opacity, area, &destination);
      SetPixelPacket(image, &destination, q++, shear_indexes++);
      for (i = 0; i < (step - 1); i++)
        SetPixelPacket(image, &background, q++, shear_indexes++);

      break;
    }

    case RIGHT:
    {
      p += width;
      indexes += width;
      q = p + step;
      shear_indexes = indexes + step;
      for (i = 0; i < ((ssize_t) width); i++)
      {
        p--;
        indexes--;
        q--;
        shear_indexes--;
        if (((size_t) (((x_offset + width) + step) - i)) >= image->columns)
          continue;

        SetMagickPixelPacket(image, p, indexes, &source);
        MagickPixelCompositeAreaBlend(&pixel, (MagickRealType) pixel.opacity, &source, (MagickRealType) GetPixelOpacity(p), area, &destination);
        SetPixelPacket(image, &destination, q, shear_indexes);
        SetMagickPixelPacket(image, p, indexes, &pixel);
      }

      MagickPixelCompositeAreaBlend(&pixel, (MagickRealType) pixel.opacity, &background, (MagickRealType) background.opacity, area, &destination);
      SetPixelPacket(image, &destination, --q, --shear_indexes);
      for (i = 0; i < (step - 1); i++)
        SetPixelPacket(image, &background, --q, --shear_indexes);

      break;
    }

  }

  if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_XShearImage)
    proceed = SetImageProgress(image, "XShear/Image", progress++, height);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static void SetMagickPixelPacket(const Image *image, const PixelPacket *color, const IndexPacket *index, MagickPixelPacket *pixel)
{
  pixel->red = (MagickRealType) GetPixelRed(color);
  pixel->green = (MagickRealType) GetPixelGreen(color);
  pixel->blue = (MagickRealType) GetPixelBlue(color);
  pixel->opacity = (MagickRealType) GetPixelOpacity(color);
  if ((image->colorspace == CMYKColorspace) && (index != ((const IndexPacket *) 0)))
    pixel->index = (MagickRealType) GetPixelIndex(index);

}


inline static void SetMagickPixelPacket(const Image *image, const PixelPacket *color, const IndexPacket *index, MagickPixelPacket *pixel)
{
  pixel->red = (MagickRealType) GetPixelRed(color);
  pixel->green = (MagickRealType) GetPixelGreen(color);
  pixel->blue = (MagickRealType) GetPixelBlue(color);
  pixel->opacity = (MagickRealType) GetPixelOpacity(color);
  if ((image->colorspace == CMYKColorspace) && (index != ((const IndexPacket *) 0)))
    pixel->index = (MagickRealType) GetPixelIndex(index);

}


inline static void MagickPixelCompositeAreaBlend(const MagickPixelPacket *p, const MagickRealType alpha, const MagickPixelPacket *q, const MagickRealType beta, const MagickRealType area, MagickPixelPacket *composite)
{
  MagickPixelCompositePlus(p, ((MagickRealType) QuantumRange) - ((1.0 - area) * (QuantumRange - alpha)), q, (MagickRealType) (QuantumRange - (area * (QuantumRange - beta))), composite);
}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static void SetMagickPixelPacket(const Image *image, const PixelPacket *color, const IndexPacket *index, MagickPixelPacket *pixel)
{
  pixel->red = (MagickRealType) GetPixelRed(color);
  pixel->green = (MagickRealType) GetPixelGreen(color);
  pixel->blue = (MagickRealType) GetPixelBlue(color);
  pixel->opacity = (MagickRealType) GetPixelOpacity(color);
  if ((image->colorspace == CMYKColorspace) && (index != ((const IndexPacket *) 0)))
    pixel->index = (MagickRealType) GetPixelIndex(index);

}


inline static void MagickPixelCompositeAreaBlend(const MagickPixelPacket *p, const MagickRealType alpha, const MagickPixelPacket *q, const MagickRealType beta, const MagickRealType area, MagickPixelPacket *composite)
{
  MagickPixelCompositePlus(p, ((MagickRealType) QuantumRange) - ((1.0 - area) * (QuantumRange - alpha)), q, (MagickRealType) (QuantumRange - (area * (QuantumRange - beta))), composite);
}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static void SetMagickPixelPacket(const Image *image, const PixelPacket *color, const IndexPacket *index, MagickPixelPacket *pixel)
{
  pixel->red = (MagickRealType) GetPixelRed(color);
  pixel->green = (MagickRealType) GetPixelGreen(color);
  pixel->blue = (MagickRealType) GetPixelBlue(color);
  pixel->opacity = (MagickRealType) GetPixelOpacity(color);
  if ((image->colorspace == CMYKColorspace) && (index != ((const IndexPacket *) 0)))
    pixel->index = (MagickRealType) GetPixelIndex(index);

}


inline static void MagickPixelCompositeAreaBlend(const MagickPixelPacket *p, const MagickRealType alpha, const MagickPixelPacket *q, const MagickRealType beta, const MagickRealType area, MagickPixelPacket *composite)
{
  MagickPixelCompositePlus(p, ((MagickRealType) QuantumRange) - ((1.0 - area) * (QuantumRange - alpha)), q, (MagickRealType) (QuantumRange - (area * (QuantumRange - beta))), composite);
}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static void SetMagickPixelPacket(const Image *image, const PixelPacket *color, const IndexPacket *index, MagickPixelPacket *pixel)
{
  pixel->red = (MagickRealType) GetPixelRed(color);
  pixel->green = (MagickRealType) GetPixelGreen(color);
  pixel->blue = (MagickRealType) GetPixelBlue(color);
  pixel->opacity = (MagickRealType) GetPixelOpacity(color);
  if ((image->colorspace == CMYKColorspace) && (index != ((const IndexPacket *) 0)))
    pixel->index = (MagickRealType) GetPixelIndex(index);

}


inline static void MagickPixelCompositeAreaBlend(const MagickPixelPacket *p, const MagickRealType alpha, const MagickPixelPacket *q, const MagickRealType beta, const MagickRealType area, MagickPixelPacket *composite)
{
  MagickPixelCompositePlus(p, ((MagickRealType) QuantumRange) - ((1.0 - area) * (QuantumRange - alpha)), q, (MagickRealType) (QuantumRange - (area * (QuantumRange - beta))), composite);
}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

