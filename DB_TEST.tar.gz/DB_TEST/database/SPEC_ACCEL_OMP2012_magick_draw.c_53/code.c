for (j = ((ssize_t) number_vertices) - 2; j >= 0; j--)
{
  dx = primitive_info[number_vertices - 1].point.x - primitive_info[j].point.x;
  dy = primitive_info[number_vertices - 1].point.y - primitive_info[j].point.y;
  if ((fabs((double) dx) >= MagickEpsilon) || (fabs((double) dy) >= MagickEpsilon))
    break;

}
