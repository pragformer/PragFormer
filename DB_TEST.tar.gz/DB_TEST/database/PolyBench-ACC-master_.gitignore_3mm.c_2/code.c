for (i = 0; i < POLYBENCH_LOOP_BOUND(1024, ni); i++)
  for (j = 0; j < POLYBENCH_LOOP_BOUND(1024, nl); j++)
{
  G[i][j] = 0;
  for (k = 0; k < POLYBENCH_LOOP_BOUND(1024, nj); ++k)
    G[i][j] += E[i][k] * F[k][j];

}

