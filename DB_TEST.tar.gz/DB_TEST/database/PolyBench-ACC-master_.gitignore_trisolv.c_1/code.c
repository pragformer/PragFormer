for (i = 0; i < n; i++)
{
  c[i] = (x[i] = ((double) i) / n);
  for (j = 0; j < n; j++)
    A[i][j] = (((double) i) * j) / n;

}
