for (i = 0; i < ny; i++)
  p[i] = i * M_PI;
