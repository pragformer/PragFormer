for (y = 0; y < ((ssize_t) image->rows); y++)
{
  Quantum blue;
  Quantum green;
  Quantum red;
  register PixelPacket * restrict q;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    red = GetPixelRed(q);
    green = GetPixelGreen(q);
    blue = GetPixelBlue(q);
    switch (colorspace)
    {
      case HSBColorspace:
      {
        ModulateHSB(percent_hue, percent_saturation, percent_brightness, &red, &green, &blue);
        break;
      }

      case HSLColorspace:

      default:
      {
        ModulateHSL(percent_hue, percent_saturation, percent_brightness, &red, &green, &blue);
        break;
      }

      case HWBColorspace:
      {
        ModulateHWB(percent_hue, percent_saturation, percent_brightness, &red, &green, &blue);
        break;
      }

    }

    SetPixelRed(q, red);
    SetPixelGreen(q, green);
    SetPixelBlue(q, blue);
    q++;
  }

  if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_ModulateImage)
    proceed = SetImageProgress(image, "Modulate/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

static void ModulateHSB(const double percent_hue, const double percent_saturation, const double percent_brightness, Quantum *red, Quantum *green, Quantum *blue)
{
  double brightness;
  double hue;
  double saturation;
  assert(red != ((Quantum *) 0));
  assert(green != ((Quantum *) 0));
  assert(blue != ((Quantum *) 0));
  ConvertRGBToHSB(*red, *green, *blue, &hue, &saturation, &brightness);
  hue += 0.5 * ((0.01 * percent_hue) - 1.0);
  while (hue < 0.0)
    hue += 1.0;

  while (hue > 1.0)
    hue -= 1.0;

  saturation *= 0.01 * percent_saturation;
  brightness *= 0.01 * percent_brightness;
  ConvertHSBToRGB(hue, saturation, brightness, red, green, blue);
}


static void ModulateHSL(const double percent_hue, const double percent_saturation, const double percent_lightness, Quantum *red, Quantum *green, Quantum *blue)
{
  double hue;
  double lightness;
  double saturation;
  assert(red != ((Quantum *) 0));
  assert(green != ((Quantum *) 0));
  assert(blue != ((Quantum *) 0));
  ConvertRGBToHSL(*red, *green, *blue, &hue, &saturation, &lightness);
  hue += 0.5 * ((0.01 * percent_hue) - 1.0);
  while (hue < 0.0)
    hue += 1.0;

  while (hue > 1.0)
    hue -= 1.0;

  saturation *= 0.01 * percent_saturation;
  lightness *= 0.01 * percent_lightness;
  ConvertHSLToRGB(hue, saturation, lightness, red, green, blue);
}


static void ModulateHWB(const double percent_hue, const double percent_whiteness, const double percent_blackness, Quantum *red, Quantum *green, Quantum *blue)
{
  double blackness;
  double hue;
  double whiteness;
  assert(red != ((Quantum *) 0));
  assert(green != ((Quantum *) 0));
  assert(blue != ((Quantum *) 0));
  ConvertRGBToHWB(*red, *green, *blue, &hue, &whiteness, &blackness);
  hue += 0.5 * ((0.01 * percent_hue) - 1.0);
  while (hue < 0.0)
    hue += 1.0;

  while (hue > 1.0)
    hue -= 1.0;

  blackness *= 0.01 * percent_blackness;
  whiteness *= 0.01 * percent_whiteness;
  ConvertHWBToRGB(hue, whiteness, blackness, red, green, blue);
}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

