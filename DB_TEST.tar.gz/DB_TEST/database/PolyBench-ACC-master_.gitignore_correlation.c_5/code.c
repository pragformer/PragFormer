for (i = 0; i < m; i++)
  for (j = 0; j < m; j++)
{
  fprintf(stderr, "%0.2lf ", symmat[i][j]);
  if ((((i * m) + j) % 20) == 0)
    fprintf(stderr, "\n");

}

