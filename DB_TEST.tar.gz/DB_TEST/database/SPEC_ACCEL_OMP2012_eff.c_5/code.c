for (i = threadnum; i < nphi; i += numthreads)
{
  at1 = (dim * a1[i]) / 3;
  at2 = (dim * a2[i]) / 3;
  at3 = (dim * abs(a3[i])) / 3;
  at4 = (dim * abs(a4[i])) / 3;
  atyp = atype[i] - 1;
  ax = x[at2 + 0] - x[at1 + 0];
  ay = x[at2 + 1] - x[at1 + 1];
  az = x[at2 + 2] - x[at1 + 2];
  bx = x[at3 + 0] - x[at2 + 0];
  by = x[at3 + 1] - x[at2 + 1];
  bz = x[at3 + 2] - x[at2 + 2];
  cx = x[at4 + 0] - x[at3 + 0];
  cy = x[at4 + 1] - x[at3 + 1];
  cz = x[at4 + 2] - x[at3 + 2];
  if (dim == 4)
  {
    aw = x[at2 + 3] - x[at1 + 3];
    bw = x[at3 + 3] - x[at2 + 3];
    cw = x[at4 + 3] - x[at3 + 3];
    ab = (((ax * bx) + (ay * by)) + (az * bz)) + (aw * bw);
    bc = (((bx * cx) + (by * cy)) + (bz * cz)) + (bw * cw);
    ac = (((ax * cx) + (ay * cy)) + (az * cz)) + (aw * cw);
    aa = (((ax * ax) + (ay * ay)) + (az * az)) + (aw * aw);
    bb = (((bx * bx) + (by * by)) + (bz * bz)) + (bw * bw);
    cc = (((cx * cx) + (cy * cy)) + (cz * cz)) + (cw * cw);
  }
  else
  {
    ab = ((ax * bx) + (ay * by)) + (az * bz);
    bc = ((bx * cx) + (by * cy)) + (bz * cz);
    ac = ((ax * cx) + (ay * cy)) + (az * cz);
    aa = ((ax * ax) + (ay * ay)) + (az * az);
    bb = ((bx * bx) + (by * by)) + (bz * bz);
    cc = ((cx * cx) + (cy * cy)) + (cz * cz);
  }

  uu = (aa * bb) - (ab * ab);
  vv = (bb * cc) - (bc * bc);
  uv = (ab * bc) - (ac * bb);
  den = 1.0 / sqrt(uu * vv);
  co = uv * den;
  co1 = (0.5 * co) * den;
  a0x = ((-bc) * bx) + (bb * cx);
  a0y = ((-bc) * by) + (bb * cy);
  a0z = ((-bc) * bz) + (bb * cz);
  b0x = ((ab * cx) + (bc * ax)) - ((2. * ac) * bx);
  b0y = ((ab * cy) + (bc * ay)) - ((2. * ac) * by);
  b0z = ((ab * cz) + (bc * az)) - ((2. * ac) * bz);
  c0x = (ab * bx) - (bb * ax);
  c0y = (ab * by) - (bb * ay);
  c0z = (ab * bz) - (bb * az);
  a1x = (2. * uu) * (((-cc) * bx) + (bc * cx));
  a1y = (2. * uu) * (((-cc) * by) + (bc * cy));
  a1z = (2. * uu) * (((-cc) * bz) + (bc * cz));
  b1x = (2. * uu) * ((bb * cx) - (bc * bx));
  b1y = (2. * uu) * ((bb * cy) - (bc * by));
  b1z = (2. * uu) * ((bb * cz) - (bc * bz));
  a2x = ((-2.) * vv) * ((bb * ax) - (ab * bx));
  a2y = ((-2.) * vv) * ((bb * ay) - (ab * by));
  a2z = ((-2.) * vv) * ((bb * az) - (ab * bz));
  b2x = (2. * vv) * ((aa * bx) - (ab * ax));
  b2y = (2. * vv) * ((aa * by) - (ab * ay));
  b2z = (2. * vv) * ((aa * bz) - (ab * az));
  dd1x = (a0x - (a2x * co1)) * den;
  dd1y = (a0y - (a2y * co1)) * den;
  dd1z = (a0z - (a2z * co1)) * den;
  dd2x = (((-a0x) - b0x) - (((a1x - a2x) - b2x) * co1)) * den;
  dd2y = (((-a0y) - b0y) - (((a1y - a2y) - b2y) * co1)) * den;
  dd2z = (((-a0z) - b0z) - (((a1z - a2z) - b2z) * co1)) * den;
  dd3x = ((b0x - c0x) - ((((-a1x) - b1x) + b2x) * co1)) * den;
  dd3y = ((b0y - c0y) - ((((-a1y) - b1y) + b2y) * co1)) * den;
  dd3z = ((b0z - c0z) - ((((-a1z) - b1z) + b2z) * co1)) * den;
  dd4x = (c0x - (b1x * co1)) * den;
  dd4y = (c0y - (b1y * co1)) * den;
  dd4z = (c0z - (b1z * co1)) * den;
  if (dim == 4)
  {
    a0w = ((-bc) * bw) + (bb * cw);
    b0w = ((ab * cw) + (bc * aw)) - ((2. * ac) * bw);
    c0w = (ab * bw) - (bb * aw);
    a1w = (2. * uu) * (((-cc) * bw) + (bc * cw));
    b1w = (2. * uu) * ((bb * cw) - (bc * bw));
    a2w = ((-2.) * vv) * ((bb * aw) - (ab * bw));
    b2w = (2. * vv) * ((aa * bw) - (ab * aw));
    dd1w = (a0w - (a2w * co1)) * den;
    dd2w = (((-a0w) - b0w) - (((a1w - a2w) - b2w) * co1)) * den;
    dd3w = ((b0w - c0w) - ((((-a1w) - b1w) + b2w) * co1)) * den;
    dd4w = (c0w - (b1w * co1)) * den;
  }

  if (prm->Nhparm && (a3[i] < 0))
  {
    co = (co > 1.0) ? (1.0) : (co);
    co = (co < (-1.0)) ? (-1.0) : (co);
    phi = acos(co);
    ux = (ay * bz) - (az * by);
    uy = (az * bx) - (ax * bz);
    uz = (ax * by) - (ay * bx);
    vx = (by * cz) - (bz * cy);
    vy = (bz * cx) - (bx * cz);
    vz = (bx * cy) - (by * cx);
    dx1 = (uy * vz) - (uz * vy);
    dy1 = (uz * vx) - (ux * vz);
    dz1 = (ux * vy) - (uy * vx);
    dx1 = ((dx1 * bx) + (dy1 * by)) + (dz1 * bz);
    if (dx1 < 0.0)
      phi = -phi;

    delta = phi - Phase[atyp];
    delta = (delta > pi) ? (pi) : (delta);
    delta = (delta < (-pi)) ? (-pi) : (delta);
    df = Pk[atyp] * delta;
    e = df * delta;
    e_tors += e;
    yy = sin(phi);
    if (fabs(yy) > 0.001)
    {
      df = ((-2.0) * df) / yy;
    }
    else
    {
      if (fabs(delta) < 0.10)
      {
        if (Phase[atyp] == 0.0)
        {
          df = ((-2.0) * Pk[atyp]) * (1 + ((phi * phi) / 6.0));
        }
        else
        {
          if (fabs(Phase[atyp]) == pi)
          {
            df = (2.0 * Pk[atyp]) * (1 + ((delta * delta) / 6.0));
          }

        }

      }
      else
      {
        if (((phi > 0.0) && (phi < (pi / 2.0))) || ((phi < 0.0) && (phi > ((-pi) / 2.0))))
          df = df * 1000.;
        else
          df = (-df) * 1000.;

      }

    }

  }
  else
  {
    multi_term:
    if (fabs(Phase[atyp] - 3.142) < 0.01)
      phase = -1.0;
    else
      phase = 1.0;


    ktors = Pk[atyp];
    switch ((int) fabs(Pn[atyp]))
    {
      case 1:
        e = ktors * (1.0 + (phase * co));
        df = phase * ktors;
        break;

      case 2:
        e = ktors * (1.0 + (phase * (((2. * co) * co) - 1.)));
        df = ((phase * ktors) * 4.) * co;
        break;

      case 3:
        cosq = co * co;
        e = ktors * (1.0 + ((phase * co) * ((4. * cosq) - 3.)));
        df = (phase * ktors) * ((12. * cosq) - 3.);
        break;

      case 4:
        cosq = co * co;
        e = ktors * (1.0 + (phase * (((8. * cosq) * (cosq - 1.)) + 1.)));
        df = ((phase * ktors) * co) * ((32. * cosq) - 16.);
        break;

      case 6:
        cosq = co * co;
        e = ktors * (1.0 + (phase * ((((((32. * cosq) * cosq) * cosq) - ((48. * cosq) * cosq)) + (18. * cosq)) - 1.)));
        df = ((phase * ktors) * co) * ((((192. * cosq) * cosq) - (192. * cosq)) + 36.);
        break;

      default:
        fprintf(stderr, "bad value for Pn: %d %d %d %d %8.3f\n", at1, at2, at3, at4, Pn[atyp]);
        exit(1);

    }

    e_tors += e;
  }

  f[(foff + at1) + 0] += df * dd1x;
  f[(foff + at1) + 1] += df * dd1y;
  f[(foff + at1) + 2] += df * dd1z;
  f[(foff + at2) + 0] += df * dd2x;
  f[(foff + at2) + 1] += df * dd2y;
  f[(foff + at2) + 2] += df * dd2z;
  f[(foff + at3) + 0] += df * dd3x;
  f[(foff + at3) + 1] += df * dd3y;
  f[(foff + at3) + 2] += df * dd3z;
  f[(foff + at4) + 0] += df * dd4x;
  f[(foff + at4) + 1] += df * dd4y;
  f[(foff + at4) + 2] += df * dd4z;
  if (dim == 4)
  {
    f[(foff + at1) + 3] += df * dd1w;
    f[(foff + at2) + 3] += df * dd2w;
    f[(foff + at3) + 3] += df * dd3w;
    f[(foff + at4) + 3] += df * dd4w;
  }

  if (Pn[atyp] < 0.0)
  {
    atyp++;
    goto multi_term;
  }

}
