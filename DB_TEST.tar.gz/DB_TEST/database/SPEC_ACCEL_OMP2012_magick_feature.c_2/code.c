for (i = 0; i < 4; i++)
{
  register ssize_t x;
  for (x = 2; x < ((ssize_t) (2 * number_grays)); x++)
  {
    channel_features[RedChannel].sum_average[i] += x * density_xy[x].direction[i].red;
    channel_features[GreenChannel].sum_average[i] += x * density_xy[x].direction[i].green;
    channel_features[BlueChannel].sum_average[i] += x * density_xy[x].direction[i].blue;
    if (image->colorspace == CMYKColorspace)
      channel_features[IndexChannel].sum_average[i] += x * density_xy[x].direction[i].index;

    if (image->matte != MagickFalse)
      channel_features[OpacityChannel].sum_average[i] += x * density_xy[x].direction[i].opacity;

    channel_features[RedChannel].sum_entropy[i] -= density_xy[x].direction[i].red * log10(density_xy[x].direction[i].red + MagickEpsilon);
    channel_features[GreenChannel].sum_entropy[i] -= density_xy[x].direction[i].green * log10(density_xy[x].direction[i].green + MagickEpsilon);
    channel_features[BlueChannel].sum_entropy[i] -= density_xy[x].direction[i].blue * log10(density_xy[x].direction[i].blue + MagickEpsilon);
    if (image->colorspace == CMYKColorspace)
      channel_features[IndexChannel].sum_entropy[i] -= density_xy[x].direction[i].index * log10(density_xy[x].direction[i].index + MagickEpsilon);

    if (image->matte != MagickFalse)
      channel_features[OpacityChannel].sum_entropy[i] -= density_xy[x].direction[i].opacity * log10(density_xy[x].direction[i].opacity + MagickEpsilon);

    channel_features[RedChannel].sum_variance[i] += ((x - channel_features[RedChannel].sum_entropy[i]) * (x - channel_features[RedChannel].sum_entropy[i])) * density_xy[x].direction[i].red;
    channel_features[GreenChannel].sum_variance[i] += ((x - channel_features[GreenChannel].sum_entropy[i]) * (x - channel_features[GreenChannel].sum_entropy[i])) * density_xy[x].direction[i].green;
    channel_features[BlueChannel].sum_variance[i] += ((x - channel_features[BlueChannel].sum_entropy[i]) * (x - channel_features[BlueChannel].sum_entropy[i])) * density_xy[x].direction[i].blue;
    if (image->colorspace == CMYKColorspace)
      channel_features[IndexChannel].sum_variance[i] += ((x - channel_features[IndexChannel].sum_entropy[i]) * (x - channel_features[IndexChannel].sum_entropy[i])) * density_xy[x].direction[i].index;

    if (image->matte != MagickFalse)
      channel_features[OpacityChannel].sum_variance[i] += ((x - channel_features[OpacityChannel].sum_entropy[i]) * (x - channel_features[OpacityChannel].sum_entropy[i])) * density_xy[x].direction[i].opacity;

  }

}
