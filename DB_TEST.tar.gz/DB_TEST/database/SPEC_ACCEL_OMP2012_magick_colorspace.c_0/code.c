for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    SetPixelRed(q, ClampToQuantum((MagickRealType) (QuantumRange - GetPixelRed(q))));
    SetPixelGreen(q, ClampToQuantum((MagickRealType) (QuantumRange - GetPixelGreen(q))));
    SetPixelBlue(q, ClampToQuantum((MagickRealType) (QuantumRange - GetPixelBlue(q))));
    q++;
  }

  sync = SyncCacheViewAuthenticPixels(image_view, exception);
  if (sync == MagickFalse)
    status = MagickFalse;

}

inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}

