for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register PixelPacket * restrict q;
  register ssize_t x;
  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
    break;

  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    (void) GetFillColor(draw_info, x, y, &pixel);
    SetPixelOpacity(q, pixel.opacity);
    q++;
  }

  sync = SyncCacheViewAuthenticPixels(image_view, exception);
  if (sync == MagickFalse)
    break;

}

inline static MagickBooleanType GetFillColor(const DrawInfo *draw_info, const ssize_t x, const ssize_t y, PixelPacket *pixel)
{
  Image *pattern;
  MagickBooleanType status;
  pattern = draw_info->fill_pattern;
  if (pattern == ((Image *) 0))
  {
    *pixel = draw_info->fill;
    return MagickTrue;
  }

  status = GetOneVirtualMethodPixel(pattern, TileVirtualPixelMethod, x + pattern->tile_offset.x, y + pattern->tile_offset.y, pixel, &pattern->exception);
  if (pattern->matte == MagickFalse)
    pixel->opacity = OpaqueOpacity;

  return status;
}

