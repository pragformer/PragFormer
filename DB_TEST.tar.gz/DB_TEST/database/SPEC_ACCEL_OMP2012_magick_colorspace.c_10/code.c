for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  x_map[i].x = 0.299000f * ((MagickRealType) i);
  y_map[i].x = 0.587000f * ((MagickRealType) i);
  z_map[i].x = 0.114000f * ((MagickRealType) i);
  x_map[i].y = (-0.168730f) * ((MagickRealType) i);
  y_map[i].y = (-0.331264f) * ((MagickRealType) i);
  z_map[i].y = 0.500000f * ((MagickRealType) i);
  x_map[i].z = 0.500000f * ((MagickRealType) i);
  y_map[i].z = (-0.418688f) * ((MagickRealType) i);
  z_map[i].z = (-0.081312f) * ((MagickRealType) i);
}
