for (i = 0; i < 1000; i++)
  for (j = 0; j < 1000; j++)
  data[i][j] = (((double) i) * j) / 1000;

