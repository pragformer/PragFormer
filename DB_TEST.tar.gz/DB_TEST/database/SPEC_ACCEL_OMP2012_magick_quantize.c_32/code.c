for (i = 0; i < ((ssize_t) image->colors); i++)
  image->colormap[i].opacity = (unsigned short) i;
