for (v = 0; v < 6; v++)
{
  *message = '\0';
  (void) FormatLocaleString(format, 4096, "%.20g: ", (double) v);
  (void) ConcatenateString(&message, format);
  for (u = 0; u < 6; u++)
  {
    (void) FormatLocaleString(format, 4096, "%+f ", ColorMatrix[v][u]);
    (void) ConcatenateString(&message, format);
  }

  (void) LogMagickEvent(TransformEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_fx.c", __func__, (unsigned long) 967, "%s", message);
}
