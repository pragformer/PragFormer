for (i = 0; image != ((Image *) 0); i++)
{
  progress_monitor = SetImageProgressMonitor(image, (MagickProgressMonitor) 0, image->client_data);
  status = ClassifyImageColors(cube_info, image, &image->exception);
  if (status == MagickFalse)
    break;

  (void) SetImageProgressMonitor(image, progress_monitor, image->client_data);
  proceed = SetImageProgress(image, "Assign/Image", (MagickOffsetType) i, number_images);
  if (proceed == MagickFalse)
    break;

  image = GetNextImageInList(image);
}

static MagickBooleanType ClassifyImageColors(CubeInfo *cube_info, const Image *image, ExceptionInfo *exception)
{
  CacheView *image_view;
  MagickBooleanType proceed;
  MagickRealType bisect;
  NodeInfo *node_info;
  RealPixelPacket error;
  RealPixelPacket mid;
  RealPixelPacket midpoint;
  RealPixelPacket pixel;
  size_t count;
  size_t id;
  size_t index;
  size_t level;
  ssize_t y;
  SetAssociatedAlpha(image, cube_info);
  if ((cube_info->quantize_info->colorspace != UndefinedColorspace) && (cube_info->quantize_info->colorspace != CMYKColorspace))
    (void) TransformImageColorspace((Image *) image, cube_info->quantize_info->colorspace);
  else
    if (((image->colorspace != GRAYColorspace) && (image->colorspace != CMYColorspace)) && (IsRGBColorspace(image->colorspace) == MagickFalse))
    (void) TransformImageColorspace((Image *) image, RGBColorspace);


  midpoint.red = ((MagickRealType) QuantumRange) / 2.0;
  midpoint.green = ((MagickRealType) QuantumRange) / 2.0;
  midpoint.blue = ((MagickRealType) QuantumRange) / 2.0;
  midpoint.opacity = ((MagickRealType) QuantumRange) / 2.0;
  error.opacity = 0.0;
  image_view = AcquireCacheView(image);
  for (y = 0; y < ((ssize_t) image->rows); y++)
  {
    register const PixelPacket * restrict p;
    register ssize_t x;
    p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
    if (p == ((const PixelPacket *) 0))
      break;

    if (cube_info->nodes > 266817)
    {
      PruneLevel(image, cube_info, cube_info->root);
      cube_info->depth--;
    }

    for (x = 0; x < ((ssize_t) image->columns); x += (ssize_t) count)
    {
      for (count = 1; (x + ((ssize_t) count)) < ((ssize_t) image->columns); count++)
        if (IsSameColor(image, p, p + count) == MagickFalse)
        break;


      AssociateAlphaPixel(cube_info, p, &pixel);
      index = 8 - 1;
      bisect = (((MagickRealType) QuantumRange) + 1.0) / 2.0;
      mid = midpoint;
      node_info = cube_info->root;
      for (level = 1; level <= 8; level++)
      {
        bisect *= 0.5;
        id = ColorToNodeId(cube_info, &pixel, index);
        mid.red += ((id & 1) != 0) ? (bisect) : (-bisect);
        mid.green += ((id & 2) != 0) ? (bisect) : (-bisect);
        mid.blue += ((id & 4) != 0) ? (bisect) : (-bisect);
        mid.opacity += ((id & 8) != 0) ? (bisect) : (-bisect);
        if (node_info->child[id] == ((NodeInfo *) 0))
        {
          node_info->child[id] = GetNodeInfo(cube_info, id, level, node_info);
          if (node_info->child[id] == ((NodeInfo *) 0))
            (void) ThrowMagickException(exception, GetMagickModule(), ResourceLimitError, "MemoryAllocationFailed", "`%s'", image->filename);

          if (level == 8)
            cube_info->colors++;

        }

        node_info = node_info->child[id];
        error.red = (((double) 1.0) / ((double) QuantumRange)) * (pixel.red - mid.red);
        error.green = (((double) 1.0) / ((double) QuantumRange)) * (pixel.green - mid.green);
        error.blue = (((double) 1.0) / ((double) QuantumRange)) * (pixel.blue - mid.blue);
        if (cube_info->associate_alpha != MagickFalse)
          error.opacity = (((double) 1.0) / ((double) QuantumRange)) * (pixel.opacity - mid.opacity);

        node_info->quantize_error += sqrt((double) (((((count * error.red) * error.red) + ((count * error.green) * error.green)) + ((count * error.blue) * error.blue)) + ((count * error.opacity) * error.opacity)));
        cube_info->root->quantize_error += node_info->quantize_error;
        index--;
      }

      node_info->number_unique += count;
      node_info->total_color.red += (count * (((double) 1.0) / ((double) QuantumRange))) * pixel.red;
      node_info->total_color.green += (count * (((double) 1.0) / ((double) QuantumRange))) * pixel.green;
      node_info->total_color.blue += (count * (((double) 1.0) / ((double) QuantumRange))) * pixel.blue;
      if (cube_info->associate_alpha != MagickFalse)
        node_info->total_color.opacity += (count * (((double) 1.0) / ((double) QuantumRange))) * pixel.opacity;

      p += count;
    }

    if (cube_info->colors > cube_info->maximum_colors)
    {
      PruneToCubeDepth(image, cube_info, cube_info->root);
      break;
    }

    proceed = SetImageProgress(image, "Classify/Image", (MagickOffsetType) y, image->rows);
    if (proceed == MagickFalse)
      break;

  }

  for (y++; y < ((ssize_t) image->rows); y++)
  {
    register const PixelPacket * restrict p;
    register ssize_t x;
    p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
    if (p == ((const PixelPacket *) 0))
      break;

    if (cube_info->nodes > 266817)
    {
      PruneLevel(image, cube_info, cube_info->root);
      cube_info->depth--;
    }

    for (x = 0; x < ((ssize_t) image->columns); x += (ssize_t) count)
    {
      for (count = 1; (x + ((ssize_t) count)) < ((ssize_t) image->columns); count++)
        if (IsSameColor(image, p, p + count) == MagickFalse)
        break;


      AssociateAlphaPixel(cube_info, p, &pixel);
      index = 8 - 1;
      bisect = (((MagickRealType) QuantumRange) + 1.0) / 2.0;
      mid = midpoint;
      node_info = cube_info->root;
      for (level = 1; level <= cube_info->depth; level++)
      {
        bisect *= 0.5;
        id = ColorToNodeId(cube_info, &pixel, index);
        mid.red += ((id & 1) != 0) ? (bisect) : (-bisect);
        mid.green += ((id & 2) != 0) ? (bisect) : (-bisect);
        mid.blue += ((id & 4) != 0) ? (bisect) : (-bisect);
        mid.opacity += ((id & 8) != 0) ? (bisect) : (-bisect);
        if (node_info->child[id] == ((NodeInfo *) 0))
        {
          node_info->child[id] = GetNodeInfo(cube_info, id, level, node_info);
          if (node_info->child[id] == ((NodeInfo *) 0))
            (void) ThrowMagickException(exception, GetMagickModule(), ResourceLimitError, "MemoryAllocationFailed", "%s", image->filename);

          if (level == cube_info->depth)
            cube_info->colors++;

        }

        node_info = node_info->child[id];
        error.red = (((double) 1.0) / ((double) QuantumRange)) * (pixel.red - mid.red);
        error.green = (((double) 1.0) / ((double) QuantumRange)) * (pixel.green - mid.green);
        error.blue = (((double) 1.0) / ((double) QuantumRange)) * (pixel.blue - mid.blue);
        if (cube_info->associate_alpha != MagickFalse)
          error.opacity = (((double) 1.0) / ((double) QuantumRange)) * (pixel.opacity - mid.opacity);

        node_info->quantize_error += sqrt((double) (((((count * error.red) * error.red) + ((count * error.green) * error.green)) + ((count * error.blue) * error.blue)) + ((count * error.opacity) * error.opacity)));
        cube_info->root->quantize_error += node_info->quantize_error;
        index--;
      }

      node_info->number_unique += count;
      node_info->total_color.red += (count * (((double) 1.0) / ((double) QuantumRange))) * pixel.red;
      node_info->total_color.green += (count * (((double) 1.0) / ((double) QuantumRange))) * pixel.green;
      node_info->total_color.blue += (count * (((double) 1.0) / ((double) QuantumRange))) * pixel.blue;
      if (cube_info->associate_alpha != MagickFalse)
        node_info->total_color.opacity += (count * (((double) 1.0) / ((double) QuantumRange))) * pixel.opacity;

      p += count;
    }

    proceed = SetImageProgress(image, "Classify/Image", (MagickOffsetType) y, image->rows);
    if (proceed == MagickFalse)
      break;

  }

  image_view = DestroyCacheView(image_view);
  if ((cube_info->quantize_info->colorspace != UndefinedColorspace) && (cube_info->quantize_info->colorspace != CMYKColorspace))
    (void) TransformImageColorspace((Image *) image, RGBColorspace);

  return MagickTrue;
}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

