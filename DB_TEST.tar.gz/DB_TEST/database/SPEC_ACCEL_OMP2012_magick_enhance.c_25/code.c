for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register const PixelPacket * restrict p;
  register IndexPacket * restrict indexes;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  if (p == ((const PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  if (channel == DefaultChannels)
    for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    Quantum intensity;
    intensity = PixelIntensityToQuantum(p);
    histogram[ScaleQuantumToMap(intensity)].red++;
    histogram[ScaleQuantumToMap(intensity)].green++;
    histogram[ScaleQuantumToMap(intensity)].blue++;
    histogram[ScaleQuantumToMap(intensity)].index++;
    p++;
  }

  else
    for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    if ((channel & RedChannel) != 0)
      histogram[ScaleQuantumToMap(GetPixelRed(p))].red++;

    if ((channel & GreenChannel) != 0)
      histogram[ScaleQuantumToMap(GetPixelGreen(p))].green++;

    if ((channel & BlueChannel) != 0)
      histogram[ScaleQuantumToMap(GetPixelBlue(p))].blue++;

    if ((channel & OpacityChannel) != 0)
      histogram[ScaleQuantumToMap(GetPixelOpacity(p))].opacity++;

    if (((channel & IndexChannel) != 0) && (image->colorspace == CMYKColorspace))
      histogram[ScaleQuantumToMap(GetPixelIndex(indexes + x))].index++;

    p++;
  }


}

inline static Quantum PixelIntensityToQuantum(const PixelPacket *pixel)
{
  if ((GetPixelRed(pixel) == GetPixelGreen(pixel)) && (GetPixelGreen(pixel) == GetPixelBlue(pixel)))
    return GetPixelRed(pixel);

  return (Quantum) ((((0.299 * GetPixelRed(pixel)) + (0.587 * GetPixelGreen(pixel))) + (0.114 * GetPixelBlue(pixel))) + 0.5);
}

