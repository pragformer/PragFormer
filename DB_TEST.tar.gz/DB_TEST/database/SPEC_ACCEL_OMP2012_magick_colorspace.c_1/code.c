for (y = 0; y < ((ssize_t) image->rows); y++)
{
  MagickPixelPacket pixel;
  register IndexPacket * restrict indexes;
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  pixel = zero;
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    SetMagickPixelPacket(image, q, indexes + x, &pixel);
    ConvertRGBToCMYK(&pixel);
    SetPixelPacket(image, &pixel, q, indexes + x);
    q++;
  }

  sync = SyncCacheViewAuthenticPixels(image_view, exception);
  if (sync == MagickFalse)
    status = MagickFalse;

}

inline static void SetMagickPixelPacket(const Image *image, const PixelPacket *color, const IndexPacket *index, MagickPixelPacket *pixel)
{
  pixel->red = (MagickRealType) GetPixelRed(color);
  pixel->green = (MagickRealType) GetPixelGreen(color);
  pixel->blue = (MagickRealType) GetPixelBlue(color);
  pixel->opacity = (MagickRealType) GetPixelOpacity(color);
  if ((image->colorspace == CMYKColorspace) && (index != ((const IndexPacket *) 0)))
    pixel->index = (MagickRealType) GetPixelIndex(index);

}


inline static void ConvertRGBToCMYK(MagickPixelPacket *pixel)
{
  MagickRealType black;
  MagickRealType cyan;
  MagickRealType magenta;
  MagickRealType yellow;
  if (((pixel->red == 0) && (pixel->green == 0)) && (pixel->blue == 0))
  {
    pixel->index = (MagickRealType) QuantumRange;
    return;
  }

  cyan = (MagickRealType) (1.0 - (QuantumScale * pixel->red));
  magenta = (MagickRealType) (1.0 - (QuantumScale * pixel->green));
  yellow = (MagickRealType) (1.0 - (QuantumScale * pixel->blue));
  black = cyan;
  if (magenta < black)
    black = magenta;

  if (yellow < black)
    black = yellow;

  cyan = (MagickRealType) ((cyan - black) / (1.0 - black));
  magenta = (MagickRealType) ((magenta - black) / (1.0 - black));
  yellow = (MagickRealType) ((yellow - black) / (1.0 - black));
  pixel->colorspace = CMYKColorspace;
  pixel->red = QuantumRange * cyan;
  pixel->green = QuantumRange * magenta;
  pixel->blue = QuantumRange * yellow;
  pixel->index = QuantumRange * black;
}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}

