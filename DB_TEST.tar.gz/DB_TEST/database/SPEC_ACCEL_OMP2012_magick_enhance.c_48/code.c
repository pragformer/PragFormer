for (white = (ssize_t) MaxMap; white != 0; white--)
{
  intensity += histogram[white];
  if (intensity >= white_point)
    break;

}
