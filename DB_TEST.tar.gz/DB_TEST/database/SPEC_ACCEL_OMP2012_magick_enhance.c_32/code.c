for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  intensity += histogram[i].opacity;
  if (intensity > black_point)
    break;

}
