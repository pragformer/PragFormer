for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  x_map[i].x = 0.29900f * ((MagickRealType) i);
  y_map[i].x = 0.58700f * ((MagickRealType) i);
  z_map[i].x = 0.11400f * ((MagickRealType) i);
  x_map[i].y = (-0.14740f) * ((MagickRealType) i);
  y_map[i].y = (-0.28950f) * ((MagickRealType) i);
  z_map[i].y = 0.43690f * ((MagickRealType) i);
  x_map[i].z = 0.61500f * ((MagickRealType) i);
  y_map[i].z = (-0.51500f) * ((MagickRealType) i);
  z_map[i].z = (-0.10000f) * ((MagickRealType) i);
}
