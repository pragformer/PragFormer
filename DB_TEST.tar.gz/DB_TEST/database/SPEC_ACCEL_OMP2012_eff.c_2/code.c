for (i = threadnum; i < prm->Natom; i += numthreads)
{
  if (constrained[i])
  {
    rx = x[dim * i] - x0[dim * i];
    ry = x[(dim * i) + 1] - x0[(dim * i) + 1];
    rz = x[(dim * i) + 2] - x0[(dim * i) + 2];
    e_cons += wcons * (((rx * rx) + (ry * ry)) + (rz * rz));
    f[foff + (dim * i)] += (2. * wcons) * rx;
    f[(foff + (dim * i)) + 1] += (2. * wcons) * ry;
    f[(foff + (dim * i)) + 2] += (2. * wcons) * rz;
    if (dim == 4)
    {
      rw = x[(dim * i) + 3] - x0[(dim * i) + 3];
      e_cons += (wcons * rw) * rw;
      f[(foff + (dim * i)) + 3] += (2. * wcons) * rw;
    }

  }

}
