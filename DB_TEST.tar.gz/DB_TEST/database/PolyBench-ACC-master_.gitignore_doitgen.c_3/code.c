for (i = 0; i < nr; i++)
  for (j = 0; j < nq; j++)
  for (k = 0; k < np; k++)
{
  fprintf(stderr, "%0.2lf ", A[i][j][k]);
  if ((i % 20) == 0)
    fprintf(stderr, "\n");

}


