for (i = 0; i <= ((ssize_t) MaxMap); i++)
  gamma_map[i] = ClampToQuantum((MagickRealType) ScaleMapToQuantum((MagickRealType) (MaxMap * pow(((double) i) / MaxMap, 1.0 / gamma))));

inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}

