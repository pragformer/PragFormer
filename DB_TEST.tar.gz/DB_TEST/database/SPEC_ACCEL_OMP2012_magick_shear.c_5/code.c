for (tile_y = 0; tile_y < ((ssize_t) image->rows); tile_y += (ssize_t) tile_height)
{
  register ssize_t tile_x;
  if (status == MagickFalse)
    continue;

  for (tile_x = 0; tile_x < ((ssize_t) image->columns); tile_x += (ssize_t) tile_width)
  {
    MagickBooleanType sync;
    register const IndexPacket * restrict indexes;
    register const PixelPacket * restrict p;
    register IndexPacket * restrict rotate_indexes;
    register ssize_t y;
    register PixelPacket * restrict q;
    size_t height;
    size_t width;
    width = tile_width;
    if ((tile_x + ((ssize_t) tile_width)) > ((ssize_t) image->columns))
      width = (size_t) (tile_width - ((tile_x + tile_width) - image->columns));

    height = tile_height;
    if ((tile_y + ((ssize_t) tile_height)) > ((ssize_t) image->rows))
      height = (size_t) (tile_height - ((tile_y + tile_height) - image->rows));

    p = GetCacheViewVirtualPixels(image_view, tile_x, tile_y, width, height, exception);
    if (p == ((const PixelPacket *) 0))
    {
      status = MagickFalse;
      break;
    }

    indexes = GetCacheViewVirtualIndexQueue(image_view);
    for (y = 0; y < ((ssize_t) width); y++)
    {
      register const PixelPacket * restrict tile_pixels;
      register ssize_t x;
      q = QueueCacheViewAuthenticPixels(rotate_view, tile_y, (ssize_t) ((y + rotate_image->rows) - (tile_x + width)), height, 1, exception);
      if (q == ((PixelPacket *) 0))
      {
        status = MagickFalse;
        break;
      }

      tile_pixels = (p + (width - 1)) - y;
      for (x = 0; x < ((ssize_t) height); x++)
      {
        *(q++) = *tile_pixels;
        tile_pixels += width;
      }

      rotate_indexes = GetCacheViewAuthenticIndexQueue(rotate_view);
      if ((indexes != ((IndexPacket *) 0)) && (rotate_indexes != ((IndexPacket *) 0)))
      {
        register const IndexPacket * restrict tile_indexes;
        tile_indexes = (indexes + (width - 1)) - y;
        for (x = 0; x < ((ssize_t) height); x++)
        {
          *(rotate_indexes++) = *tile_indexes;
          tile_indexes += width;
        }

      }

      sync = SyncCacheViewAuthenticPixels(rotate_view, exception);
      if (sync == MagickFalse)
        status = MagickFalse;

    }

  }

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    proceed = SetImageProgress(image, "Rotate/Image", progress += tile_height, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

