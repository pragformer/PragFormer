for (i = 0; i < ni; i++)
  for (j = 0; j < ni; j++)
{
  A[i][j] = (((double) i) * j) / ni;
  B[i][j] = (((double) i) * j) / ni;
}

