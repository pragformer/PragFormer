for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  if (grays[i].red != (~0U))
    grays[(ssize_t) (gray.red++)].red = grays[i].red;

  if (grays[i].green != (~0U))
    grays[(ssize_t) (gray.green++)].green = grays[i].green;

  if (grays[i].blue != (~0U))
    grays[(ssize_t) (gray.blue++)].blue = grays[i].blue;

  if (image->colorspace == CMYKColorspace)
    if (grays[i].index != (~0U))
    grays[(ssize_t) (gray.index++)].index = grays[i].index;


  if (image->matte != MagickFalse)
    if (grays[i].opacity != (~0U))
    grays[(ssize_t) (gray.opacity++)].opacity = grays[i].opacity;


}
