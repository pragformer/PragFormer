for (i = 0; i < ((ssize_t) image->colors); i++)
  Contrast(sign, &image->colormap[i].red, &image->colormap[i].green, &image->colormap[i].blue);

static void Contrast(const int sign, Quantum *red, Quantum *green, Quantum *blue)
{
  double brightness;
  double hue;
  double saturation;
  assert(red != ((Quantum *) 0));
  assert(green != ((Quantum *) 0));
  assert(blue != ((Quantum *) 0));
  hue = 0.0;
  saturation = 0.0;
  brightness = 0.0;
  ConvertRGBToHSB(*red, *green, *blue, &hue, &saturation, &brightness);
  brightness += (0.5 * sign) * ((0.5 * (sin((double) (3.14159265358979323846264338327950288419716939937510L * (brightness - 0.5))) + 1.0)) - brightness);
  if (brightness > 1.0)
    brightness = 1.0;
  else
    if (brightness < 0.0)
    brightness = 0.0;


  ConvertHSBToRGB(hue, saturation, brightness, red, green, blue);
}

