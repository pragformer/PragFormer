for (n = 1; n < ((ssize_t) number_vertices); n++)
{
  dx.p = polygon_primitive[n].point.x - polygon_primitive[0].point.x;
  dy.p = polygon_primitive[n].point.y - polygon_primitive[0].point.y;
  if ((fabs(dx.p) >= MagickEpsilon) || (fabs(dy.p) >= MagickEpsilon))
    break;

}
