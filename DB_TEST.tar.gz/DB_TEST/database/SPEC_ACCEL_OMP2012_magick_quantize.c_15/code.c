for (i = 0; i < 16; i++)
{
  cube_info->weights[(16 - i) - 1] = 1.0 / weight;
  weight *= exp(log(((double) QuantumRange) + 1.0) / (16 - 1.0));
}
