for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  x_map[i].x = (MagickRealType) i;
  y_map[i].x = 0.000000f;
  z_map[i].x = (1.402000f * 0.500000f) * ((2.000000f * ((MagickRealType) i)) - ((MagickRealType) MaxMap));
  x_map[i].y = (MagickRealType) i;
  y_map[i].y = ((-0.344136f) * 0.500000f) * ((2.000000f * ((MagickRealType) i)) - ((MagickRealType) MaxMap));
  z_map[i].y = ((-0.714136f) * 0.500000f) * ((2.000000f * ((MagickRealType) i)) - ((MagickRealType) MaxMap));
  x_map[i].z = (MagickRealType) i;
  y_map[i].z = (1.772000f * 0.500000f) * ((2.000000f * ((MagickRealType) i)) - ((MagickRealType) MaxMap));
  z_map[i].z = 0.000000f;
}
