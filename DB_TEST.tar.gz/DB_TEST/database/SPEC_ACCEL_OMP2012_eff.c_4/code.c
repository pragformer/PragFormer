for (i = threadnum; i < nang; i += numthreads)
{
  at1 = (dim * a1[i]) / 3;
  at2 = (dim * a2[i]) / 3;
  at3 = (dim * a3[i]) / 3;
  atyp = atype[i] - 1;
  dxi = x[at1] - x[at2];
  dyi = x[at1 + 1] - x[at2 + 1];
  dzi = x[at1 + 2] - x[at2 + 2];
  dxj = x[at3] - x[at2];
  dyj = x[at3 + 1] - x[at2 + 1];
  dzj = x[at3 + 2] - x[at2 + 2];
  ri2 = ((dxi * dxi) + (dyi * dyi)) + (dzi * dzi);
  rj2 = ((dxj * dxj) + (dyj * dyj)) + (dzj * dzj);
  if (dim == 4)
  {
    dwi = x[at1 + 3] - x[at2 + 3];
    dwj = x[at3 + 3] - x[at2 + 3];
    ri2 += dwi * dwi;
    rj2 += dwj * dwj;
  }

  ri = sqrt(ri2);
  rj = sqrt(rj2);
  rir = 1. / ri;
  rjr = 1. / rj;
  dxir = dxi * rir;
  dyir = dyi * rir;
  dzir = dzi * rir;
  dxjr = dxj * rjr;
  dyjr = dyj * rjr;
  dzjr = dzj * rjr;
  cst = ((dxir * dxjr) + (dyir * dyjr)) + (dzir * dzjr);
  if (dim == 4)
  {
    dwir = dwi * rir;
    dwjr = dwj * rjr;
    cst += dwir * dwjr;
  }

  if (cst > 1.0)
    cst = 1.0;

  if (cst < (-1.0))
    cst = -1.0;

  at = acos(cst);
  da = at - Teq[atyp];
  df = da * Tk[atyp];
  e = df * da;
  e_theta = e_theta + e;
  df = df + df;
  at = sin(at);
  if ((at > 0) && (at < 1.e-3))
    at = 1.e-3;
  else
    if ((at < 0) && (at > (-1.e-3)))
    at = -1.e-3;


  df = (-df) / at;
  xtmp = (df * rir) * (dxjr - (cst * dxir));
  dxtmp = (df * rjr) * (dxir - (cst * dxjr));
  ytmp = (df * rir) * (dyjr - (cst * dyir));
  dytmp = (df * rjr) * (dyir - (cst * dyjr));
  ztmp = (df * rir) * (dzjr - (cst * dzir));
  dztmp = (df * rjr) * (dzir - (cst * dzjr));
  f[(foff + at1) + 0] += xtmp;
  f[(foff + at3) + 0] += dxtmp;
  f[(foff + at2) + 0] -= xtmp + dxtmp;
  f[(foff + at1) + 1] += ytmp;
  f[(foff + at3) + 1] += dytmp;
  f[(foff + at2) + 1] -= ytmp + dytmp;
  f[(foff + at1) + 2] += ztmp;
  f[(foff + at3) + 2] += dztmp;
  f[(foff + at2) + 2] -= ztmp + dztmp;
  if (dim == 4)
  {
    wtmp = (df * rir) * (dwjr - (cst * dwir));
    dwtmp = (df * rjr) * (dwir - (cst * dwjr));
    f[(foff + at1) + 3] += wtmp;
    f[(foff + at3) + 3] += dwtmp;
    f[(foff + at2) + 3] -= wtmp + dwtmp;
  }

}
