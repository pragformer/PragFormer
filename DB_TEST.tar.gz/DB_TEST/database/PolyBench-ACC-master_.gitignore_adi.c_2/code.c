for (i1 = 0; i1 < POLYBENCH_LOOP_BOUND(1024, n); i1++)
  for (i2 = 0; i2 < (POLYBENCH_LOOP_BOUND(1024, n) - 2); i2++)
  X[i1][(POLYBENCH_LOOP_BOUND(1024, n) - i2) - 2] = (X[i1][(POLYBENCH_LOOP_BOUND(1024, n) - 2) - i2] - (X[i1][((POLYBENCH_LOOP_BOUND(1024, n) - 2) - i2) - 1] * A[i1][(POLYBENCH_LOOP_BOUND(1024, n) - i2) - 3])) / B[i1][(POLYBENCH_LOOP_BOUND(1024, n) - 3) - i2];

