for (span = cube_info->colors; cube_info->colors > cube_info->maximum_colors;)
{
  cube_info->pruning_threshold = cube_info->next_threshold;
  cube_info->next_threshold = cube_info->root->quantize_error - 1;
  cube_info->colors = 0;
  Reduce(image, cube_info, cube_info->root);
  offset = ((MagickOffsetType) span) - cube_info->colors;
  proceed = SetImageProgress(image, "Reduce/Image", offset, (span - cube_info->maximum_colors) + 1);
  if (proceed == MagickFalse)
    break;

}

static void Reduce(const Image *image, CubeInfo *cube_info, const NodeInfo *node_info)
{
  register ssize_t i;
  size_t number_children;
  number_children = (cube_info->associate_alpha == MagickFalse) ? (8UL) : (16UL);
  for (i = 0; i < ((ssize_t) number_children); i++)
    if (node_info->child[i] != ((NodeInfo *) 0))
    Reduce(image, cube_info, node_info->child[i]);


  if (node_info->quantize_error <= cube_info->pruning_threshold)
    PruneChild(image, cube_info, node_info);
  else
  {
    if (node_info->number_unique > 0)
      cube_info->colors++;

    if (node_info->quantize_error < cube_info->next_threshold)
      cube_info->next_threshold = node_info->quantize_error;

  }

}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

