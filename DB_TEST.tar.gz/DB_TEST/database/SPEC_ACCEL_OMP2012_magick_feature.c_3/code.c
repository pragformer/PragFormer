for (i = 0; i < 4; i++)
{
  register ssize_t y;
  for (y = 0; y < ((ssize_t) number_grays); y++)
  {
    register ssize_t x;
    for (x = 0; x < ((ssize_t) number_grays); x++)
    {
      variance.direction[i].red += (((y - mean.direction[i].red) + 1) * ((y - mean.direction[i].red) + 1)) * cooccurrence[x][y].direction[i].red;
      variance.direction[i].green += (((y - mean.direction[i].green) + 1) * ((y - mean.direction[i].green) + 1)) * cooccurrence[x][y].direction[i].green;
      variance.direction[i].blue += (((y - mean.direction[i].blue) + 1) * ((y - mean.direction[i].blue) + 1)) * cooccurrence[x][y].direction[i].blue;
      if (image->colorspace == CMYKColorspace)
        variance.direction[i].index += (((y - mean.direction[i].index) + 1) * ((y - mean.direction[i].index) + 1)) * cooccurrence[x][y].direction[i].index;

      if (image->matte != MagickFalse)
        variance.direction[i].opacity += (((y - mean.direction[i].opacity) + 1) * ((y - mean.direction[i].opacity) + 1)) * cooccurrence[x][y].direction[i].opacity;

      density_xy[MagickAbsoluteValue(y - x)].direction[i].red += cooccurrence[x][y].direction[i].red;
      density_xy[MagickAbsoluteValue(y - x)].direction[i].green += cooccurrence[x][y].direction[i].green;
      density_xy[MagickAbsoluteValue(y - x)].direction[i].blue += cooccurrence[x][y].direction[i].blue;
      if (image->colorspace == CMYKColorspace)
        density_xy[MagickAbsoluteValue(y - x)].direction[i].index += cooccurrence[x][y].direction[i].index;

      if (image->matte != MagickFalse)
        density_xy[MagickAbsoluteValue(y - x)].direction[i].opacity += cooccurrence[x][y].direction[i].opacity;

      entropy_xy.direction[i].red -= cooccurrence[x][y].direction[i].red * log10(cooccurrence[x][y].direction[i].red + MagickEpsilon);
      entropy_xy.direction[i].green -= cooccurrence[x][y].direction[i].green * log10(cooccurrence[x][y].direction[i].green + MagickEpsilon);
      entropy_xy.direction[i].blue -= cooccurrence[x][y].direction[i].blue * log10(cooccurrence[x][y].direction[i].blue + MagickEpsilon);
      if (image->colorspace == CMYKColorspace)
        entropy_xy.direction[i].index -= cooccurrence[x][y].direction[i].index * log10(cooccurrence[x][y].direction[i].index + MagickEpsilon);

      if (image->matte != MagickFalse)
        entropy_xy.direction[i].opacity -= cooccurrence[x][y].direction[i].opacity * log10(cooccurrence[x][y].direction[i].opacity + MagickEpsilon);

      entropy_xy1.direction[i].red -= cooccurrence[x][y].direction[i].red * log10((density_x[x].direction[i].red * density_y[y].direction[i].red) + MagickEpsilon);
      entropy_xy1.direction[i].green -= cooccurrence[x][y].direction[i].green * log10((density_x[x].direction[i].green * density_y[y].direction[i].green) + MagickEpsilon);
      entropy_xy1.direction[i].blue -= cooccurrence[x][y].direction[i].blue * log10((density_x[x].direction[i].blue * density_y[y].direction[i].blue) + MagickEpsilon);
      if (image->colorspace == CMYKColorspace)
        entropy_xy1.direction[i].index -= cooccurrence[x][y].direction[i].index * log10((density_x[x].direction[i].index * density_y[y].direction[i].index) + MagickEpsilon);

      if (image->matte != MagickFalse)
        entropy_xy1.direction[i].opacity -= cooccurrence[x][y].direction[i].opacity * log10((density_x[x].direction[i].opacity * density_y[y].direction[i].opacity) + MagickEpsilon);

      entropy_xy2.direction[i].red -= (density_x[x].direction[i].red * density_y[y].direction[i].red) * log10((density_x[x].direction[i].red * density_y[y].direction[i].red) + MagickEpsilon);
      entropy_xy2.direction[i].green -= (density_x[x].direction[i].green * density_y[y].direction[i].green) * log10((density_x[x].direction[i].green * density_y[y].direction[i].green) + MagickEpsilon);
      entropy_xy2.direction[i].blue -= (density_x[x].direction[i].blue * density_y[y].direction[i].blue) * log10((density_x[x].direction[i].blue * density_y[y].direction[i].blue) + MagickEpsilon);
      if (image->colorspace == CMYKColorspace)
        entropy_xy2.direction[i].index -= (density_x[x].direction[i].index * density_y[y].direction[i].index) * log10((density_x[x].direction[i].index * density_y[y].direction[i].index) + MagickEpsilon);

      if (image->matte != MagickFalse)
        entropy_xy2.direction[i].opacity -= (density_x[x].direction[i].opacity * density_y[y].direction[i].opacity) * log10((density_x[x].direction[i].opacity * density_y[y].direction[i].opacity) + MagickEpsilon);

    }

  }

  channel_features[RedChannel].variance_sum_of_squares[i] = variance.direction[i].red;
  channel_features[GreenChannel].variance_sum_of_squares[i] = variance.direction[i].green;
  channel_features[BlueChannel].variance_sum_of_squares[i] = variance.direction[i].blue;
  if (image->colorspace == CMYKColorspace)
    channel_features[RedChannel].variance_sum_of_squares[i] = variance.direction[i].index;

  if (image->matte != MagickFalse)
    channel_features[RedChannel].variance_sum_of_squares[i] = variance.direction[i].opacity;

}

inline static ssize_t MagickAbsoluteValue(const ssize_t x)
{
  if (x < 0)
    return -x;

  return x;
}


inline static ssize_t MagickAbsoluteValue(const ssize_t x)
{
  if (x < 0)
    return -x;

  return x;
}


inline static ssize_t MagickAbsoluteValue(const ssize_t x)
{
  if (x < 0)
    return -x;

  return x;
}


inline static ssize_t MagickAbsoluteValue(const ssize_t x)
{
  if (x < 0)
    return -x;

  return x;
}


inline static ssize_t MagickAbsoluteValue(const ssize_t x)
{
  if (x < 0)
    return -x;

  return x;
}

