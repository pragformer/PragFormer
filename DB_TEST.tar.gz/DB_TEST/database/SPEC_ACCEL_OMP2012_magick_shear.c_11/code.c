for (step = 1; step < p->width; step *= 2)
{
  for (x = 0; x < ((ssize_t) p->width); x += 2 * ((ssize_t) step))
  {
    register ssize_t i;
    ssize_t y;
    unsigned short cell;
    for (i = 0; i < ((ssize_t) step); i++)
    {
      for (y = 0; y < ((ssize_t) ((p->height - i) - 1)); y++)
      {
        cell = GetRadonCell(p, x + i, y);
        (void) SetRadonCell(q, x + (2 * i), y, cell + GetRadonCell(p, (x + i) + ((ssize_t) step), y + i));
        (void) SetRadonCell(q, (x + (2 * i)) + 1, y, cell + GetRadonCell(p, (x + i) + ((ssize_t) step), (y + i) + 1));
      }

      for (; y < ((ssize_t) (p->height - i)); y++)
      {
        cell = GetRadonCell(p, x + i, y);
        (void) SetRadonCell(q, x + (2 * i), y, cell + GetRadonCell(p, (x + i) + ((ssize_t) step), y + i));
        (void) SetRadonCell(q, (x + (2 * i)) + 1, y, cell);
      }

      for (; y < ((ssize_t) p->height); y++)
      {
        cell = GetRadonCell(p, x + i, y);
        (void) SetRadonCell(q, x + (2 * i), y, cell);
        (void) SetRadonCell(q, (x + (2 * i)) + 1, y, cell);
      }

    }

  }

  swap = p;
  p = q;
  q = swap;
}

inline static unsigned short GetRadonCell(const RadonInfo *radon_info, const ssize_t x, const ssize_t y)
{
  MagickOffsetType i;
  unsigned short value;
  i = (((MagickOffsetType) radon_info->height) * x) + y;
  if ((i < 0) || (((MagickSizeType) (i * (sizeof(*radon_info->cells)))) >= radon_info->length))
    return 0;

  if (radon_info->type != DiskCache)
    return radon_info->cells[i];

  value = 0;
  (void) ReadRadonCell(radon_info, i * (sizeof(*radon_info->cells)), sizeof(*radon_info->cells), (unsigned char *) (&value));
  return value;
}


inline static MagickBooleanType SetRadonCell(const RadonInfo *radon_info, const ssize_t x, const ssize_t y, const unsigned short value)
{
  MagickOffsetType i;
  ssize_t count;
  i = (((MagickOffsetType) radon_info->height) * x) + y;
  if ((i < 0) || (((MagickSizeType) (i * (sizeof(*radon_info->cells)))) >= radon_info->length))
    return MagickFalse;

  if (radon_info->type != DiskCache)
  {
    radon_info->cells[i] = value;
    return MagickTrue;
  }

  count = WriteRadonCell(radon_info, i * (sizeof(*radon_info->cells)), sizeof(*radon_info->cells), (const unsigned char *) (&value));
  if (count != ((ssize_t) (sizeof(*radon_info->cells))))
    return MagickFalse;

  return MagickTrue;
}


inline static unsigned short GetRadonCell(const RadonInfo *radon_info, const ssize_t x, const ssize_t y)
{
  MagickOffsetType i;
  unsigned short value;
  i = (((MagickOffsetType) radon_info->height) * x) + y;
  if ((i < 0) || (((MagickSizeType) (i * (sizeof(*radon_info->cells)))) >= radon_info->length))
    return 0;

  if (radon_info->type != DiskCache)
    return radon_info->cells[i];

  value = 0;
  (void) ReadRadonCell(radon_info, i * (sizeof(*radon_info->cells)), sizeof(*radon_info->cells), (unsigned char *) (&value));
  return value;
}


inline static MagickBooleanType SetRadonCell(const RadonInfo *radon_info, const ssize_t x, const ssize_t y, const unsigned short value)
{
  MagickOffsetType i;
  ssize_t count;
  i = (((MagickOffsetType) radon_info->height) * x) + y;
  if ((i < 0) || (((MagickSizeType) (i * (sizeof(*radon_info->cells)))) >= radon_info->length))
    return MagickFalse;

  if (radon_info->type != DiskCache)
  {
    radon_info->cells[i] = value;
    return MagickTrue;
  }

  count = WriteRadonCell(radon_info, i * (sizeof(*radon_info->cells)), sizeof(*radon_info->cells), (const unsigned char *) (&value));
  if (count != ((ssize_t) (sizeof(*radon_info->cells))))
    return MagickFalse;

  return MagickTrue;
}


inline static unsigned short GetRadonCell(const RadonInfo *radon_info, const ssize_t x, const ssize_t y)
{
  MagickOffsetType i;
  unsigned short value;
  i = (((MagickOffsetType) radon_info->height) * x) + y;
  if ((i < 0) || (((MagickSizeType) (i * (sizeof(*radon_info->cells)))) >= radon_info->length))
    return 0;

  if (radon_info->type != DiskCache)
    return radon_info->cells[i];

  value = 0;
  (void) ReadRadonCell(radon_info, i * (sizeof(*radon_info->cells)), sizeof(*radon_info->cells), (unsigned char *) (&value));
  return value;
}


inline static unsigned short GetRadonCell(const RadonInfo *radon_info, const ssize_t x, const ssize_t y)
{
  MagickOffsetType i;
  unsigned short value;
  i = (((MagickOffsetType) radon_info->height) * x) + y;
  if ((i < 0) || (((MagickSizeType) (i * (sizeof(*radon_info->cells)))) >= radon_info->length))
    return 0;

  if (radon_info->type != DiskCache)
    return radon_info->cells[i];

  value = 0;
  (void) ReadRadonCell(radon_info, i * (sizeof(*radon_info->cells)), sizeof(*radon_info->cells), (unsigned char *) (&value));
  return value;
}


inline static MagickBooleanType SetRadonCell(const RadonInfo *radon_info, const ssize_t x, const ssize_t y, const unsigned short value)
{
  MagickOffsetType i;
  ssize_t count;
  i = (((MagickOffsetType) radon_info->height) * x) + y;
  if ((i < 0) || (((MagickSizeType) (i * (sizeof(*radon_info->cells)))) >= radon_info->length))
    return MagickFalse;

  if (radon_info->type != DiskCache)
  {
    radon_info->cells[i] = value;
    return MagickTrue;
  }

  count = WriteRadonCell(radon_info, i * (sizeof(*radon_info->cells)), sizeof(*radon_info->cells), (const unsigned char *) (&value));
  if (count != ((ssize_t) (sizeof(*radon_info->cells))))
    return MagickFalse;

  return MagickTrue;
}


inline static unsigned short GetRadonCell(const RadonInfo *radon_info, const ssize_t x, const ssize_t y)
{
  MagickOffsetType i;
  unsigned short value;
  i = (((MagickOffsetType) radon_info->height) * x) + y;
  if ((i < 0) || (((MagickSizeType) (i * (sizeof(*radon_info->cells)))) >= radon_info->length))
    return 0;

  if (radon_info->type != DiskCache)
    return radon_info->cells[i];

  value = 0;
  (void) ReadRadonCell(radon_info, i * (sizeof(*radon_info->cells)), sizeof(*radon_info->cells), (unsigned char *) (&value));
  return value;
}


inline static MagickBooleanType SetRadonCell(const RadonInfo *radon_info, const ssize_t x, const ssize_t y, const unsigned short value)
{
  MagickOffsetType i;
  ssize_t count;
  i = (((MagickOffsetType) radon_info->height) * x) + y;
  if ((i < 0) || (((MagickSizeType) (i * (sizeof(*radon_info->cells)))) >= radon_info->length))
    return MagickFalse;

  if (radon_info->type != DiskCache)
  {
    radon_info->cells[i] = value;
    return MagickTrue;
  }

  count = WriteRadonCell(radon_info, i * (sizeof(*radon_info->cells)), sizeof(*radon_info->cells), (const unsigned char *) (&value));
  if (count != ((ssize_t) (sizeof(*radon_info->cells))))
    return MagickFalse;

  return MagickTrue;
}


inline static unsigned short GetRadonCell(const RadonInfo *radon_info, const ssize_t x, const ssize_t y)
{
  MagickOffsetType i;
  unsigned short value;
  i = (((MagickOffsetType) radon_info->height) * x) + y;
  if ((i < 0) || (((MagickSizeType) (i * (sizeof(*radon_info->cells)))) >= radon_info->length))
    return 0;

  if (radon_info->type != DiskCache)
    return radon_info->cells[i];

  value = 0;
  (void) ReadRadonCell(radon_info, i * (sizeof(*radon_info->cells)), sizeof(*radon_info->cells), (unsigned char *) (&value));
  return value;
}


inline static MagickBooleanType SetRadonCell(const RadonInfo *radon_info, const ssize_t x, const ssize_t y, const unsigned short value)
{
  MagickOffsetType i;
  ssize_t count;
  i = (((MagickOffsetType) radon_info->height) * x) + y;
  if ((i < 0) || (((MagickSizeType) (i * (sizeof(*radon_info->cells)))) >= radon_info->length))
    return MagickFalse;

  if (radon_info->type != DiskCache)
  {
    radon_info->cells[i] = value;
    return MagickTrue;
  }

  count = WriteRadonCell(radon_info, i * (sizeof(*radon_info->cells)), sizeof(*radon_info->cells), (const unsigned char *) (&value));
  if (count != ((ssize_t) (sizeof(*radon_info->cells))))
    return MagickFalse;

  return MagickTrue;
}


inline static MagickBooleanType SetRadonCell(const RadonInfo *radon_info, const ssize_t x, const ssize_t y, const unsigned short value)
{
  MagickOffsetType i;
  ssize_t count;
  i = (((MagickOffsetType) radon_info->height) * x) + y;
  if ((i < 0) || (((MagickSizeType) (i * (sizeof(*radon_info->cells)))) >= radon_info->length))
    return MagickFalse;

  if (radon_info->type != DiskCache)
  {
    radon_info->cells[i] = value;
    return MagickTrue;
  }

  count = WriteRadonCell(radon_info, i * (sizeof(*radon_info->cells)), sizeof(*radon_info->cells), (const unsigned char *) (&value));
  if (count != ((ssize_t) (sizeof(*radon_info->cells))))
    return MagickFalse;

  return MagickTrue;
}

