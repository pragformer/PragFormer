for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register const PixelPacket * restrict p;
  register ssize_t i;
  register ssize_t x;
  size_t bit;
  size_t byte;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  if (p == ((const PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  bit = 0;
  byte = 0;
  i = 0;
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    byte <<= 1;
    if (((((MagickRealType) GetPixelRed(p)) < threshold) || (((MagickRealType) GetPixelGreen(p)) < threshold)) || (((MagickRealType) GetPixelBlue(p)) < threshold))
      byte |= 0x01;

    bit++;
    if (bit == 8)
    {
      (void) SetRadonCell(source_cells, i++, y, bits[byte]);
      bit = 0;
      byte = 0;
    }

    p++;
  }

  if (bit != 0)
  {
    byte <<= 8 - bit;
    (void) SetRadonCell(source_cells, i++, y, bits[byte]);
  }

}

inline static MagickBooleanType SetRadonCell(const RadonInfo *radon_info, const ssize_t x, const ssize_t y, const unsigned short value)
{
  MagickOffsetType i;
  ssize_t count;
  i = (((MagickOffsetType) radon_info->height) * x) + y;
  if ((i < 0) || (((MagickSizeType) (i * (sizeof(*radon_info->cells)))) >= radon_info->length))
    return MagickFalse;

  if (radon_info->type != DiskCache)
  {
    radon_info->cells[i] = value;
    return MagickTrue;
  }

  count = WriteRadonCell(radon_info, i * (sizeof(*radon_info->cells)), sizeof(*radon_info->cells), (const unsigned char *) (&value));
  if (count != ((ssize_t) (sizeof(*radon_info->cells))))
    return MagickFalse;

  return MagickTrue;
}


inline static MagickBooleanType SetRadonCell(const RadonInfo *radon_info, const ssize_t x, const ssize_t y, const unsigned short value)
{
  MagickOffsetType i;
  ssize_t count;
  i = (((MagickOffsetType) radon_info->height) * x) + y;
  if ((i < 0) || (((MagickSizeType) (i * (sizeof(*radon_info->cells)))) >= radon_info->length))
    return MagickFalse;

  if (radon_info->type != DiskCache)
  {
    radon_info->cells[i] = value;
    return MagickTrue;
  }

  count = WriteRadonCell(radon_info, i * (sizeof(*radon_info->cells)), sizeof(*radon_info->cells), (const unsigned char *) (&value));
  if (count != ((ssize_t) (sizeof(*radon_info->cells))))
    return MagickFalse;

  return MagickTrue;
}

