for (i = 0; i < ((ssize_t) GetOpenMPMaximumThreads()); i++)
  if (pixels[i] != ((RealPixelPacket *) 0))
  pixels[i] = (RealPixelPacket *) RelinquishMagickMemory(pixels[i]);


inline static size_t GetOpenMPMaximumThreads(void)
{
  static size_t maximum_threads = 1;
  return maximum_threads;
}

