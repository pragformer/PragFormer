for (i = 0; i <= (POLYBENCH_LOOP_BOUND(6, maxgrid) - 1); i++)
  path[0][i] = mean[0][i];
