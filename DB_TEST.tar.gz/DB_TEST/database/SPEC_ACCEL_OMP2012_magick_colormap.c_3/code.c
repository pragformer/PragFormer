for (i = 0; i < ((ssize_t) image->colors); i++)
{
  size_t pixel;
  pixel = (size_t) (i * (QuantumRange / MagickMax(colors - 1, 1)));
  image->colormap[i].red = (Quantum) pixel;
  image->colormap[i].green = (Quantum) pixel;
  image->colormap[i].blue = (Quantum) pixel;
  image->colormap[i].opacity = OpaqueOpacity;
}

inline static size_t MagickMax(const size_t x, const size_t y)
{
  if (x > y)
    return x;

  return y;
}

