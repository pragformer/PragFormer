for (i = 0; i <= ((ssize_t) CompositeChannels); i++)
  distortion[i] = 0.0;
