for (i = 0; i < ((ssize_t) image->colors); i++)
{
  if (grayscale != MagickFalse)
    if ((image->colormap[i].red != image->colormap[i].green) || (image->colormap[i].green != image->colormap[i].blue))
    continue;


  if ((channel & RedChannel) != 0)
    image->colormap[i].red = ((Quantum) QuantumRange) - image->colormap[i].red;

  if ((channel & GreenChannel) != 0)
    image->colormap[i].green = ((Quantum) QuantumRange) - image->colormap[i].green;

  if ((channel & BlueChannel) != 0)
    image->colormap[i].blue = ((Quantum) QuantumRange) - image->colormap[i].blue;

}
