for (y = (ssize_t) ceil(edge.y1 - 0.5); y <= ((ssize_t) floor(edge.y2 + 0.5)); y++)
{
  MagickPixelPacket composite;
  MagickPixelPacket pixel;
  PointInfo point;
  register IndexPacket * restrict indexes;
  register ssize_t x;
  register PixelPacket * restrict q;
  SegmentInfo inverse_edge;
  ssize_t x_offset;
  inverse_edge = AffineEdge(source, &inverse_affine, (double) y, &edge);
  if (inverse_edge.x2 < inverse_edge.x1)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, (ssize_t) ceil(inverse_edge.x1 - 0.5), y, (size_t) ((((ssize_t) floor(inverse_edge.x2 + 0.5)) - ((ssize_t) floor(inverse_edge.x1 + 0.5))) + 1), 1, exception);
  if (q == ((PixelPacket *) 0))
    continue;

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  pixel = zero;
  composite = zero;
  x_offset = 0;
  for (x = (ssize_t) ceil(inverse_edge.x1 - 0.5); x <= ((ssize_t) floor(inverse_edge.x2 + 0.5)); x++)
  {
    point.x = ((((double) x) * inverse_affine.sx) + (y * inverse_affine.ry)) + inverse_affine.tx;
    point.y = ((((double) x) * inverse_affine.rx) + (y * inverse_affine.sy)) + inverse_affine.ty;
    (void) InterpolateMagickPixelPacket(source, source_view, UndefinedInterpolatePixel, point.x, point.y, &pixel, exception);
    SetMagickPixelPacket(image, q, indexes + x_offset, &composite);
    MagickPixelCompositeOver(&pixel, pixel.opacity, &composite, composite.opacity, &composite);
    SetPixelPacket(image, &composite, q, indexes + x_offset);
    x_offset++;
    q++;
  }

  if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
    status = MagickFalse;

}

static SegmentInfo AffineEdge(const Image *image, const AffineMatrix *affine, const double y, const SegmentInfo *edge)
{
  double intercept;
  double z;
  register double x;
  SegmentInfo inverse_edge;
  inverse_edge.x1 = edge->x1;
  inverse_edge.y1 = edge->y1;
  inverse_edge.x2 = edge->x2;
  inverse_edge.y2 = edge->y2;
  z = (affine->ry * y) + affine->tx;
  if (affine->sx > MagickEpsilon)
  {
    intercept = (-z) / affine->sx;
    x = intercept + MagickEpsilon;
    if (x > inverse_edge.x1)
      inverse_edge.x1 = x;

    intercept = ((-z) + ((double) image->columns)) / affine->sx;
    x = intercept - MagickEpsilon;
    if (x < inverse_edge.x2)
      inverse_edge.x2 = x;

  }
  else
    if (affine->sx < (-MagickEpsilon))
  {
    intercept = ((-z) + ((double) image->columns)) / affine->sx;
    x = intercept + MagickEpsilon;
    if (x > inverse_edge.x1)
      inverse_edge.x1 = x;

    intercept = (-z) / affine->sx;
    x = intercept - MagickEpsilon;
    if (x < inverse_edge.x2)
      inverse_edge.x2 = x;

  }
  else
    if ((z < 0.0) || (((size_t) floor(z + 0.5)) >= image->columns))
  {
    inverse_edge.x2 = edge->x1;
    return inverse_edge;
  }



  z = (affine->sy * y) + affine->ty;
  if (affine->rx > MagickEpsilon)
  {
    intercept = (-z) / affine->rx;
    x = intercept + MagickEpsilon;
    if (x > inverse_edge.x1)
      inverse_edge.x1 = x;

    intercept = ((-z) + ((double) image->rows)) / affine->rx;
    x = intercept - MagickEpsilon;
    if (x < inverse_edge.x2)
      inverse_edge.x2 = x;

  }
  else
    if (affine->rx < (-MagickEpsilon))
  {
    intercept = ((-z) + ((double) image->rows)) / affine->rx;
    x = intercept + MagickEpsilon;
    if (x > inverse_edge.x1)
      inverse_edge.x1 = x;

    intercept = (-z) / affine->rx;
    x = intercept - MagickEpsilon;
    if (x < inverse_edge.x2)
      inverse_edge.x2 = x;

  }
  else
    if ((z < 0.0) || (((size_t) floor(z + 0.5)) >= image->rows))
  {
    inverse_edge.x2 = edge->x2;
    return inverse_edge;
  }



  return inverse_edge;
}


inline static void SetMagickPixelPacket(const Image *image, const PixelPacket *color, const IndexPacket *index, MagickPixelPacket *pixel)
{
  pixel->red = (MagickRealType) GetPixelRed(color);
  pixel->green = (MagickRealType) GetPixelGreen(color);
  pixel->blue = (MagickRealType) GetPixelBlue(color);
  pixel->opacity = (MagickRealType) GetPixelOpacity(color);
  if ((image->colorspace == CMYKColorspace) && (index != ((const IndexPacket *) 0)))
    pixel->index = (MagickRealType) GetPixelIndex(index);

}


inline static void MagickPixelCompositeOver(const MagickPixelPacket *p, const MagickRealType alpha, const MagickPixelPacket *q, const MagickRealType beta, MagickPixelPacket *composite)
{
  MagickRealType gamma;
  if (alpha == OpaqueOpacity)
  {
    *composite = *p;
    return;
  }

  gamma = 1.0 - (((QuantumScale * QuantumScale) * alpha) * beta);
  composite->opacity = ((MagickRealType) QuantumRange) * (1.0 - gamma);
  gamma = 1.0 / ((fabs(gamma) <= MagickEpsilon) ? (1.0) : (gamma));
  composite->red = gamma * MagickOver_(p->red, alpha, q->red, beta);
  composite->green = gamma * MagickOver_(p->green, alpha, q->green, beta);
  composite->blue = gamma * MagickOver_(p->blue, alpha, q->blue, beta);
  if (q->colorspace == CMYKColorspace)
    composite->index = gamma * MagickOver_(p->index, alpha, q->index, beta);

}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}

