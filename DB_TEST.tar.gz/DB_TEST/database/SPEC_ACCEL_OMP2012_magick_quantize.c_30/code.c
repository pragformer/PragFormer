for (i = 0; i <= ((ssize_t) MaxMap); i++)
  colormap_index[i] = -1;
