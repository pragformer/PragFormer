for (i = 0; i < ((ssize_t) number_grays); i++)
  Q[i] = (ChannelStatistics *) RelinquishMagickMemory(Q[i]);
