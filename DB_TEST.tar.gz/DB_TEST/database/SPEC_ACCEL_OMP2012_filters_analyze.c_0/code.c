for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register const PixelPacket *p;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  if (p == ((const PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    ConvertRGBToHSB(GetPixelRed(p), GetPixelGreen(p), GetPixelBlue(p), &hue, &saturation, &brightness);
    brightness *= QuantumRange;
    brightness_sum_x += brightness;
    brightness_sum_x2 += brightness * brightness;
    brightness_sum_x3 += (brightness * brightness) * brightness;
    brightness_sum_x4 += ((brightness * brightness) * brightness) * brightness;
    saturation *= QuantumRange;
    saturation_sum_x += saturation;
    saturation_sum_x2 += saturation * saturation;
    saturation_sum_x3 += (saturation * saturation) * saturation;
    saturation_sum_x4 += ((saturation * saturation) * saturation) * saturation;
    area++;
    p++;
  }

}
