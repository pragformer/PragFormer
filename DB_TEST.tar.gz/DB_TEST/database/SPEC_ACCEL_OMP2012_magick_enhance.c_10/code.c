for (i = 0; i < ((ssize_t) image->colors); i++)
{
  if ((channel & RedChannel) != 0)
    image->colormap[i].red = ClampToQuantum((((MagickRealType) pow((double) ((((double) 1.0) / ((double) QuantumRange)) * image->colormap[i].red), 1.0 / gamma)) * (white_point - black_point)) + black_point);

  if ((channel & GreenChannel) != 0)
    image->colormap[i].green = ClampToQuantum((((MagickRealType) pow((double) ((((double) 1.0) / ((double) QuantumRange)) * image->colormap[i].green), 1.0 / gamma)) * (white_point - black_point)) + black_point);

  if ((channel & BlueChannel) != 0)
    image->colormap[i].blue = ClampToQuantum((((MagickRealType) pow((double) ((((double) 1.0) / ((double) QuantumRange)) * image->colormap[i].blue), 1.0 / gamma)) * (white_point - black_point)) + black_point);

  if ((channel & OpacityChannel) != 0)
    image->colormap[i].opacity = ClampToQuantum((((MagickRealType) pow((double) ((((double) 1.0) / ((double) QuantumRange)) * image->colormap[i].opacity), 1.0 / gamma)) * (white_point - black_point)) + black_point);

}

inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}

