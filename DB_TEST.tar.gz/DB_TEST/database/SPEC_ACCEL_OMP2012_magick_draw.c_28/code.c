for (i = 1; i < ((ssize_t) polygon_info[0]->number_edges); i++)
{
  p = polygon_info[0]->edges + i;
  if (p->bounds.x1 < bounds.x1)
    bounds.x1 = p->bounds.x1;

  if (p->bounds.y1 < bounds.y1)
    bounds.y1 = p->bounds.y1;

  if (p->bounds.x2 > bounds.x2)
    bounds.x2 = p->bounds.x2;

  if (p->bounds.y2 > bounds.y2)
    bounds.y2 = p->bounds.y2;

}
