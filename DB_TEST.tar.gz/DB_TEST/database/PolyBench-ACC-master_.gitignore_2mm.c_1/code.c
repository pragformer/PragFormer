for (i = 0; i < POLYBENCH_LOOP_BOUND(1024, ni); i++)
  for (j = 0; j < POLYBENCH_LOOP_BOUND(1024, nl); j++)
{
  D[i][j] *= beta;
  for (k = 0; k < POLYBENCH_LOOP_BOUND(1024, nj); ++k)
    D[i][j] += tmp[i][k] * C[k][j];

}

