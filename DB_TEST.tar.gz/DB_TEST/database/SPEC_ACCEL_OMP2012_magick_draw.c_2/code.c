for (y = (ssize_t) ceil(bounds.y1 - 0.5); y <= ((ssize_t) floor(bounds.y2 + 0.5)); y++)
{
  MagickBooleanType sync;
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  x = start;
  q = GetCacheViewAuthenticPixels(image_view, x, y, (size_t) ((stop - x) + 1), 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  for (; x <= stop; x++)
  {
    if ((x == ((ssize_t) ceil(primitive_info->point.x - 0.5))) && (y == ((ssize_t) ceil(primitive_info->point.y - 0.5))))
      (void) GetStrokeColor(draw_info, x, y, q);

    q++;
  }

  sync = SyncCacheViewAuthenticPixels(image_view, exception);
  if (sync == MagickFalse)
    status = MagickFalse;

}

inline static MagickBooleanType GetStrokeColor(const DrawInfo *draw_info, const ssize_t x, const ssize_t y, PixelPacket *pixel)
{
  Image *pattern;
  MagickBooleanType status;
  pattern = draw_info->stroke_pattern;
  if (pattern == ((Image *) 0))
  {
    *pixel = draw_info->stroke;
    return MagickTrue;
  }

  status = GetOneVirtualMethodPixel(pattern, TileVirtualPixelMethod, x + pattern->tile_offset.x, y + pattern->tile_offset.y, pixel, &pattern->exception);
  if (pattern->matte == MagickFalse)
    pixel->opacity = OpaqueOpacity;

  return status;
}

