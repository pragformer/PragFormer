for (y = 0; y < ((ssize_t) fx_image->rows); y++)
{
  const int id = GetOpenMPThreadId();
  MagickRealType alpha;
  register IndexPacket * restrict fx_indexes;
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(fx_view, 0, y, fx_image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  fx_indexes = GetCacheViewAuthenticIndexQueue(fx_view);
  alpha = 0.0;
  for (x = 0; x < ((ssize_t) fx_image->columns); x++)
  {
    if ((channel & RedChannel) != 0)
    {
      (void) FxEvaluateChannelExpression(fx_info[id], RedChannel, x, y, &alpha, exception);
      SetPixelRed(q, ClampToQuantum(((MagickRealType) QuantumRange) * alpha));
    }

    if ((channel & GreenChannel) != 0)
    {
      (void) FxEvaluateChannelExpression(fx_info[id], GreenChannel, x, y, &alpha, exception);
      SetPixelGreen(q, ClampToQuantum(((MagickRealType) QuantumRange) * alpha));
    }

    if ((channel & BlueChannel) != 0)
    {
      (void) FxEvaluateChannelExpression(fx_info[id], BlueChannel, x, y, &alpha, exception);
      SetPixelBlue(q, ClampToQuantum(((MagickRealType) QuantumRange) * alpha));
    }

    if ((channel & OpacityChannel) != 0)
    {
      (void) FxEvaluateChannelExpression(fx_info[id], OpacityChannel, x, y, &alpha, exception);
      if (image->matte == MagickFalse)
        SetPixelOpacity(q, ClampToQuantum(((MagickRealType) QuantumRange) * alpha));
      else
        SetPixelOpacity(q, ClampToQuantum((MagickRealType) (QuantumRange - (QuantumRange * alpha))));

    }

    if (((channel & IndexChannel) != 0) && (fx_image->colorspace == CMYKColorspace))
    {
      (void) FxEvaluateChannelExpression(fx_info[id], IndexChannel, x, y, &alpha, exception);
      SetPixelIndex(fx_indexes + x, ClampToQuantum(((MagickRealType) QuantumRange) * alpha));
    }

    q++;
  }

  if (SyncCacheViewAuthenticPixels(fx_view, exception) == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_FxImageChannel)
    proceed = SetImageProgress(image, "Fx/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static int GetOpenMPThreadId(void)
{
  return 0;
}


MagickBooleanType FxEvaluateChannelExpression(FxInfo *fx_info, const ChannelType channel, const ssize_t x, const ssize_t y, MagickRealType *alpha, ExceptionInfo *exception)
{
  MagickRealType beta;
  beta = 0.0;
  *alpha = FxEvaluateSubexpression(fx_info, channel, x, y, fx_info->expression, &beta, exception);
  return (exception->severity == OptionError) ? (MagickFalse) : (MagickTrue);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


MagickBooleanType FxEvaluateChannelExpression(FxInfo *fx_info, const ChannelType channel, const ssize_t x, const ssize_t y, MagickRealType *alpha, ExceptionInfo *exception)
{
  MagickRealType beta;
  beta = 0.0;
  *alpha = FxEvaluateSubexpression(fx_info, channel, x, y, fx_info->expression, &beta, exception);
  return (exception->severity == OptionError) ? (MagickFalse) : (MagickTrue);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


MagickBooleanType FxEvaluateChannelExpression(FxInfo *fx_info, const ChannelType channel, const ssize_t x, const ssize_t y, MagickRealType *alpha, ExceptionInfo *exception)
{
  MagickRealType beta;
  beta = 0.0;
  *alpha = FxEvaluateSubexpression(fx_info, channel, x, y, fx_info->expression, &beta, exception);
  return (exception->severity == OptionError) ? (MagickFalse) : (MagickTrue);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


MagickBooleanType FxEvaluateChannelExpression(FxInfo *fx_info, const ChannelType channel, const ssize_t x, const ssize_t y, MagickRealType *alpha, ExceptionInfo *exception)
{
  MagickRealType beta;
  beta = 0.0;
  *alpha = FxEvaluateSubexpression(fx_info, channel, x, y, fx_info->expression, &beta, exception);
  return (exception->severity == OptionError) ? (MagickFalse) : (MagickTrue);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


MagickBooleanType FxEvaluateChannelExpression(FxInfo *fx_info, const ChannelType channel, const ssize_t x, const ssize_t y, MagickRealType *alpha, ExceptionInfo *exception)
{
  MagickRealType beta;
  beta = 0.0;
  *alpha = FxEvaluateSubexpression(fx_info, channel, x, y, fx_info->expression, &beta, exception);
  return (exception->severity == OptionError) ? (MagickFalse) : (MagickTrue);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

