for (i = 0; i < POLYBENCH_LOOP_BOUND(1024, ni); i++)
  for (j = 0; j < POLYBENCH_LOOP_BOUND(1024, nj); j++)
{
  E[i][j] = 0;
  for (k = 0; k < POLYBENCH_LOOP_BOUND(1024, nk); ++k)
    E[i][j] += A[i][k] * B[k][j];

}

