for (i1 = 0; i1 < POLYBENCH_LOOP_BOUND(1024, n); i1++)
  for (i2 = 1; i2 < POLYBENCH_LOOP_BOUND(1024, n); i2++)
{
  X[i1][i2] = X[i1][i2] - ((X[i1][i2 - 1] * A[i1][i2]) / B[i1][i2 - 1]);
  B[i1][i2] = B[i1][i2] - ((A[i1][i2] * A[i1][i2]) / B[i1][i2 - 1]);
}

