for (i = 0; i < ((ssize_t) GetOpenMPMaximumThreads()); i++)
  if (polygon_info[i] != ((PolygonInfo *) 0))
  polygon_info[i] = DestroyPolygonInfo(polygon_info[i]);


inline static size_t GetOpenMPMaximumThreads(void)
{
  static size_t maximum_threads = 1;
  return maximum_threads;
}


static PolygonInfo *DestroyPolygonInfo(PolygonInfo *polygon_info)
{
  register ssize_t i;
  for (i = 0; i < ((ssize_t) polygon_info->number_edges); i++)
    polygon_info->edges[i].points = (PointInfo *) RelinquishMagickMemory(polygon_info->edges[i].points);

  polygon_info->edges = (EdgeInfo *) RelinquishMagickMemory(polygon_info->edges);
  return (PolygonInfo *) RelinquishMagickMemory(polygon_info);
}

