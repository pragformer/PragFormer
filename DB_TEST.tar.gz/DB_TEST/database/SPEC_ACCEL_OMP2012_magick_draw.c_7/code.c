for (i = 0; i < ((ssize_t) polygon_info->number_edges); i++)
{
  (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 419, "      edge %.20g:", (double) i);
  (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 421, "      direction: %s", (p->direction != MagickFalse) ? ("down") : ("up"));
  (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 423, "      ghostline: %s", (p->ghostline != MagickFalse) ? ("transparent") : ("opaque"));
  (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 425, "      bounds: %g %g - %g %g", p->bounds.x1, p->bounds.y1, p->bounds.x2, p->bounds.y2);
  for (j = 0; j < ((ssize_t) p->number_points); j++)
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 429, "        %g %g", p->points[j].x, p->points[j].y);

  p++;
}
