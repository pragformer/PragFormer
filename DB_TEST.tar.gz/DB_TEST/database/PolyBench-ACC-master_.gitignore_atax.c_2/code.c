for (i = 0; i < ny; i++)
  x[i] = i * M_PI;
