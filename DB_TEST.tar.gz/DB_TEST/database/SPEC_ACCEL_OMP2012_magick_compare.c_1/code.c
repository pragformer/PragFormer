for (y = 0; y < ((ssize_t) image->rows); y++)
{
  double channel_distortion[CompositeChannels + 1];
  MagickPixelPacket pixel;
  MagickPixelPacket reconstruct_pixel;
  register const IndexPacket * restrict indexes;
  register const IndexPacket * restrict reconstruct_indexes;
  register const PixelPacket * restrict p;
  register const PixelPacket * restrict q;
  register ssize_t i;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  q = GetCacheViewVirtualPixels(reconstruct_view, 0, y, reconstruct_image->columns, 1, exception);
  if ((p == ((const PixelPacket *) 0)) || (q == ((const PixelPacket *) 0)))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewVirtualIndexQueue(image_view);
  reconstruct_indexes = GetCacheViewVirtualIndexQueue(reconstruct_view);
  pixel = zero;
  reconstruct_pixel = pixel;
  (void) ResetMagickMemory(channel_distortion, 0, sizeof(channel_distortion));
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    SetMagickPixelPacket(image, p, indexes + x, &pixel);
    SetMagickPixelPacket(reconstruct_image, q, reconstruct_indexes + x, &reconstruct_pixel);
    if (IsMagickColorSimilar(&pixel, &reconstruct_pixel) == MagickFalse)
    {
      if ((channel & RedChannel) != 0)
        channel_distortion[RedChannel]++;

      if ((channel & GreenChannel) != 0)
        channel_distortion[GreenChannel]++;

      if ((channel & BlueChannel) != 0)
        channel_distortion[BlueChannel]++;

      if (((channel & OpacityChannel) != 0) && (image->matte != MagickFalse))
        channel_distortion[OpacityChannel]++;

      if (((channel & IndexChannel) != 0) && (image->colorspace == CMYKColorspace))
        channel_distortion[BlackChannel]++;

      channel_distortion[CompositeChannels]++;
    }

    p++;
    q++;
  }

  #pragma omp critical (MagickCore_GetAbsoluteError)
  for (i = 0; i <= ((ssize_t) CompositeChannels); i++)
    distortion[i] += channel_distortion[i];

}

inline static void SetMagickPixelPacket(const Image *image, const PixelPacket *color, const IndexPacket *index, MagickPixelPacket *pixel)
{
  pixel->red = (MagickRealType) GetPixelRed(color);
  pixel->green = (MagickRealType) GetPixelGreen(color);
  pixel->blue = (MagickRealType) GetPixelBlue(color);
  pixel->opacity = (MagickRealType) GetPixelOpacity(color);
  if ((image->colorspace == CMYKColorspace) && (index != ((const IndexPacket *) 0)))
    pixel->index = (MagickRealType) GetPixelIndex(index);

}


inline static void SetMagickPixelPacket(const Image *image, const PixelPacket *color, const IndexPacket *index, MagickPixelPacket *pixel)
{
  pixel->red = (MagickRealType) GetPixelRed(color);
  pixel->green = (MagickRealType) GetPixelGreen(color);
  pixel->blue = (MagickRealType) GetPixelBlue(color);
  pixel->opacity = (MagickRealType) GetPixelOpacity(color);
  if ((image->colorspace == CMYKColorspace) && (index != ((const IndexPacket *) 0)))
    pixel->index = (MagickRealType) GetPixelIndex(index);

}

