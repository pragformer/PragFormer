for (i = ((ssize_t) n) + 1; i < ((ssize_t) number_vertices); i++)
{
  dx.q = polygon_primitive[i].point.x - polygon_primitive[n].point.x;
  dy.q = polygon_primitive[i].point.y - polygon_primitive[n].point.y;
  dot_product = (dx.q * dx.q) + (dy.q * dy.q);
  if (dot_product < 0.25)
    continue;

  slope.q = 0.0;
  inverse_slope.q = 0.0;
  if (fabs(dx.q) < MagickEpsilon)
  {
    if (dx.q >= 0.0)
      slope.q = (dy.q < 0.0) ? ((-1.0) / MagickEpsilon) : (1.0 / MagickEpsilon);
    else
      slope.q = (dy.q < 0.0) ? (1.0 / MagickEpsilon) : ((-1.0) / MagickEpsilon);

  }
  else
    if (fabs(dy.q) <= MagickEpsilon)
  {
    if (dy.q >= 0.0)
      inverse_slope.q = (dx.q < 0.0) ? ((-1.0) / MagickEpsilon) : (1.0 / MagickEpsilon);
    else
      inverse_slope.q = (dx.q < 0.0) ? (1.0 / MagickEpsilon) : ((-1.0) / MagickEpsilon);

  }
  else
  {
    slope.q = dy.q / dx.q;
    inverse_slope.q = (-1.0) / slope.q;
  }


  offset.x = sqrt((double) ((mid * mid) / ((inverse_slope.q * inverse_slope.q) + 1.0)));
  offset.y = (double) (offset.x * inverse_slope.q);
  dot_product = (dy.q * offset.x) - (dx.q * offset.y);
  if (dot_product > 0.0)
  {
    box_p[2].x = polygon_primitive[n].point.x - offset.x;
    box_p[2].y = polygon_primitive[n].point.y - offset.y;
    box_p[3].x = polygon_primitive[i].point.x - offset.x;
    box_p[3].y = polygon_primitive[i].point.y - offset.y;
    box_q[2].x = polygon_primitive[n].point.x + offset.x;
    box_q[2].y = polygon_primitive[n].point.y + offset.y;
    box_q[3].x = polygon_primitive[i].point.x + offset.x;
    box_q[3].y = polygon_primitive[i].point.y + offset.y;
  }
  else
  {
    box_p[2].x = polygon_primitive[n].point.x + offset.x;
    box_p[2].y = polygon_primitive[n].point.y + offset.y;
    box_p[3].x = polygon_primitive[i].point.x + offset.x;
    box_p[3].y = polygon_primitive[i].point.y + offset.y;
    box_q[2].x = polygon_primitive[n].point.x - offset.x;
    box_q[2].y = polygon_primitive[n].point.y - offset.y;
    box_q[3].x = polygon_primitive[i].point.x - offset.x;
    box_q[3].y = polygon_primitive[i].point.y - offset.y;
  }

  if (fabs((double) (slope.p - slope.q)) <= MagickEpsilon)
  {
    box_p[4] = box_p[1];
    box_q[4] = box_q[1];
  }
  else
  {
    box_p[4].x = (double) (((((slope.p * box_p[0].x) - box_p[0].y) - (slope.q * box_p[3].x)) + box_p[3].y) / (slope.p - slope.q));
    box_p[4].y = (double) ((slope.p * (box_p[4].x - box_p[0].x)) + box_p[0].y);
    box_q[4].x = (double) (((((slope.p * box_q[0].x) - box_q[0].y) - (slope.q * box_q[3].x)) + box_q[3].y) / (slope.p - slope.q));
    box_q[4].y = (double) ((slope.p * (box_q[4].x - box_q[0].x)) + box_q[0].y);
  }

  if (q >= ((ssize_t) ((max_strokes - (6 * 200)) - 360)))
  {
    max_strokes += (6 * 200) + 360;
    path_p = (PointInfo *) ResizeQuantumMemory(path_p, (size_t) max_strokes, sizeof(*path_p));
    path_q = (PointInfo *) ResizeQuantumMemory(path_q, (size_t) max_strokes, sizeof(*path_q));
    if ((path_p == ((PointInfo *) 0)) || (path_q == ((PointInfo *) 0)))
    {
      polygon_primitive = (PrimitiveInfo *) RelinquishMagickMemory(polygon_primitive);
      return (PrimitiveInfo *) 0;
    }

  }

  dot_product = (dx.q * dy.p) - (dx.p * dy.q);
  if (dot_product <= 0.0)
    switch (draw_info->linejoin)
  {
    case BevelJoin:
    {
      path_q[q++] = box_q[1];
      path_q[q++] = box_q[2];
      dot_product = ((box_q[4].x - box_p[4].x) * (box_q[4].x - box_p[4].x)) + ((box_q[4].y - box_p[4].y) * (box_q[4].y - box_p[4].y));
      if (dot_product <= miterlimit)
        path_p[p++] = box_p[4];
      else
      {
        path_p[p++] = box_p[1];
        path_p[p++] = box_p[2];
      }

      break;
    }

    case MiterJoin:
    {
      dot_product = ((box_q[4].x - box_p[4].x) * (box_q[4].x - box_p[4].x)) + ((box_q[4].y - box_p[4].y) * (box_q[4].y - box_p[4].y));
      if (dot_product <= miterlimit)
      {
        path_q[q++] = box_q[4];
        path_p[p++] = box_p[4];
      }
      else
      {
        path_q[q++] = box_q[1];
        path_q[q++] = box_q[2];
        path_p[p++] = box_p[1];
        path_p[p++] = box_p[2];
      }

      break;
    }

    case RoundJoin:
    {
      dot_product = ((box_q[4].x - box_p[4].x) * (box_q[4].x - box_p[4].x)) + ((box_q[4].y - box_p[4].y) * (box_q[4].y - box_p[4].y));
      if (dot_product <= miterlimit)
        path_p[p++] = box_p[4];
      else
      {
        path_p[p++] = box_p[1];
        path_p[p++] = box_p[2];
      }

      center = polygon_primitive[n].point;
      theta.p = atan2(box_q[1].y - center.y, box_q[1].x - center.x);
      theta.q = atan2(box_q[2].y - center.y, box_q[2].x - center.x);
      if (theta.q < theta.p)
        theta.q += (MagickRealType) (2.0 * 3.14159265358979323846264338327950288419716939937510L);

      arc_segments = (size_t) ceil((double) ((theta.q - theta.p) / (2.0 * sqrt((double) (1.0 / mid)))));
      path_q[q].x = box_q[1].x;
      path_q[q].y = box_q[1].y;
      q++;
      for (j = 1; j < ((ssize_t) arc_segments); j++)
      {
        delta_theta = (MagickRealType) ((j * (theta.q - theta.p)) / arc_segments);
        path_q[q].x = (double) (center.x + (mid * cos(fmod((double) (theta.p + delta_theta), DegreesToRadians(360.0)))));
        path_q[q].y = (double) (center.y + (mid * sin(fmod((double) (theta.p + delta_theta), DegreesToRadians(360.0)))));
        q++;
      }

      path_q[q++] = box_q[2];
      break;
    }

    default:
      break;

  }

  else
    switch (draw_info->linejoin)
  {
    case BevelJoin:
    {
      path_p[p++] = box_p[1];
      path_p[p++] = box_p[2];
      dot_product = ((box_q[4].x - box_p[4].x) * (box_q[4].x - box_p[4].x)) + ((box_q[4].y - box_p[4].y) * (box_q[4].y - box_p[4].y));
      if (dot_product <= miterlimit)
        path_q[q++] = box_q[4];
      else
      {
        path_q[q++] = box_q[1];
        path_q[q++] = box_q[2];
      }

      break;
    }

    case MiterJoin:
    {
      dot_product = ((box_q[4].x - box_p[4].x) * (box_q[4].x - box_p[4].x)) + ((box_q[4].y - box_p[4].y) * (box_q[4].y - box_p[4].y));
      if (dot_product <= miterlimit)
      {
        path_q[q++] = box_q[4];
        path_p[p++] = box_p[4];
      }
      else
      {
        path_q[q++] = box_q[1];
        path_q[q++] = box_q[2];
        path_p[p++] = box_p[1];
        path_p[p++] = box_p[2];
      }

      break;
    }

    case RoundJoin:
    {
      dot_product = ((box_q[4].x - box_p[4].x) * (box_q[4].x - box_p[4].x)) + ((box_q[4].y - box_p[4].y) * (box_q[4].y - box_p[4].y));
      if (dot_product <= miterlimit)
        path_q[q++] = box_q[4];
      else
      {
        path_q[q++] = box_q[1];
        path_q[q++] = box_q[2];
      }

      center = polygon_primitive[n].point;
      theta.p = atan2(box_p[1].y - center.y, box_p[1].x - center.x);
      theta.q = atan2(box_p[2].y - center.y, box_p[2].x - center.x);
      if (theta.p < theta.q)
        theta.p += (MagickRealType) (2.0 * 3.14159265358979323846264338327950288419716939937510L);

      arc_segments = (size_t) ceil((double) ((theta.p - theta.q) / (2.0 * sqrt((double) (1.0 / mid)))));
      path_p[p++] = box_p[1];
      for (j = 1; j < ((ssize_t) arc_segments); j++)
      {
        delta_theta = (MagickRealType) ((j * (theta.q - theta.p)) / arc_segments);
        path_p[p].x = (double) (center.x + (mid * cos(fmod((double) (theta.p + delta_theta), DegreesToRadians(360.0)))));
        path_p[p].y = (double) (center.y + (mid * sin(fmod((double) (theta.p + delta_theta), DegreesToRadians(360.0)))));
        p++;
      }

      path_p[p++] = box_p[2];
      break;
    }

    default:
      break;

  }


  slope.p = slope.q;
  inverse_slope.p = inverse_slope.q;
  box_p[0] = box_p[2];
  box_p[1] = box_p[3];
  box_q[0] = box_q[2];
  box_q[1] = box_q[3];
  dx.p = dx.q;
  dy.p = dy.q;
  n = i;
}

inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}

