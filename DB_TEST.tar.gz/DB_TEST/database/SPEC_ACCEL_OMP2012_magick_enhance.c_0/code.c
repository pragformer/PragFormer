for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  cdl_map[i].red = ClampToQuantum((MagickRealType) ScaleMapToQuantum((MagickRealType) (MaxMap * pow(((color_correction.red.slope * i) / MaxMap) + color_correction.red.offset, color_correction.red.power))));
  cdl_map[i].green = ClampToQuantum((MagickRealType) ScaleMapToQuantum((MagickRealType) (MaxMap * pow(((color_correction.green.slope * i) / MaxMap) + color_correction.green.offset, color_correction.green.power))));
  cdl_map[i].blue = ClampToQuantum((MagickRealType) ScaleMapToQuantum((MagickRealType) (MaxMap * pow(((color_correction.blue.slope * i) / MaxMap) + color_correction.blue.offset, color_correction.blue.power))));
}

inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}

