for (i = 0; i < ((ssize_t) length); i += count)
{
  count = read(radon_info->file, buffer + i, MagickMin(length - i, (size_t) SSIZE_MAX));
  if (count > 0)
    continue;

  count = 0;
  if (errno != EINTR)
  {
    i = -1;
    break;
  }

}

inline static size_t MagickMin(const size_t x, const size_t y)
{
  if (x < y)
    return x;

  return y;
}

