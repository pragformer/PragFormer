for (i = 0; primitive_info[i].primitive != UndefinedPrimitive; i++)
{
  code = LineToCode;
  if (coordinates <= 0)
  {
    coordinates = (ssize_t) primitive_info[i].coordinates;
    p = primitive_info[i].point;
    start = n;
    code = MoveToCode;
  }

  coordinates--;
  if (((i == 0) || (fabs(q.x - primitive_info[i].point.x) > MagickEpsilon)) || (fabs(q.y - primitive_info[i].point.y) > MagickEpsilon))
  {
    path_info[n].code = code;
    path_info[n].point = primitive_info[i].point;
    q = primitive_info[i].point;
    n++;
  }

  if (coordinates > 0)
    continue;

  if ((fabs(p.x - primitive_info[i].point.x) <= MagickEpsilon) && (fabs(p.y - primitive_info[i].point.y) <= MagickEpsilon))
    continue;

  path_info[start].code = OpenCode;
  path_info[n].code = GhostlineCode;
  path_info[n].point = primitive_info[i].point;
  n++;
  path_info[n].code = LineToCode;
  path_info[n].point = p;
  n++;
}
