for (; i < ((ssize_t) ((reference_white * MaxMap) / 1024.0)); i++)
  logmap[i] = ClampToQuantum((((MagickRealType) QuantumRange) / (1.0 - black)) * (pow(10.0, (((((1024.0 * i) / MaxMap) - reference_white) * (gamma / density)) * 0.002) / film_gamma) - black));

inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}

