for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register IndexPacket * restrict indexes;
  register ssize_t x;
  register PixelPacket * restrict q;
  ssize_t index;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    index = ((ssize_t) (GetPixelIndex(indexes + x) + displace)) % image->colors;
    if (index < 0)
      index += (ssize_t) image->colors;

    SetPixelIndex(indexes + x, index);
    SetPixelRGBO(q, image->colormap + ((ssize_t) index));
    q++;
  }

  if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
    status = MagickFalse;

}
