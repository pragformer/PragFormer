for (y = 0; y < ((ssize_t) flop_image->rows); y++)
{
  register const IndexPacket * restrict indexes;
  register const PixelPacket * restrict p;
  register IndexPacket * restrict flop_indexes;
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  q = QueueCacheViewAuthenticPixels(flop_view, 0, y, flop_image->columns, 1, exception);
  if ((p == ((PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
  {
    status = MagickFalse;
    continue;
  }

  q += flop_image->columns;
  indexes = GetCacheViewVirtualIndexQueue(image_view);
  flop_indexes = GetCacheViewAuthenticIndexQueue(flop_view);
  for (x = 0; x < ((ssize_t) flop_image->columns); x++)
  {
    *(--q) = *(p++);
    if ((indexes != ((const IndexPacket *) 0)) && (flop_indexes != ((IndexPacket *) 0)))
      SetPixelIndex(((flop_indexes + flop_image->columns) - x) - 1, GetPixelIndex(indexes + x));

  }

  if (SyncCacheViewAuthenticPixels(flop_view, exception) == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_FlopImage)
    proceed = SetImageProgress(image, "Flop/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

