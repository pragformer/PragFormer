for (i = 0; i < ((ssize_t) number_coordinates); i++)
{
  q--;
  q->primitive = primitive_type;
  if (z_count > 1)
    q->method = FillToBorderMethod;

}
