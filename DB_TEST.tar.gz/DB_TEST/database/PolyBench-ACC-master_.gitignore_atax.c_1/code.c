for (i = 0; i < POLYBENCH_LOOP_BOUND(4000, nx); i++)
{
  tmp[i] = 0;
  for (j = 0; j < POLYBENCH_LOOP_BOUND(4000, ny); j++)
    tmp[i] = tmp[i] + (A[i][j] * x[j]);

  for (j = 0; j < POLYBENCH_LOOP_BOUND(4000, ny); j++)
    y[j] = y[j] + (A[i][j] * tmp[i]);

}
