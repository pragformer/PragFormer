for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  grays[i].red = ~0U;
  grays[i].green = ~0U;
  grays[i].blue = ~0U;
  grays[i].opacity = ~0U;
  grays[i].index = ~0U;
}
