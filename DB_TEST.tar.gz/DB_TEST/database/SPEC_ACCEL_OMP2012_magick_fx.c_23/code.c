for (y = 0; y < ((ssize_t) image->rows); y++)
{
  MagickPixelPacket pixel;
  MagickRealType distance;
  PointInfo delta;
  register IndexPacket * restrict implode_indexes;
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(implode_view, 0, y, implode_image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  implode_indexes = GetCacheViewAuthenticIndexQueue(implode_view);
  delta.y = scale.y * ((double) (y - center.y));
  pixel = zero;
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    delta.x = scale.x * ((double) (x - center.x));
    distance = (delta.x * delta.x) + (delta.y * delta.y);
    if (distance < (radius * radius))
    {
      double factor;
      factor = 1.0;
      if (distance > 0.0)
        factor = pow(sin((double) (((3.14159265358979323846264338327950288419716939937510L * sqrt((double) distance)) / radius) / 2)), -amount);

      (void) InterpolateMagickPixelPacket(image, image_view, UndefinedInterpolatePixel, (double) (((factor * delta.x) / scale.x) + center.x), (double) (((factor * delta.y) / scale.y) + center.y), &pixel, exception);
      SetPixelPacket(implode_image, &pixel, q, implode_indexes + x);
    }

    q++;
  }

  if (SyncCacheViewAuthenticPixels(implode_view, exception) == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_ImplodeImage)
    proceed = SetImageProgress(image, "Implode/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

