for (i = 0; i < n; i++)
{
  p[i] = 1.0 / n;
  for (j = 0; j < n; j++)
    A[i][j] = 1.0 / n;

}
