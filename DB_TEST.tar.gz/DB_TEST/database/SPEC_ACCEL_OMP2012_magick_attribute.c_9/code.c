for (y = 0; y < ((ssize_t) image->rows); y++)
{
  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  if (p == ((const PixelPacket *) 0))
    break;

  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    if (IsMonochromePixel(p) == MagickFalse)
    {
      type = UndefinedType;
      break;
    }

    p++;
  }

  if (type == UndefinedType)
    break;

}

inline static MagickBooleanType IsMonochromePixel(const PixelPacket *pixel)
{
  if ((((pixel->red == 0) || (pixel->red == ((Quantum) QuantumRange))) && (pixel->red == pixel->green)) && (pixel->green == pixel->blue))
    return MagickTrue;

  return MagickFalse;
}

