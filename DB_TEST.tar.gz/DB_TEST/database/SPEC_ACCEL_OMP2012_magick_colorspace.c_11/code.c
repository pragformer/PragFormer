for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  x_map[i].x = 0.21260f * ((MagickRealType) i);
  y_map[i].x = 0.71520f * ((MagickRealType) i);
  z_map[i].x = 0.07220f * ((MagickRealType) i);
  x_map[i].y = 0.21260f * ((MagickRealType) i);
  y_map[i].y = 0.71520f * ((MagickRealType) i);
  z_map[i].y = 0.07220f * ((MagickRealType) i);
  x_map[i].z = 0.21260f * ((MagickRealType) i);
  y_map[i].z = 0.71520f * ((MagickRealType) i);
  z_map[i].z = 0.07220f * ((MagickRealType) i);
}
