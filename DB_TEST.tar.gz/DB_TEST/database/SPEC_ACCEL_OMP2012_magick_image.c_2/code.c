for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register IndexPacket * restrict indexes;
  register PixelPacket * restrict q;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    if (q->opacity == TransparentOpacity)
    {
      SetPixelRed(q, pixel.red);
      SetPixelGreen(q, pixel.green);
      SetPixelBlue(q, pixel.blue);
    }

    q++;
  }

  if (image->colorspace == CMYKColorspace)
  {
    indexes = GetCacheViewAuthenticIndexQueue(image_view);
    for (x = 0; x < ((ssize_t) image->columns); x++)
      SetPixelIndex(indexes + x, index);

  }

  if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
    status = MagickFalse;

}
