for (i = 0; i < nx; i++)
  for (j = 0; j < ny; j++)
{
  fprintf(stderr, "%0.2lf ", ex[i][j]);
  fprintf(stderr, "%0.2lf ", ey[i][j]);
  fprintf(stderr, "%0.2lf ", hz[i][j]);
  if ((((i * nx) + j) % 20) == 0)
    fprintf(stderr, "\n");

}

