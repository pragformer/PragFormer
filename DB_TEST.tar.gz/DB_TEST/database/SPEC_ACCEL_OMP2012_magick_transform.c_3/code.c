for (i = 0; i < ((ssize_t) GetImageListLength(images)); i += 4)
{
  cmyk_image = CloneImage(images, images->columns, images->rows, MagickTrue, exception);
  if (cmyk_image == ((Image *) 0))
    break;

  if (SetImageStorageClass(cmyk_image, DirectClass) == MagickFalse)
    break;

  (void) SetImageColorspace(cmyk_image, CMYKColorspace);
  image_view = AcquireCacheView(images);
  cmyk_view = AcquireCacheView(cmyk_image);
  for (y = 0; y < ((ssize_t) images->rows); y++)
  {
    register const PixelPacket * restrict p;
    register ssize_t x;
    register PixelPacket * restrict q;
    p = GetCacheViewVirtualPixels(image_view, 0, y, images->columns, 1, exception);
    q = QueueCacheViewAuthenticPixels(cmyk_view, 0, y, cmyk_image->columns, 1, exception);
    if ((p == ((const PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
      break;

    for (x = 0; x < ((ssize_t) images->columns); x++)
    {
      SetPixelRed(q, QuantumRange - PixelIntensityToQuantum(p));
      p++;
      q++;
    }

    if (SyncCacheViewAuthenticPixels(cmyk_view, exception) == MagickFalse)
      break;

  }

  cmyk_view = DestroyCacheView(cmyk_view);
  image_view = DestroyCacheView(image_view);
  images = GetNextImageInList(images);
  if (images == ((Image *) 0))
    break;

  image_view = AcquireCacheView(images);
  cmyk_view = AcquireCacheView(cmyk_image);
  for (y = 0; y < ((ssize_t) images->rows); y++)
  {
    register const PixelPacket * restrict p;
    register ssize_t x;
    register PixelPacket * restrict q;
    p = GetCacheViewVirtualPixels(image_view, 0, y, images->columns, 1, exception);
    q = GetCacheViewAuthenticPixels(cmyk_view, 0, y, cmyk_image->columns, 1, exception);
    if ((p == ((const PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
      break;

    for (x = 0; x < ((ssize_t) images->columns); x++)
    {
      q->green = (Quantum) (QuantumRange - PixelIntensityToQuantum(p));
      p++;
      q++;
    }

    if (SyncCacheViewAuthenticPixels(cmyk_view, exception) == MagickFalse)
      break;

  }

  cmyk_view = DestroyCacheView(cmyk_view);
  image_view = DestroyCacheView(image_view);
  images = GetNextImageInList(images);
  if (images == ((Image *) 0))
    break;

  image_view = AcquireCacheView(images);
  cmyk_view = AcquireCacheView(cmyk_image);
  for (y = 0; y < ((ssize_t) images->rows); y++)
  {
    register const PixelPacket * restrict p;
    register ssize_t x;
    register PixelPacket * restrict q;
    p = GetCacheViewVirtualPixels(image_view, 0, y, images->columns, 1, exception);
    q = GetCacheViewAuthenticPixels(cmyk_view, 0, y, cmyk_image->columns, 1, exception);
    if ((p == ((const PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
      break;

    for (x = 0; x < ((ssize_t) images->columns); x++)
    {
      q->blue = (Quantum) (QuantumRange - PixelIntensityToQuantum(p));
      p++;
      q++;
    }

    if (SyncCacheViewAuthenticPixels(cmyk_view, exception) == MagickFalse)
      break;

  }

  cmyk_view = DestroyCacheView(cmyk_view);
  image_view = DestroyCacheView(image_view);
  images = GetNextImageInList(images);
  if (images == ((Image *) 0))
    break;

  image_view = AcquireCacheView(images);
  cmyk_view = AcquireCacheView(cmyk_image);
  for (y = 0; y < ((ssize_t) images->rows); y++)
  {
    register const PixelPacket * restrict p;
    register IndexPacket * restrict indexes;
    register ssize_t x;
    register PixelPacket * restrict q;
    p = GetCacheViewVirtualPixels(image_view, 0, y, images->columns, 1, exception);
    q = GetCacheViewAuthenticPixels(cmyk_view, 0, y, cmyk_image->columns, 1, exception);
    if ((p == ((const PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
      break;

    indexes = GetCacheViewAuthenticIndexQueue(cmyk_view);
    for (x = 0; x < ((ssize_t) images->columns); x++)
    {
      SetPixelIndex(indexes + x, QuantumRange - PixelIntensityToQuantum(p));
      p++;
    }

    if (SyncCacheViewAuthenticPixels(cmyk_view, exception) == MagickFalse)
      break;

  }

  cmyk_view = DestroyCacheView(cmyk_view);
  image_view = DestroyCacheView(image_view);
  AppendImageToList(&cmyk_images, cmyk_image);
  images = GetNextImageInList(images);
  if (images == ((Image *) 0))
    break;

}

inline static Quantum PixelIntensityToQuantum(const PixelPacket *pixel)
{
  if ((GetPixelRed(pixel) == GetPixelGreen(pixel)) && (GetPixelGreen(pixel) == GetPixelBlue(pixel)))
    return GetPixelRed(pixel);

  return (Quantum) ((((0.299 * GetPixelRed(pixel)) + (0.587 * GetPixelGreen(pixel))) + (0.114 * GetPixelBlue(pixel))) + 0.5);
}


inline static Quantum PixelIntensityToQuantum(const PixelPacket *pixel)
{
  if ((GetPixelRed(pixel) == GetPixelGreen(pixel)) && (GetPixelGreen(pixel) == GetPixelBlue(pixel)))
    return GetPixelRed(pixel);

  return (Quantum) ((((0.299 * GetPixelRed(pixel)) + (0.587 * GetPixelGreen(pixel))) + (0.114 * GetPixelBlue(pixel))) + 0.5);
}


inline static Quantum PixelIntensityToQuantum(const PixelPacket *pixel)
{
  if ((GetPixelRed(pixel) == GetPixelGreen(pixel)) && (GetPixelGreen(pixel) == GetPixelBlue(pixel)))
    return GetPixelRed(pixel);

  return (Quantum) ((((0.299 * GetPixelRed(pixel)) + (0.587 * GetPixelGreen(pixel))) + (0.114 * GetPixelBlue(pixel))) + 0.5);
}


inline static Quantum PixelIntensityToQuantum(const PixelPacket *pixel)
{
  if ((GetPixelRed(pixel) == GetPixelGreen(pixel)) && (GetPixelGreen(pixel) == GetPixelBlue(pixel)))
    return GetPixelRed(pixel);

  return (Quantum) ((((0.299 * GetPixelRed(pixel)) + (0.587 * GetPixelGreen(pixel))) + (0.114 * GetPixelBlue(pixel))) + 0.5);
}

