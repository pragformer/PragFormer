for (i = 0; i < POLYBENCH_LOOP_BOUND(1024, ni); i++)
  for (j = 0; j < POLYBENCH_LOOP_BOUND(1024, ni); j++)
  C[i][j] *= beta;

