for (i = 0; i < POLYBENCH_LOOP_BOUND(4000, n); i++)
  for (j = 0; j < POLYBENCH_LOOP_BOUND(4000, n); j++)
  A[i][j] = (A[i][j] + (u1[i] * v1[j])) + (u2[i] * v2[j]);

