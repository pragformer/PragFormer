for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  if (((channel & RedChannel) != 0) && (white.red != black.red))
    equalize_map[i].red = (MagickRealType) ScaleMapToQuantum((MagickRealType) ((MaxMap * (map[i].red - black.red)) / (white.red - black.red)));

  if (((channel & GreenChannel) != 0) && (white.green != black.green))
    equalize_map[i].green = (MagickRealType) ScaleMapToQuantum((MagickRealType) ((MaxMap * (map[i].green - black.green)) / (white.green - black.green)));

  if (((channel & BlueChannel) != 0) && (white.blue != black.blue))
    equalize_map[i].blue = (MagickRealType) ScaleMapToQuantum((MagickRealType) ((MaxMap * (map[i].blue - black.blue)) / (white.blue - black.blue)));

  if (((channel & OpacityChannel) != 0) && (white.opacity != black.opacity))
    equalize_map[i].opacity = (MagickRealType) ScaleMapToQuantum((MagickRealType) ((MaxMap * (map[i].opacity - black.opacity)) / (white.opacity - black.opacity)));

  if ((((channel & IndexChannel) != 0) && (image->colorspace == CMYKColorspace)) && (white.index != black.index))
    equalize_map[i].index = (MagickRealType) ScaleMapToQuantum((MagickRealType) ((MaxMap * (map[i].index - black.index)) / (white.index - black.index)));

}
