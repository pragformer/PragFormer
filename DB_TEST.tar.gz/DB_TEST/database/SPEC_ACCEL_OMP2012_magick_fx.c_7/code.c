for (; next != ((Image *) 0); next = next->next)
{
  fx_info->view[i] = AcquireCacheView(next);
  i++;
}
