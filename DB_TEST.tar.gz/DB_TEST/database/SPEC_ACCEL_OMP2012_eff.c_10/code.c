for (i = -1; i < prm->Natom; i++)
{
  iexw[eoff + i] = -1;
}
