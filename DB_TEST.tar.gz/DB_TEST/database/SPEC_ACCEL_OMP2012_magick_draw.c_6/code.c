for (x = 0; draw_info->dash_pattern[x] != 0.0; x++)
  ;
