for (i = 0; i < maxgrid; i++)
  for (j = 0; j < maxgrid; j++)
{
  fprintf(stderr, "%d ", path[i][j]);
  if ((((i * maxgrid) + j) % 20) == 0)
    fprintf(stderr, "\n");

}

