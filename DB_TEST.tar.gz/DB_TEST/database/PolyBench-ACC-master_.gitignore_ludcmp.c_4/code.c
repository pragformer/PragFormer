for (i = 0; i < POLYBENCH_LOOP_BOUND(1024, n); i++)
{
  for (j = i + 1; j <= POLYBENCH_LOOP_BOUND(1024, n); j++)
  {
    w = A[j][i];
    for (k = 0; k < i; k++)
      w = w - (A[j][k] * A[k][i]);

    A[j][i] = w / A[i][i];
  }

  #pragma omp barrier
  for (j = i + 1; j <= POLYBENCH_LOOP_BOUND(1024, n); j++)
  {
    w = A[i + 1][j];
    for (k = 0; k <= i; k++)
      w = w - (A[i + 1][k] * A[k][j]);

    A[i + 1][j] = w;
  }

}
