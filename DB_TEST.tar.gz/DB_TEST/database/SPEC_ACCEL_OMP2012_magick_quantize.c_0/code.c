for (i = 0; i < ((ssize_t) image->colors); i++)
{
  if ((channel & RedChannel) != 0)
    image->colormap[i].red = (Quantum) ((QuantumRange * MagickRound(((((double) 1.0) / ((double) QuantumRange)) * image->colormap[i].red) * (levels - 1))) / MagickMax(((ssize_t) levels) - 1, 1));

  if ((channel & GreenChannel) != 0)
    image->colormap[i].green = (Quantum) ((QuantumRange * MagickRound(((((double) 1.0) / ((double) QuantumRange)) * image->colormap[i].green) * (levels - 1))) / MagickMax(((ssize_t) levels) - 1, 1));

  if ((channel & BlueChannel) != 0)
    image->colormap[i].blue = (Quantum) ((QuantumRange * MagickRound(((((double) 1.0) / ((double) QuantumRange)) * image->colormap[i].blue) * (levels - 1))) / MagickMax(((ssize_t) levels) - 1, 1));

  if ((channel & OpacityChannel) != 0)
    image->colormap[i].opacity = (Quantum) ((QuantumRange * MagickRound(((((double) 1.0) / ((double) QuantumRange)) * image->colormap[i].opacity) * (levels - 1))) / MagickMax(((ssize_t) levels) - 1, 1));

}

inline static ssize_t MagickRound(MagickRealType x)
{
  if (x >= 0.0)
    return (ssize_t) (x + 0.5);

  return (ssize_t) (x - 0.5);
}


inline static ssize_t MagickMax(const ssize_t x, const ssize_t y)
{
  if (x > y)
    return x;

  return y;
}


inline static ssize_t MagickRound(MagickRealType x)
{
  if (x >= 0.0)
    return (ssize_t) (x + 0.5);

  return (ssize_t) (x - 0.5);
}


inline static ssize_t MagickMax(const ssize_t x, const ssize_t y)
{
  if (x > y)
    return x;

  return y;
}


inline static ssize_t MagickRound(MagickRealType x)
{
  if (x >= 0.0)
    return (ssize_t) (x + 0.5);

  return (ssize_t) (x - 0.5);
}


inline static ssize_t MagickMax(const ssize_t x, const ssize_t y)
{
  if (x > y)
    return x;

  return y;
}


inline static ssize_t MagickRound(MagickRealType x)
{
  if (x >= 0.0)
    return (ssize_t) (x + 0.5);

  return (ssize_t) (x - 0.5);
}


inline static ssize_t MagickMax(const ssize_t x, const ssize_t y)
{
  if (x > y)
    return x;

  return y;
}

