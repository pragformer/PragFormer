for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register const PixelPacket * restrict p;
  register IndexPacket * restrict transpose_indexes;
  register IndexPacket * restrict indexes;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, (((ssize_t) image->rows) - y) - 1, image->columns, 1, exception);
  q = QueueCacheViewAuthenticPixels(transpose_view, (ssize_t) ((image->rows - y) - 1), 0, 1, transpose_image->rows, exception);
  if ((p == ((const PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
  {
    status = MagickFalse;
    continue;
  }

  (void) CopyMagickMemory(q, p, ((size_t) image->columns) * (sizeof(*q)));
  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  if (indexes != ((IndexPacket *) 0))
  {
    transpose_indexes = GetCacheViewAuthenticIndexQueue(transpose_view);
    if (transpose_indexes != ((IndexPacket *) 0))
      (void) CopyMagickMemory(transpose_indexes, indexes, ((size_t) image->columns) * (sizeof(*transpose_indexes)));

  }

  if (SyncCacheViewAuthenticPixels(transpose_view, exception) == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_TransposeImage)
    proceed = SetImageProgress(image, "Transpose/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

