for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register IndexPacket * restrict indexes;
  register PixelPacket * restrict q;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    if ((channel & RedChannel) != 0)
      SetPixelRed(q, ClampToQuantum(sigmoidal_map[ScaleQuantumToMap(GetPixelRed(q))]));

    if ((channel & GreenChannel) != 0)
      SetPixelGreen(q, ClampToQuantum(sigmoidal_map[ScaleQuantumToMap(GetPixelGreen(q))]));

    if ((channel & BlueChannel) != 0)
      SetPixelBlue(q, ClampToQuantum(sigmoidal_map[ScaleQuantumToMap(GetPixelBlue(q))]));

    if ((channel & OpacityChannel) != 0)
      SetPixelOpacity(q, ClampToQuantum(sigmoidal_map[ScaleQuantumToMap(GetPixelOpacity(q))]));

    if (((channel & IndexChannel) != 0) && (image->colorspace == CMYKColorspace))
      SetPixelIndex(indexes + x, ClampToQuantum(sigmoidal_map[ScaleQuantumToMap(GetPixelIndex(indexes + x))]));

    q++;
  }

  if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_SigmoidalContrastImageChannel)
    proceed = SetImageProgress(image, "SigmoidalContrast/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

