for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  if ((channel & RedChannel) != 0)
  {
    if (i < ((ssize_t) black.red))
      stretch_map[i].red = 0.0;
    else
      if (i > ((ssize_t) white.red))
      stretch_map[i].red = (MagickRealType) QuantumRange;
    else
      if (black.red != white.red)
      stretch_map[i].red = (MagickRealType) ScaleMapToQuantum((MagickRealType) ((MaxMap * (i - black.red)) / (white.red - black.red)));



  }

  if ((channel & GreenChannel) != 0)
  {
    if (i < ((ssize_t) black.green))
      stretch_map[i].green = 0.0;
    else
      if (i > ((ssize_t) white.green))
      stretch_map[i].green = (MagickRealType) QuantumRange;
    else
      if (black.green != white.green)
      stretch_map[i].green = (MagickRealType) ScaleMapToQuantum((MagickRealType) ((MaxMap * (i - black.green)) / (white.green - black.green)));



  }

  if ((channel & BlueChannel) != 0)
  {
    if (i < ((ssize_t) black.blue))
      stretch_map[i].blue = 0.0;
    else
      if (i > ((ssize_t) white.blue))
      stretch_map[i].blue = (MagickRealType) QuantumRange;
    else
      if (black.blue != white.blue)
      stretch_map[i].blue = (MagickRealType) ScaleMapToQuantum((MagickRealType) ((MaxMap * (i - black.blue)) / (white.blue - black.blue)));



  }

  if ((channel & OpacityChannel) != 0)
  {
    if (i < ((ssize_t) black.opacity))
      stretch_map[i].opacity = 0.0;
    else
      if (i > ((ssize_t) white.opacity))
      stretch_map[i].opacity = (MagickRealType) QuantumRange;
    else
      if (black.opacity != white.opacity)
      stretch_map[i].opacity = (MagickRealType) ScaleMapToQuantum((MagickRealType) ((MaxMap * (i - black.opacity)) / (white.opacity - black.opacity)));



  }

  if (((channel & IndexChannel) != 0) && (image->colorspace == CMYKColorspace))
  {
    if (i < ((ssize_t) black.index))
      stretch_map[i].index = 0.0;
    else
      if (i > ((ssize_t) white.index))
      stretch_map[i].index = (MagickRealType) QuantumRange;
    else
      if (black.index != white.index)
      stretch_map[i].index = (MagickRealType) ScaleMapToQuantum((MagickRealType) ((MaxMap * (i - black.index)) / (white.index - black.index)));



  }

}
