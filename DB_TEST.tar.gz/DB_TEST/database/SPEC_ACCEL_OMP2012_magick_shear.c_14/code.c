for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register const PixelPacket * restrict p;
  register ssize_t x;
  if ((y >= offset) && (y < (((ssize_t) image->rows) - offset)))
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  if (p == ((const PixelPacket *) 0))
    continue;

  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    if ((x >= offset) && (x < (((ssize_t) image->columns) - offset)))
      continue;

    background.red += (((double) 1.0) / ((double) QuantumRange)) * GetPixelRed(p);
    background.green += (((double) 1.0) / ((double) QuantumRange)) * GetPixelGreen(p);
    background.blue += (((double) 1.0) / ((double) QuantumRange)) * GetPixelBlue(p);
    background.opacity += (((double) 1.0) / ((double) QuantumRange)) * GetPixelOpacity(p);
    count++;
    p++;
  }

}
