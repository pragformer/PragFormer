for (i = 0; i < ((ssize_t) image->colors); i++)
{
  double luma;
  luma = ((0.2126 * image->colormap[i].red) + (0.7152 * image->colormap[i].green)) + (0.0722 * image->colormap[i].blue);
  image->colormap[i].red = ClampToQuantum((luma + (color_correction.saturation * cdl_map[ScaleQuantumToMap(image->colormap[i].red)].red)) - luma);
  image->colormap[i].green = ClampToQuantum((luma + (color_correction.saturation * cdl_map[ScaleQuantumToMap(image->colormap[i].green)].green)) - luma);
  image->colormap[i].blue = ClampToQuantum((luma + (color_correction.saturation * cdl_map[ScaleQuantumToMap(image->colormap[i].blue)].blue)) - luma);
}

inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}

