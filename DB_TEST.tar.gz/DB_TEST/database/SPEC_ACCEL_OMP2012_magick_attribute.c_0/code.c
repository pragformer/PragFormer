for (i = 0; i < ((ssize_t) image->colors); i++)
{
  const int id = GetOpenMPThreadId();
  if (status == MagickFalse)
    continue;

  while (current_depth[id] < MAGICKCORE_QUANTUM_DEPTH)
  {
    MagickStatusType status;
    QuantumAny range;
    status = 0;
    range = GetQuantumRange(current_depth[id]);
    if ((channel & RedChannel) != 0)
      status |= p->red != ScaleAnyToQuantum(ScaleQuantumToAny(p->red, range), range);

    if ((channel & GreenChannel) != 0)
      status |= p->green != ScaleAnyToQuantum(ScaleQuantumToAny(p->green, range), range);

    if ((channel & BlueChannel) != 0)
      status |= p->blue != ScaleAnyToQuantum(ScaleQuantumToAny(p->blue, range), range);

    if (status == 0)
      break;

    current_depth[id]++;
  }

  p++;
}

inline static int GetOpenMPThreadId(void)
{
  return 0;
}

