for (i = 0; image_list[i] != ((Image *) 0); i++)
{
  image = image_list[i];
  status |= TransformImage(&image, crop_geometry, image_geometry);
  AppendImageToList(&transform_images, image);
}

MagickBooleanType TransformImage(Image **image, const char *crop_geometry, const char *image_geometry)
{
  Image *resize_image;
  Image *transform_image;
  MagickStatusType flags;
  RectangleInfo geometry;
  assert(image != ((Image **) 0));
  assert((*image)->signature == 0xabacadabUL);
  if ((*image)->debug != MagickFalse)
    (void) LogMagickEvent(TraceEvent, GetMagickModule(), "%s", (*image)->filename);

  transform_image = *image;
  if (crop_geometry != ((const char *) 0))
  {
    Image *crop_image;
    crop_image = CropImageToTiles(*image, crop_geometry, &(*image)->exception);
    if (crop_image == ((Image *) 0))
      transform_image = CloneImage(*image, 0, 0, MagickTrue, &(*image)->exception);
    else
    {
      transform_image = DestroyImage(transform_image);
      transform_image = GetFirstImageInList(crop_image);
    }

    *image = transform_image;
  }

  if (image_geometry == ((const char *) 0))
    return MagickTrue;

  flags = ParseRegionGeometry(transform_image, image_geometry, &geometry, &(*image)->exception);
  (void) flags;
  if ((transform_image->columns == geometry.width) && (transform_image->rows == geometry.height))
    return MagickTrue;

  resize_image = ResizeImage(transform_image, geometry.width, geometry.height, transform_image->filter, transform_image->blur, &(*image)->exception);
  if (resize_image == ((Image *) 0))
    return MagickFalse;

  transform_image = DestroyImage(transform_image);
  transform_image = resize_image;
  *image = transform_image;
  return MagickTrue;
}

