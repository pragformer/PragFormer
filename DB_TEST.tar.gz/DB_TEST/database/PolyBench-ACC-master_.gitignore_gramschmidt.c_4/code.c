for (i = 0; i < nj; i++)
  for (j = 0; j < nj; j++)
{
  fprintf(stderr, "%0.2lf ", R[i][j]);
  if ((i % 20) == 0)
    fprintf(stderr, "\n");

}

