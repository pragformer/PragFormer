for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register const IndexPacket * restrict indexes;
  register const PixelPacket * restrict p;
  register ssize_t x;
  p = GetVirtualPixels(image, 0, y, image->columns, 1, exception);
  if (p == ((const PixelPacket *) 0))
    break;

  indexes = GetVirtualIndexQueue(image);
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    if ((channel & RedChannel) != 0)
      histogram[ScaleQuantumToMap(GetPixelRed(p))].red++;

    if ((channel & GreenChannel) != 0)
      histogram[ScaleQuantumToMap(GetPixelGreen(p))].green++;

    if ((channel & BlueChannel) != 0)
      histogram[ScaleQuantumToMap(GetPixelBlue(p))].blue++;

    if ((channel & OpacityChannel) != 0)
      histogram[ScaleQuantumToMap(GetPixelOpacity(p))].opacity++;

    if (((channel & IndexChannel) != 0) && (image->colorspace == CMYKColorspace))
      histogram[ScaleQuantumToMap(GetPixelIndex(indexes + x))].index++;

    p++;
  }

}
