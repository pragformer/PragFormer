for (iz = 0; iz < POLYBENCH_LOOP_BOUND(256, cz); iz++)
{
  for (iy = 0; iy < POLYBENCH_LOOP_BOUND(256, cym); iy++)
  {
    for (ix = 0; ix < POLYBENCH_LOOP_BOUND(256, cxm); ix++)
    {
      clf[iz][iy] = ((Ex[iz][iy][ix] - Ex[iz][iy + 1][ix]) + Ey[iz][iy][ix + 1]) - Ey[iz][iy][ix];
      tmp[iz][iy] = ((cymh[iy] / cyph[iy]) * Bza[iz][iy][ix]) - ((ch / cyph[iy]) * clf[iz][iy]);
      Hz[iz][iy][ix] = (((cxmh[ix] / cxph[ix]) * Hz[iz][iy][ix]) + (((mui * czp[iz]) / cxph[ix]) * tmp[iz][iy])) - (((mui * czm[iz]) / cxph[ix]) * Bza[iz][iy][ix]);
      Bza[iz][iy][ix] = tmp[iz][iy];
    }

    clf[iz][iy] = ((Ex[iz][iy][POLYBENCH_LOOP_BOUND(256, cxm)] - Ex[iz][iy + 1][POLYBENCH_LOOP_BOUND(256, cxm)]) + Ry[iz][iy]) - Ey[iz][iy][POLYBENCH_LOOP_BOUND(256, cxm)];
    tmp[iz][iy] = ((cymh[iy] / cyph[iy]) * Bza[iz][iy][POLYBENCH_LOOP_BOUND(256, cxm)]) - ((ch / cyph[iy]) * clf[iz][iy]);
    Hz[iz][iy][POLYBENCH_LOOP_BOUND(256, cxm)] = (((cxmh[POLYBENCH_LOOP_BOUND(256, cxm)] / cxph[POLYBENCH_LOOP_BOUND(256, cxm)]) * Hz[iz][iy][POLYBENCH_LOOP_BOUND(256, cxm)]) + (((mui * czp[iz]) / cxph[POLYBENCH_LOOP_BOUND(256, cxm)]) * tmp[iz][iy])) - (((mui * czm[iz]) / cxph[POLYBENCH_LOOP_BOUND(256, cxm)]) * Bza[iz][iy][POLYBENCH_LOOP_BOUND(256, cxm)]);
    Bza[iz][iy][POLYBENCH_LOOP_BOUND(256, cxm)] = tmp[iz][iy];
    for (ix = 0; ix < POLYBENCH_LOOP_BOUND(256, cxm); ix++)
    {
      clf[iz][iy] = ((Ex[iz][POLYBENCH_LOOP_BOUND(256, cym)][ix] - Ax[iz][ix]) + Ey[iz][POLYBENCH_LOOP_BOUND(256, cym)][ix + 1]) - Ey[iz][POLYBENCH_LOOP_BOUND(256, cym)][ix];
      tmp[iz][iy] = ((cymh[POLYBENCH_LOOP_BOUND(256, cym)] / cyph[iy]) * Bza[iz][iy][ix]) - ((ch / cyph[iy]) * clf[iz][iy]);
      Hz[iz][POLYBENCH_LOOP_BOUND(256, cym)][ix] = (((cxmh[ix] / cxph[ix]) * Hz[iz][POLYBENCH_LOOP_BOUND(256, cym)][ix]) + (((mui * czp[iz]) / cxph[ix]) * tmp[iz][iy])) - (((mui * czm[iz]) / cxph[ix]) * Bza[iz][POLYBENCH_LOOP_BOUND(256, cym)][ix]);
      Bza[iz][POLYBENCH_LOOP_BOUND(256, cym)][ix] = tmp[iz][iy];
    }

    clf[iz][iy] = ((Ex[iz][POLYBENCH_LOOP_BOUND(256, cym)][POLYBENCH_LOOP_BOUND(256, cxm)] - Ax[iz][POLYBENCH_LOOP_BOUND(256, cxm)]) + Ry[iz][POLYBENCH_LOOP_BOUND(256, cym)]) - Ey[iz][POLYBENCH_LOOP_BOUND(256, cym)][POLYBENCH_LOOP_BOUND(256, cxm)];
    tmp[iz][iy] = ((cymh[POLYBENCH_LOOP_BOUND(256, cym)] / cyph[POLYBENCH_LOOP_BOUND(256, cym)]) * Bza[iz][POLYBENCH_LOOP_BOUND(256, cym)][POLYBENCH_LOOP_BOUND(256, cxm)]) - ((ch / cyph[POLYBENCH_LOOP_BOUND(256, cym)]) * clf[iz][iy]);
    Hz[iz][POLYBENCH_LOOP_BOUND(256, cym)][POLYBENCH_LOOP_BOUND(256, cxm)] = (((cxmh[POLYBENCH_LOOP_BOUND(256, cxm)] / cxph[POLYBENCH_LOOP_BOUND(256, cxm)]) * Hz[iz][POLYBENCH_LOOP_BOUND(256, cym)][POLYBENCH_LOOP_BOUND(256, cxm)]) + (((mui * czp[iz]) / cxph[POLYBENCH_LOOP_BOUND(256, cxm)]) * tmp[iz][iy])) - (((mui * czm[iz]) / cxph[POLYBENCH_LOOP_BOUND(256, cxm)]) * Bza[iz][POLYBENCH_LOOP_BOUND(256, cym)][POLYBENCH_LOOP_BOUND(256, cxm)]);
    Bza[iz][POLYBENCH_LOOP_BOUND(256, cym)][POLYBENCH_LOOP_BOUND(256, cxm)] = tmp[iz][iy];
  }

}
