for (i = -1; i < prm->Natom; i++)
{
  iexw[i] = -1;
}
