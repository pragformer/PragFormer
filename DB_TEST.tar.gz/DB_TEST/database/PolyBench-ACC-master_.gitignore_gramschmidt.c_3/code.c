for (i = 0; i < ni; i++)
  for (j = 0; j < nj; j++)
{
  fprintf(stderr, "%0.2lf ", A[i][j]);
  if ((i % 20) == 0)
    fprintf(stderr, "\n");

}

