for (i = 0; i < ((ssize_t) polygon_info->number_edges); i++)
  polygon_info->edges[i].points = (PointInfo *) RelinquishMagickMemory(polygon_info->edges[i].points);
