for (j = 0; j < goff; j++)
{
  for (i = 1; i < maxthreads; i++)
  {
    f[j] += grad[(goff * i) + j];
  }

}
