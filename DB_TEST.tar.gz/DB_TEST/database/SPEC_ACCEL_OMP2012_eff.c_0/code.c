for (j = 0; j < prm->Natom; j++)
{
  for (i = 1; i < numcopies; i++)
  {
    sumdeijda[j] += sumdeijda[(prm->Natom * i) + j];
  }

}
