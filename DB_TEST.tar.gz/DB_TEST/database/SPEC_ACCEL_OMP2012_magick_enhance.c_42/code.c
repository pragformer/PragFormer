for (level = 2; ((level * level) * level) < length; level++)
  ;
