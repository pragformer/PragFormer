for (i = 0; i < goff; i++)
{
  grad[(consumer * goff) + i] += grad[(producer * goff) + i];
}
