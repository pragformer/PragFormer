for (i = 0; i < ((ssize_t) number_coordinates); i++)
  coefficients[i] = Permutate(((ssize_t) number_coordinates) - 1, i);

inline static MagickRealType Permutate(const ssize_t n, const ssize_t k)
{
  MagickRealType r;
  register ssize_t i;
  r = 1.0;
  for (i = k + 1; i <= n; i++)
    r *= i;

  for (i = 1; i <= (n - k); i++)
    r /= i;

  return r;
}

