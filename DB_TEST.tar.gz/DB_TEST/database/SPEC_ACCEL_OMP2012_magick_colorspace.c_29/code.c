for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  x_map[i].x = 3.2404542f * ((MagickRealType) i);
  x_map[i].y = (-0.9692660f) * ((MagickRealType) i);
  x_map[i].z = 0.0556434f * ((MagickRealType) i);
  y_map[i].x = (-1.5371385f) * ((MagickRealType) i);
  y_map[i].y = 1.8760108f * ((MagickRealType) i);
  y_map[i].z = (-0.2040259f) * ((MagickRealType) i);
  z_map[i].x = (-0.4985314f) * ((MagickRealType) i);
  z_map[i].y = 0.0415560f * ((MagickRealType) i);
  z_map[i].z = 1.0572252f * ((MagickRealType) i);
}
