for (i = 0; i < prm->Natom; i++)
{
  ri = reff[i];
  qi = q[i];
  if (!frozen[i])
  {
    expmkf = exp(((-0.73) * (*kappa)) * ri) / (*diel_ext);
    dielfac = 1.0 - expmkf;
    qi2h = (0.5 * qi) * qi;
    qid2h = qi2h * dielfac;
    epol += (-qid2h) / ri;
    vdwterm = 0.0;
    vdwdenom = 1.0;
    sumdeijda[soff + i] += (qid2h - ((((0.73 * (*kappa)) * qi2h) * expmkf) * ri)) + vdwterm;
  }

  npairs = upears[i];
  if (npairs <= 0)
    continue;

  i34 = dim * i;
  xi = x[i34];
  yi = x[i34 + 1];
  zi = x[i34 + 2];
  if (dim == 4)
  {
    wi = x[i34 + 3];
  }

  iaci = prm->Ntypes * (prm->Iac[i] - 1);
  for (j = 0; j < prm->Iblo[i]; j++)
  {
    iexw[(eoff + IexclAt[i][j]) - 1] = i;
  }

  daix = (daiy = (daiz = (daiw = 0.0)));
  for (k = lpears[i]; k < (lpears[i] + npairs); k++)
  {
    if (pearlist[i] == NULL)
    {
      fprintf(nabout, "NULL pair list entry in egb loop 3, taskid = %d\n", mytaskid);
      fflush(nabout);
    }

    j = pearlist[i][k];
    j34 = dim * j;
    xij = xi - x[j34];
    yij = yi - x[j34 + 1];
    zij = zi - x[j34 + 2];
    r2 = ((xij * xij) + (yij * yij)) + (zij * zij);
    if (dim == 4)
    {
      wij = wi - x[j34 + 3];
      r2 += wij * wij;
    }

    qiqj = qi * q[j];
    rj = reff[j];
    rb2 = ri * rj;
    efac = exp((-r2) / (4.0 * rb2));
    fgbi = 1.0 / sqrt(r2 + (rb2 * efac));
    fgbk = ((-(*kappa)) * 0.73) / fgbi;
    expmkf = exp(fgbk) / (*diel_ext);
    dielfac = 1.0 - expmkf;
    epol += ((-qiqj) * dielfac) * fgbi;
    temp4 = (fgbi * fgbi) * fgbi;
    temp6 = (qiqj * temp4) * (dielfac + (fgbk * expmkf));
    de = temp6 * (1.0 - (0.25 * efac));
    temp5 = ((0.5 * efac) * temp6) * (rb2 + (0.25 * r2));
    sumdeijda[soff + i] += ri * temp5;
    sumdeijda[soff + j] += rj * temp5;
    if (iexw[eoff + j] != i)
    {
      rinv = 1. / sqrt(r2);
      r2inv = rinv * rinv;
      eel = qiqj * rinv;
      elec += eel;
      de -= eel * r2inv;
      ic = prm->Cno[(iaci + prm->Iac[j]) - 1] - 1;
      if (ic >= 0)
      {
        r6inv = (r2inv * r2inv) * r2inv;
        f6 = prm->Cn2[ic] * r6inv;
        f12 = (prm->Cn1[ic] * r6inv) * r6inv;
        evdw += f12 - f6;
        de -= ((12. * f12) - (6. * f6)) * r2inv;
      }

    }

    dedx = de * xij;
    dedy = de * yij;
    dedz = de * zij;
    daix += dedx;
    daiy += dedy;
    daiz += dedz;
    if (dim == 4)
    {
      dedw = de * wij;
      daiw += dedw;
    }

    f[foff + j34] -= dedx;
    f[(foff + j34) + 1] -= dedy;
    f[(foff + j34) + 2] -= dedz;
    if (dim == 4)
    {
      f[(foff + j34) + 3] -= dedw;
    }

  }

  f[foff + i34] += daix;
  f[(foff + i34) + 1] += daiy;
  f[(foff + i34) + 2] += daiz;
  if (dim == 4)
  {
    f[(foff + i34) + 3] += daiw;
  }

}
