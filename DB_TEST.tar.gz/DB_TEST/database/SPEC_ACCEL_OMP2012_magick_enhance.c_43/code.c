for (y = 0; y < ((ssize_t) image->rows); y++)
{
  double offset;
  HaldInfo point;
  MagickPixelPacket pixel;
  MagickPixelPacket pixel1;
  MagickPixelPacket pixel2;
  MagickPixelPacket pixel3;
  MagickPixelPacket pixel4;
  register IndexPacket * restrict indexes;
  register PixelPacket * restrict q;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewAuthenticIndexQueue(hald_view);
  pixel = zero;
  pixel1 = zero;
  pixel2 = zero;
  pixel3 = zero;
  pixel4 = zero;
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    point.x = ((((double) 1.0) / ((double) QuantumRange)) * (level - 1.0)) * GetPixelRed(q);
    point.y = ((((double) 1.0) / ((double) QuantumRange)) * (level - 1.0)) * GetPixelGreen(q);
    point.z = ((((double) 1.0) / ((double) QuantumRange)) * (level - 1.0)) * GetPixelBlue(q);
    offset = (point.x + (level * floor(point.y))) + (cube_size * floor(point.z));
    point.x -= floor(point.x);
    point.y -= floor(point.y);
    point.z -= floor(point.z);
    (void) InterpolateMagickPixelPacket(image, hald_view, UndefinedInterpolatePixel, fmod(offset, width), floor(offset / width), &pixel1, exception);
    (void) InterpolateMagickPixelPacket(image, hald_view, UndefinedInterpolatePixel, fmod(offset + level, width), floor((offset + level) / width), &pixel2, exception);
    MagickPixelCompositeAreaBlend(&pixel1, pixel1.opacity, &pixel2, pixel2.opacity, point.y, &pixel3);
    offset += cube_size;
    (void) InterpolateMagickPixelPacket(image, hald_view, UndefinedInterpolatePixel, fmod(offset, width), floor(offset / width), &pixel1, exception);
    (void) InterpolateMagickPixelPacket(image, hald_view, UndefinedInterpolatePixel, fmod(offset + level, width), floor((offset + level) / width), &pixel2, exception);
    MagickPixelCompositeAreaBlend(&pixel1, pixel1.opacity, &pixel2, pixel2.opacity, point.y, &pixel4);
    MagickPixelCompositeAreaBlend(&pixel3, pixel3.opacity, &pixel4, pixel4.opacity, point.z, &pixel);
    if ((channel & RedChannel) != 0)
      SetPixelRed(q, ClampToQuantum(pixel.red));

    if ((channel & GreenChannel) != 0)
      SetPixelGreen(q, ClampToQuantum(pixel.green));

    if ((channel & BlueChannel) != 0)
      SetPixelBlue(q, ClampToQuantum(pixel.blue));

    if (((channel & OpacityChannel) != 0) && (image->matte != MagickFalse))
      SetPixelOpacity(q, ClampToQuantum(pixel.opacity));

    if (((channel & IndexChannel) != 0) && (image->colorspace == CMYKColorspace))
      SetPixelIndex(indexes + x, ClampToQuantum(pixel.index));

    q++;
  }

  if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_HaldClutImageChannel)
    proceed = SetImageProgress(image, "Clut/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static void MagickPixelCompositeAreaBlend(const MagickPixelPacket *p, const MagickRealType alpha, const MagickPixelPacket *q, const MagickRealType beta, const MagickRealType area, MagickPixelPacket *composite)
{
  MagickPixelCompositePlus(p, ((MagickRealType) QuantumRange) - ((1.0 - area) * (QuantumRange - alpha)), q, (MagickRealType) (QuantumRange - (area * (QuantumRange - beta))), composite);
}


inline static void MagickPixelCompositeAreaBlend(const MagickPixelPacket *p, const MagickRealType alpha, const MagickPixelPacket *q, const MagickRealType beta, const MagickRealType area, MagickPixelPacket *composite)
{
  MagickPixelCompositePlus(p, ((MagickRealType) QuantumRange) - ((1.0 - area) * (QuantumRange - alpha)), q, (MagickRealType) (QuantumRange - (area * (QuantumRange - beta))), composite);
}


inline static void MagickPixelCompositeAreaBlend(const MagickPixelPacket *p, const MagickRealType alpha, const MagickPixelPacket *q, const MagickRealType beta, const MagickRealType area, MagickPixelPacket *composite)
{
  MagickPixelCompositePlus(p, ((MagickRealType) QuantumRange) - ((1.0 - area) * (QuantumRange - alpha)), q, (MagickRealType) (QuantumRange - (area * (QuantumRange - beta))), composite);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

