for (y = 0; y < ((ssize_t) image->rows); y++)
{
  MagickPixelPacket pixel;
  RectangleInfo bounding_box;
  register const IndexPacket * restrict indexes;
  register const PixelPacket * restrict p;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  #pragma omp critical (MagickCore_GetImageBoundingBox)
  bounding_box = bounds;
  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  if (p == ((const PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewVirtualIndexQueue(image_view);
  pixel = zero;
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    SetMagickPixelPacket(image, p, indexes + x, &pixel);
    if ((x < bounding_box.x) && (IsMagickColorSimilar(&pixel, &target[0]) == MagickFalse))
      bounding_box.x = x;

    if ((x > ((ssize_t) bounding_box.width)) && (IsMagickColorSimilar(&pixel, &target[1]) == MagickFalse))
      bounding_box.width = (size_t) x;

    if ((y < bounding_box.y) && (IsMagickColorSimilar(&pixel, &target[0]) == MagickFalse))
      bounding_box.y = y;

    if ((y > ((ssize_t) bounding_box.height)) && (IsMagickColorSimilar(&pixel, &target[2]) == MagickFalse))
      bounding_box.height = (size_t) y;

    p++;
  }

  #pragma omp critical (MagickCore_GetImageBoundingBox)
  {
    if (bounding_box.x < bounds.x)
      bounds.x = bounding_box.x;

    if (bounding_box.y < bounds.y)
      bounds.y = bounding_box.y;

    if (bounding_box.width > bounds.width)
      bounds.width = bounding_box.width;

    if (bounding_box.height > bounds.height)
      bounds.height = bounding_box.height;

  }
}

inline static void SetMagickPixelPacket(const Image *image, const PixelPacket *color, const IndexPacket *index, MagickPixelPacket *pixel)
{
  pixel->red = (MagickRealType) color->red;
  pixel->green = (MagickRealType) color->green;
  pixel->blue = (MagickRealType) color->blue;
  pixel->opacity = (MagickRealType) color->opacity;
  if ((image->colorspace == CMYKColorspace) && (index != ((const IndexPacket *) 0)))
    pixel->index = (MagickRealType) (*index);

}

