for (id = 1; id < ((ssize_t) number_threads); id++)
  if (depth < current_depth[id])
  depth = current_depth[id];

