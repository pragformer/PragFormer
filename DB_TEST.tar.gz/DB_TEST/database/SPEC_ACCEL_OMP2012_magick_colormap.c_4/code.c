for (y = 0; y < ((ssize_t) image->rows); y++)
{
  IndexPacket index;
  register ssize_t x;
  register IndexPacket * restrict indexes;
  register PixelPacket * restrict q;
  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    index = (IndexPacket) pixels[(ssize_t) GetPixelIndex(indexes + x)];
    SetPixelIndex(indexes + x, index);
    SetPixelRGBO(q, image->colormap + ((ssize_t) index));
    q++;
  }

  if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
    status = MagickFalse;

  if (status == MagickFalse)
    break;

}
