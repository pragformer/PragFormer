for (y = 0; y < ((ssize_t) rows); y++)
{
  MagickBooleanType sync;
  register const IndexPacket * restrict indexes;
  register const PixelPacket * restrict p;
  register IndexPacket * restrict destination_indexes;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(source_view, sx, sy + y, columns, 1, exception);
  q = GetCacheViewAuthenticPixels(destination_view, dx, dy + y, columns, 1, exception);
  if ((p == ((const PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewVirtualIndexQueue(source_view);
  (void) CopyMagickMemory(q, p, ((size_t) columns) * (sizeof(*p)));
  if (indexes != ((IndexPacket *) 0))
  {
    destination_indexes = GetCacheViewAuthenticIndexQueue(destination_view);
    if (destination_indexes != ((IndexPacket *) 0))
      (void) CopyMagickMemory(destination_indexes, indexes, ((size_t) columns) * (sizeof(*indexes)));

  }

  sync = SyncCacheViewAuthenticPixels(destination_view, exception);
  if (sync == MagickFalse)
    status = MagickFalse;

}
