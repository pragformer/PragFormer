for (y = 0; y < ((ssize_t) image->rows); y++)
{
  double hue;
  double lightness;
  double saturation;
  MagickBooleanType sync;
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    Quantum blue;
    Quantum green;
    Quantum red;
    hue = (double) ((((double) 1.0) / ((double) QuantumRange)) * GetPixelRed(q));
    saturation = (double) ((((double) 1.0) / ((double) QuantumRange)) * GetPixelGreen(q));
    lightness = (double) ((((double) 1.0) / ((double) QuantumRange)) * GetPixelBlue(q));
    ConvertHSLToRGB(hue, saturation, lightness, &red, &green, &blue);
    SetPixelRed(q, red);
    SetPixelGreen(q, green);
    SetPixelBlue(q, blue);
    q++;
  }

  sync = SyncCacheViewAuthenticPixels(image_view, exception);
  if (sync == MagickFalse)
    status = MagickFalse;

}
