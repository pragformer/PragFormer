for (i = 0; i < ((ssize_t) arc_segments); i++)
{
  beta = 0.5 * ((alpha + (((i + 1) * theta) / arc_segments)) - (alpha + ((i * theta) / arc_segments)));
  gamma = (((8.0 / 3.0) * sin(fmod((double) (0.5 * beta), DegreesToRadians(360.0)))) * sin(fmod((double) (0.5 * beta), DegreesToRadians(360.0)))) / sin(fmod((double) beta, DegreesToRadians(360.0)));
  points[0].x = (double) ((center.x + cos(fmod((double) (alpha + ((((double) i) * theta) / arc_segments)), DegreesToRadians(360.0)))) - (gamma * sin(fmod((double) (alpha + ((((double) i) * theta) / arc_segments)), DegreesToRadians(360.0)))));
  points[0].y = (double) ((center.y + sin(fmod((double) (alpha + ((((double) i) * theta) / arc_segments)), DegreesToRadians(360.0)))) + (gamma * cos(fmod((double) (alpha + ((((double) i) * theta) / arc_segments)), DegreesToRadians(360.0)))));
  points[2].x = (double) (center.x + cos(fmod((double) (alpha + ((((double) (i + 1)) * theta) / arc_segments)), DegreesToRadians(360.0))));
  points[2].y = (double) (center.y + sin(fmod((double) (alpha + ((((double) (i + 1)) * theta) / arc_segments)), DegreesToRadians(360.0))));
  points[1].x = (double) (points[2].x + (gamma * sin(fmod((double) (alpha + ((((double) (i + 1)) * theta) / arc_segments)), DegreesToRadians(360.0)))));
  points[1].y = (double) (points[2].y - (gamma * cos(fmod((double) (alpha + ((((double) (i + 1)) * theta) / arc_segments)), DegreesToRadians(360.0)))));
  p->point.x = (p == primitive_info) ? (start.x) : ((p - 1)->point.x);
  p->point.y = (p == primitive_info) ? (start.y) : ((p - 1)->point.y);
  (p + 1)->point.x = (double) (((cosine * radii.x) * points[0].x) - ((sine * radii.y) * points[0].y));
  (p + 1)->point.y = (double) (((sine * radii.x) * points[0].x) + ((cosine * radii.y) * points[0].y));
  (p + 2)->point.x = (double) (((cosine * radii.x) * points[1].x) - ((sine * radii.y) * points[1].y));
  (p + 2)->point.y = (double) (((sine * radii.x) * points[1].x) + ((cosine * radii.y) * points[1].y));
  (p + 3)->point.x = (double) (((cosine * radii.x) * points[2].x) - ((sine * radii.y) * points[2].y));
  (p + 3)->point.y = (double) (((sine * radii.x) * points[2].x) + ((cosine * radii.y) * points[2].y));
  if (i == ((ssize_t) (arc_segments - 1)))
    (p + 3)->point = end;

  TraceBezier(p, 4);
  p += p->coordinates;
}

inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


static void TraceBezier(PrimitiveInfo *primitive_info, const size_t number_coordinates)
{
  MagickRealType alpha;
  MagickRealType *coefficients;
  MagickRealType weight;
  PointInfo end;
  PointInfo point;
  PointInfo *points;
  register PrimitiveInfo *p;
  register ssize_t i;
  register ssize_t j;
  size_t control_points;
  size_t quantum;
  quantum = number_coordinates;
  for (i = 0; i < ((ssize_t) number_coordinates); i++)
  {
    for (j = i + 1; j < ((ssize_t) number_coordinates); j++)
    {
      alpha = fabs(primitive_info[j].point.x - primitive_info[i].point.x);
      if (alpha > ((MagickRealType) quantum))
        quantum = (size_t) alpha;

      alpha = fabs(primitive_info[j].point.y - primitive_info[i].point.y);
      if (alpha > ((MagickRealType) quantum))
        quantum = (size_t) alpha;

    }

  }

  quantum = (size_t) MagickMin(((double) quantum) / number_coordinates, (double) 200);
  control_points = quantum * number_coordinates;
  coefficients = (MagickRealType *) AcquireQuantumMemory((size_t) number_coordinates, sizeof(*coefficients));
  points = (PointInfo *) AcquireQuantumMemory((size_t) control_points, sizeof(*points));
  if ((coefficients == ((MagickRealType *) 0)) || (points == ((PointInfo *) 0)))
  {
    char *message;
    ExceptionInfo exception;
    GetExceptionInfo(&exception);
    message = GetExceptionMessage(errno);
    (void) ThrowMagickException(&exception, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 5060, ResourceLimitFatalError, ("MemoryAllocationFailed" == ((const char *) 0)) ? ("unknown") : ("MemoryAllocationFailed"), "`%s'", message);
    message = DestroyString(message);
    CatchException(&exception);
    (void) DestroyExceptionInfo(&exception);
    _exit(1);
  }

  ;
  end = primitive_info[number_coordinates - 1].point;
  for (i = 0; i < ((ssize_t) number_coordinates); i++)
    coefficients[i] = Permutate(((ssize_t) number_coordinates) - 1, i);

  weight = 0.0;
  for (i = 0; i < ((ssize_t) control_points); i++)
  {
    p = primitive_info;
    point.x = 0.0;
    point.y = 0.0;
    alpha = pow((double) (1.0 - weight), ((double) number_coordinates) - 1.0);
    for (j = 0; j < ((ssize_t) number_coordinates); j++)
    {
      point.x += (alpha * coefficients[j]) * p->point.x;
      point.y += (alpha * coefficients[j]) * p->point.y;
      alpha *= weight / (1.0 - weight);
      p++;
    }

    points[i] = point;
    weight += 1.0 / control_points;
  }

  p = primitive_info;
  for (i = 0; i < ((ssize_t) control_points); i++)
  {
    TracePoint(p, points[i]);
    p += p->coordinates;
  }

  TracePoint(p, end);
  p += p->coordinates;
  primitive_info->coordinates = (size_t) (p - primitive_info);
  for (i = 0; i < ((ssize_t) primitive_info->coordinates); i++)
  {
    p->primitive = primitive_info->primitive;
    p--;
  }

  points = (PointInfo *) RelinquishMagickMemory(points);
  coefficients = (MagickRealType *) RelinquishMagickMemory(coefficients);
}

