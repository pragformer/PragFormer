for (rotations = 0; angle > 45.0; rotations++)
  angle -= 90.0;
