for (i = 0; i <= ((ssize_t) (0.018 * MaxMap)); i++)
{
  x_map[i].x = 0.003962014134275617f * ((MagickRealType) i);
  y_map[i].x = 0.007778268551236748f * ((MagickRealType) i);
  z_map[i].x = 0.001510600706713781f * ((MagickRealType) i);
  x_map[i].y = (-0.002426619775463276f) * ((MagickRealType) i);
  y_map[i].y = (-0.004763965913702149f) * ((MagickRealType) i);
  z_map[i].y = 0.007190585689165425f * ((MagickRealType) i);
  x_map[i].z = 0.006927257754597858f * ((MagickRealType) i);
  y_map[i].z = (-0.005800713697502058f) * ((MagickRealType) i);
  z_map[i].z = (-0.0011265440570958f) * ((MagickRealType) i);
}
