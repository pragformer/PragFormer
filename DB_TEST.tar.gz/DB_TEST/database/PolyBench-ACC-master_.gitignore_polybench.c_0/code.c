for (i = 0; i < cs; i++)
  tmp += flush[i];
