for (i = 0; i < n; i++)
{
  fprintf(stderr, "%0.2lf ", out[i]);
  if ((i % 20) == 0)
    fprintf(stderr, "\n");

}
