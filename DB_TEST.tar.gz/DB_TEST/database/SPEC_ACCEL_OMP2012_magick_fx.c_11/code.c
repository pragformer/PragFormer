for (v = 0; v < ((ssize_t) color_matrix->height); v++)
  for (u = 0; u < ((ssize_t) color_matrix->width); u++)
{
  if ((v < 6) && (u < 6))
    ColorMatrix[v][u] = color_matrix->values[i];

  i++;
}

