for (i = 0; ((*p) != '\0') && (i < 3); i++)
{
  GetMagickToken(p, &p, token);
  if ((*token) == ',')
    GetMagickToken(p, &p, token);

  switch (i)
  {
    case 0:
    {
      color_correction.red.power = InterpretLocaleValue(token, (char **) 0);
      break;
    }

    case 1:
    {
      color_correction.green.power = InterpretLocaleValue(token, (char **) 0);
      break;
    }

    case 2:
    {
      color_correction.blue.power = InterpretLocaleValue(token, (char **) 0);
      break;
    }

  }

}
