for (y = 0; y < ((ssize_t) image->rows); y++)
{
  const int id = GetOpenMPThreadId();
  CubeInfo cube;
  RealPixelPacket *current;
  RealPixelPacket *previous;
  register IndexPacket * restrict indexes;
  register PixelPacket * restrict q;
  register ssize_t x;
  size_t index;
  ssize_t v;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  cube = *cube_info;
  current = pixels[id] + ((y & 0x01) * image->columns);
  previous = pixels[id] + (((y + 1) & 0x01) * image->columns);
  v = (ssize_t) ((y & 0x01) ? (-1) : (1));
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    RealPixelPacket color;
    RealPixelPacket pixel;
    register ssize_t i;
    ssize_t u;
    u = (y & 0x01) ? ((((ssize_t) image->columns) - 1) - x) : (x);
    AssociateAlphaPixel(&cube, q + u, &pixel);
    if (x > 0)
    {
      pixel.red += (7 * current[u - v].red) / 16;
      pixel.green += (7 * current[u - v].green) / 16;
      pixel.blue += (7 * current[u - v].blue) / 16;
      if (cube.associate_alpha != MagickFalse)
        pixel.opacity += (7 * current[u - v].opacity) / 16;

    }

    if (y > 0)
    {
      if (x < ((ssize_t) (image->columns - 1)))
      {
        pixel.red += previous[u + v].red / 16;
        pixel.green += previous[u + v].green / 16;
        pixel.blue += previous[u + v].blue / 16;
        if (cube.associate_alpha != MagickFalse)
          pixel.opacity += previous[u + v].opacity / 16;

      }

      pixel.red += (5 * previous[u].red) / 16;
      pixel.green += (5 * previous[u].green) / 16;
      pixel.blue += (5 * previous[u].blue) / 16;
      if (cube.associate_alpha != MagickFalse)
        pixel.opacity += (5 * previous[u].opacity) / 16;

      if (x > 0)
      {
        pixel.red += (3 * previous[u - v].red) / 16;
        pixel.green += (3 * previous[u - v].green) / 16;
        pixel.blue += (3 * previous[u - v].blue) / 16;
        if (cube.associate_alpha != MagickFalse)
          pixel.opacity += (3 * previous[u - v].opacity) / 16;

      }

    }

    pixel.red = (MagickRealType) ClampToUnsignedQuantum(pixel.red);
    pixel.green = (MagickRealType) ClampToUnsignedQuantum(pixel.green);
    pixel.blue = (MagickRealType) ClampToUnsignedQuantum(pixel.blue);
    if (cube.associate_alpha != MagickFalse)
      pixel.opacity = (MagickRealType) ClampToUnsignedQuantum(pixel.opacity);

    i = CacheOffset(&cube, &pixel);
    if (cube.cache[i] < 0)
    {
      register NodeInfo *node_info;
      register size_t id;
      node_info = cube.root;
      for (index = 8 - 1; ((ssize_t) index) > 0; index--)
      {
        id = ColorToNodeId(&cube, &pixel, index);
        if (node_info->child[id] == ((NodeInfo *) 0))
          break;

        node_info = node_info->child[id];
      }

      cube.target = pixel;
      cube.distance = (MagickRealType) (((4.0 * (QuantumRange + 1.0)) * (QuantumRange + 1.0)) + 1.0);
      ClosestColor(image, &cube, node_info->parent);
      cube.cache[i] = (ssize_t) cube.color_number;
    }

    index = (size_t) cube.cache[i];
    if (image->storage_class == PseudoClass)
      SetPixelIndex(indexes + u, index);

    if (cube.quantize_info->measure_error == MagickFalse)
    {
      SetPixelRGB(q + u, image->colormap + index);
      if (cube.associate_alpha != MagickFalse)
        SetPixelOpacity(q + u, image->colormap[index].opacity);

    }

    if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
      status = MagickFalse;

    AssociateAlphaPixel(&cube, image->colormap + index, &color);
    current[u].red = pixel.red - color.red;
    current[u].green = pixel.green - color.green;
    current[u].blue = pixel.blue - color.blue;
    if (cube.associate_alpha != MagickFalse)
      current[u].opacity = pixel.opacity - color.opacity;

    if (image->progress_monitor != ((MagickProgressMonitor) 0))
    {
      MagickBooleanType proceed;
      #pragma omp critical (MagickCore_FloydSteinbergDither)
      proceed = SetImageProgress(image, "Dither/Image", (MagickOffsetType) y, image->rows);
      if (proceed == MagickFalse)
        status = MagickFalse;

    }

  }

}

inline static int GetOpenMPThreadId(void)
{
  return 0;
}


inline static void AssociateAlphaPixel(const CubeInfo *cube_info, const PixelPacket *pixel, RealPixelPacket *alpha_pixel)
{
  MagickRealType alpha;
  if ((cube_info->associate_alpha == MagickFalse) || (pixel->opacity == ((Quantum) 0UL)))
  {
    alpha_pixel->red = (MagickRealType) GetPixelRed(pixel);
    alpha_pixel->green = (MagickRealType) GetPixelGreen(pixel);
    alpha_pixel->blue = (MagickRealType) GetPixelBlue(pixel);
    alpha_pixel->opacity = (MagickRealType) GetPixelOpacity(pixel);
    return;
  }

  alpha = (MagickRealType) ((((double) 1.0) / ((double) QuantumRange)) * (QuantumRange - GetPixelOpacity(pixel)));
  alpha_pixel->red = alpha * GetPixelRed(pixel);
  alpha_pixel->green = alpha * GetPixelGreen(pixel);
  alpha_pixel->blue = alpha * GetPixelBlue(pixel);
  alpha_pixel->opacity = (MagickRealType) GetPixelOpacity(pixel);
}


inline static Quantum ClampToUnsignedQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= QuantumRange)
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToUnsignedQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= QuantumRange)
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToUnsignedQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= QuantumRange)
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToUnsignedQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= QuantumRange)
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static ssize_t CacheOffset(CubeInfo *cube_info, const RealPixelPacket *pixel)
{
  ssize_t offset;
  offset = (ssize_t) ((((ScaleQuantumToChar(ClampToUnsignedQuantum(pixel->red)) >> 2) << (0 * (8 - 2))) | ((ScaleQuantumToChar(ClampToUnsignedQuantum(pixel->green)) >> 2) << (1 * (8 - 2)))) | ((ScaleQuantumToChar(ClampToUnsignedQuantum(pixel->blue)) >> 2) << (2 * (8 - 2))));
  if (cube_info->associate_alpha != MagickFalse)
    offset |= (ScaleQuantumToChar(ClampToUnsignedQuantum(pixel->opacity)) >> 2) << (3 * (8 - 2));

  return offset;
}


inline static size_t ColorToNodeId(const CubeInfo *cube_info, const RealPixelPacket *pixel, size_t index)
{
  size_t id;
  id = (size_t) ((((ScaleQuantumToChar(ClampToUnsignedQuantum(GetPixelRed(pixel))) >> index) & 0x01) | (((ScaleQuantumToChar(ClampToUnsignedQuantum(GetPixelGreen(pixel))) >> index) & 0x01) << 1)) | (((ScaleQuantumToChar(ClampToUnsignedQuantum(GetPixelBlue(pixel))) >> index) & 0x01) << 2));
  if (cube_info->associate_alpha != MagickFalse)
    id |= ((ScaleQuantumToChar(ClampToUnsignedQuantum(GetPixelOpacity(pixel))) >> index) & 0x1) << 3;

  return id;
}


static void ClosestColor(const Image *image, CubeInfo *cube_info, const NodeInfo *node_info)
{
  register ssize_t i;
  size_t number_children;
  number_children = (cube_info->associate_alpha == MagickFalse) ? (8UL) : (16UL);
  for (i = 0; i < ((ssize_t) number_children); i++)
    if (node_info->child[i] != ((NodeInfo *) 0))
    ClosestColor(image, cube_info, node_info->child[i]);


  if (node_info->number_unique != 0)
  {
    MagickRealType pixel;
    register MagickRealType alpha;
    register MagickRealType beta;
    register MagickRealType distance;
    register PixelPacket * restrict p;
    register RealPixelPacket * restrict q;
    p = image->colormap + node_info->color_number;
    q = &cube_info->target;
    alpha = 1.0;
    beta = 1.0;
    if (cube_info->associate_alpha != MagickFalse)
    {
      alpha = (MagickRealType) ((((double) 1.0) / ((double) QuantumRange)) * GetPixelAlpha(p));
      beta = (MagickRealType) ((((double) 1.0) / ((double) QuantumRange)) * GetPixelAlpha(q));
    }

    pixel = (alpha * GetPixelRed(p)) - (beta * GetPixelRed(q));
    distance = pixel * pixel;
    if (distance <= cube_info->distance)
    {
      pixel = (alpha * GetPixelGreen(p)) - (beta * GetPixelGreen(q));
      distance += pixel * pixel;
      if (distance <= cube_info->distance)
      {
        pixel = (alpha * GetPixelBlue(p)) - (beta * GetPixelBlue(q));
        distance += pixel * pixel;
        if (distance <= cube_info->distance)
        {
          pixel = alpha - beta;
          distance += pixel * pixel;
          if (distance <= cube_info->distance)
          {
            cube_info->distance = distance;
            cube_info->color_number = node_info->color_number;
          }

        }

      }

    }

  }

}


inline static void AssociateAlphaPixel(const CubeInfo *cube_info, const PixelPacket *pixel, RealPixelPacket *alpha_pixel)
{
  MagickRealType alpha;
  if ((cube_info->associate_alpha == MagickFalse) || (pixel->opacity == ((Quantum) 0UL)))
  {
    alpha_pixel->red = (MagickRealType) GetPixelRed(pixel);
    alpha_pixel->green = (MagickRealType) GetPixelGreen(pixel);
    alpha_pixel->blue = (MagickRealType) GetPixelBlue(pixel);
    alpha_pixel->opacity = (MagickRealType) GetPixelOpacity(pixel);
    return;
  }

  alpha = (MagickRealType) ((((double) 1.0) / ((double) QuantumRange)) * (QuantumRange - GetPixelOpacity(pixel)));
  alpha_pixel->red = alpha * GetPixelRed(pixel);
  alpha_pixel->green = alpha * GetPixelGreen(pixel);
  alpha_pixel->blue = alpha * GetPixelBlue(pixel);
  alpha_pixel->opacity = (MagickRealType) GetPixelOpacity(pixel);
}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

