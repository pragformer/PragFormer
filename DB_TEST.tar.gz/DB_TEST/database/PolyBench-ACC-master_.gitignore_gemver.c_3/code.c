for (i = 0; i < POLYBENCH_LOOP_BOUND(4000, n); i++)
  for (j = 0; j < POLYBENCH_LOOP_BOUND(4000, n); j++)
  w[i] = w[i] + ((alpha * A[i][j]) * x[j]);

