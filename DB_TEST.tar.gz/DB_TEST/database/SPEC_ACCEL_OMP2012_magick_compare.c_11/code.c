for (i = 0; i < ((ssize_t) CompositeChannels); i++)
{
  MagickRealType gamma;
  gamma = image_statistics[i].standard_deviation * reconstruct_statistics[i].standard_deviation;
  gamma = 1.0 / ((fabs((double) gamma) <= MagickEpsilon) ? (1.0) : (gamma));
  distortion[i] = (QuantumRange * gamma) * distortion[i];
}
