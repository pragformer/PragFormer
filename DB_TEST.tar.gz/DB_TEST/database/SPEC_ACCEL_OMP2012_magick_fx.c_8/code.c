for (y = 0; y < ((ssize_t) image->rows); y++)
{
  const int id = GetOpenMPThreadId();
  MagickBooleanType sync;
  register const IndexPacket * restrict indexes;
  register const PixelPacket * restrict p;
  register IndexPacket * restrict noise_indexes;
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  q = GetCacheViewAuthenticPixels(noise_view, 0, y, noise_image->columns, 1, exception);
  if ((p == ((PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewVirtualIndexQueue(image_view);
  noise_indexes = GetCacheViewAuthenticIndexQueue(noise_view);
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    if ((channel & RedChannel) != 0)
      SetPixelRed(q, ClampToQuantum(GenerateDifferentialNoise(random_info[id], GetPixelRed(p), noise_type, attenuate)));

    if ((channel & GreenChannel) != 0)
      SetPixelGreen(q, ClampToQuantum(GenerateDifferentialNoise(random_info[id], GetPixelGreen(p), noise_type, attenuate)));

    if ((channel & BlueChannel) != 0)
      SetPixelBlue(q, ClampToQuantum(GenerateDifferentialNoise(random_info[id], GetPixelBlue(p), noise_type, attenuate)));

    if ((channel & OpacityChannel) != 0)
      SetPixelOpacity(q, ClampToQuantum(GenerateDifferentialNoise(random_info[id], GetPixelOpacity(p), noise_type, attenuate)));

    if (((channel & IndexChannel) != 0) && (image->colorspace == CMYKColorspace))
      SetPixelIndex(noise_indexes + x, ClampToQuantum(GenerateDifferentialNoise(random_info[id], GetPixelIndex(indexes + x), noise_type, attenuate)));

    p++;
    q++;
  }

  sync = SyncCacheViewAuthenticPixels(noise_view, exception);
  if (sync == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_AddNoiseImage)
    proceed = SetImageProgress(image, "AddNoise/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static int GetOpenMPThreadId(void)
{
  return 0;
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

