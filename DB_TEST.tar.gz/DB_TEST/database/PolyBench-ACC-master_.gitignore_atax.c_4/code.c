for (i = 0; i < nx; i++)
{
  fprintf(stderr, "%0.2lf ", y[i]);
  if ((i % 20) == 0)
    fprintf(stderr, "\n");

}
