for (i = 0; i < ((ssize_t) image->colors); i++)
  switch (colorspace)
{
  case HSBColorspace:
  {
    ModulateHSB(percent_hue, percent_saturation, percent_brightness, &image->colormap[i].red, &image->colormap[i].green, &image->colormap[i].blue);
    break;
  }

  case HSLColorspace:

  default:
  {
    ModulateHSL(percent_hue, percent_saturation, percent_brightness, &image->colormap[i].red, &image->colormap[i].green, &image->colormap[i].blue);
    break;
  }

  case HWBColorspace:
  {
    ModulateHWB(percent_hue, percent_saturation, percent_brightness, &image->colormap[i].red, &image->colormap[i].green, &image->colormap[i].blue);
    break;
  }

}


static void ModulateHSB(const double percent_hue, const double percent_saturation, const double percent_brightness, Quantum *red, Quantum *green, Quantum *blue)
{
  double brightness;
  double hue;
  double saturation;
  assert(red != ((Quantum *) 0));
  assert(green != ((Quantum *) 0));
  assert(blue != ((Quantum *) 0));
  ConvertRGBToHSB(*red, *green, *blue, &hue, &saturation, &brightness);
  hue += 0.5 * ((0.01 * percent_hue) - 1.0);
  while (hue < 0.0)
    hue += 1.0;

  while (hue > 1.0)
    hue -= 1.0;

  saturation *= 0.01 * percent_saturation;
  brightness *= 0.01 * percent_brightness;
  ConvertHSBToRGB(hue, saturation, brightness, red, green, blue);
}


static void ModulateHSL(const double percent_hue, const double percent_saturation, const double percent_lightness, Quantum *red, Quantum *green, Quantum *blue)
{
  double hue;
  double lightness;
  double saturation;
  assert(red != ((Quantum *) 0));
  assert(green != ((Quantum *) 0));
  assert(blue != ((Quantum *) 0));
  ConvertRGBToHSL(*red, *green, *blue, &hue, &saturation, &lightness);
  hue += 0.5 * ((0.01 * percent_hue) - 1.0);
  while (hue < 0.0)
    hue += 1.0;

  while (hue > 1.0)
    hue -= 1.0;

  saturation *= 0.01 * percent_saturation;
  lightness *= 0.01 * percent_lightness;
  ConvertHSLToRGB(hue, saturation, lightness, red, green, blue);
}


static void ModulateHWB(const double percent_hue, const double percent_whiteness, const double percent_blackness, Quantum *red, Quantum *green, Quantum *blue)
{
  double blackness;
  double hue;
  double whiteness;
  assert(red != ((Quantum *) 0));
  assert(green != ((Quantum *) 0));
  assert(blue != ((Quantum *) 0));
  ConvertRGBToHWB(*red, *green, *blue, &hue, &whiteness, &blackness);
  hue += 0.5 * ((0.01 * percent_hue) - 1.0);
  while (hue < 0.0)
    hue += 1.0;

  while (hue > 1.0)
    hue -= 1.0;

  blackness *= 0.01 * percent_blackness;
  whiteness *= 0.01 * percent_whiteness;
  ConvertHWBToRGB(hue, whiteness, blackness, red, green, blue);
}

