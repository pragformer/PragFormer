for (q = primitive; (*q) != '\0';)
{
  GetMagickToken(q, &q, keyword);
  if ((*keyword) == '\0')
    break;

  if ((*keyword) == '#')
  {
    while (((*q) != '\n') && ((*q) != '\0'))
      q++;

    continue;
  }

  p = (q - strlen(keyword)) - 1;
  primitive_type = UndefinedPrimitive;
  current = graphic_context[n]->affine;
  GetAffineMatrix(&affine);
  switch (*keyword)
  {
    case ';':
      break;

    case 'a':

    case 'A':
    {
      if (LocaleCompare("affine", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        affine.sx = InterpretLocaleValue(token, (char **) 0);
        GetMagickToken(q, &q, token);
        if ((*token) == ',')
          GetMagickToken(q, &q, token);

        affine.rx = InterpretLocaleValue(token, (char **) 0);
        GetMagickToken(q, &q, token);
        if ((*token) == ',')
          GetMagickToken(q, &q, token);

        affine.ry = InterpretLocaleValue(token, (char **) 0);
        GetMagickToken(q, &q, token);
        if ((*token) == ',')
          GetMagickToken(q, &q, token);

        affine.sy = InterpretLocaleValue(token, (char **) 0);
        GetMagickToken(q, &q, token);
        if ((*token) == ',')
          GetMagickToken(q, &q, token);

        affine.tx = InterpretLocaleValue(token, (char **) 0);
        GetMagickToken(q, &q, token);
        if ((*token) == ',')
          GetMagickToken(q, &q, token);

        affine.ty = InterpretLocaleValue(token, (char **) 0);
        break;
      }

      if (LocaleCompare("arc", keyword) == 0)
      {
        primitive_type = ArcPrimitive;
        break;
      }

      status = MagickFalse;
      break;
    }

    case 'b':

    case 'B':
    {
      if (LocaleCompare("bezier", keyword) == 0)
      {
        primitive_type = BezierPrimitive;
        break;
      }

      if (LocaleCompare("border-color", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        (void) QueryColorDatabase(token, &graphic_context[n]->border_color, &image->exception);
        break;
      }

      status = MagickFalse;
      break;
    }

    case 'c':

    case 'C':
    {
      if (LocaleCompare("clip-path", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        (void) CloneString(&graphic_context[n]->clip_mask, token);
        (void) DrawClipPath(image, graphic_context[n], graphic_context[n]->clip_mask);
        break;
      }

      if (LocaleCompare("clip-rule", keyword) == 0)
      {
        ssize_t fill_rule;
        GetMagickToken(q, &q, token);
        fill_rule = ParseCommandOption(MagickFillRuleOptions, MagickFalse, token);
        if (fill_rule == (-1))
        {
          status = MagickFalse;
          break;
        }

        graphic_context[n]->fill_rule = (FillRule) fill_rule;
        break;
      }

      if (LocaleCompare("clip-units", keyword) == 0)
      {
        ssize_t clip_units;
        GetMagickToken(q, &q, token);
        clip_units = ParseCommandOption(MagickClipPathOptions, MagickFalse, token);
        if (clip_units == (-1))
        {
          status = MagickFalse;
          break;
        }

        graphic_context[n]->clip_units = (ClipPathUnits) clip_units;
        if (clip_units == ObjectBoundingBox)
        {
          GetAffineMatrix(&current);
          affine.sx = draw_info->bounds.x2;
          affine.sy = draw_info->bounds.y2;
          affine.tx = draw_info->bounds.x1;
          affine.ty = draw_info->bounds.y1;
          break;
        }

        break;
      }

      if (LocaleCompare("circle", keyword) == 0)
      {
        primitive_type = CirclePrimitive;
        break;
      }

      if (LocaleCompare("color", keyword) == 0)
      {
        primitive_type = ColorPrimitive;
        break;
      }

      status = MagickFalse;
      break;
    }

    case 'd':

    case 'D':
    {
      if (LocaleCompare("decorate", keyword) == 0)
      {
        ssize_t decorate;
        GetMagickToken(q, &q, token);
        decorate = ParseCommandOption(MagickDecorateOptions, MagickFalse, token);
        if (decorate == (-1))
        {
          status = MagickFalse;
          break;
        }

        graphic_context[n]->decorate = (DecorationType) decorate;
        break;
      }

      status = MagickFalse;
      break;
    }

    case 'e':

    case 'E':
    {
      if (LocaleCompare("ellipse", keyword) == 0)
      {
        primitive_type = EllipsePrimitive;
        break;
      }

      if (LocaleCompare("encoding", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        (void) CloneString(&graphic_context[n]->encoding, token);
        break;
      }

      status = MagickFalse;
      break;
    }

    case 'f':

    case 'F':
    {
      if (LocaleCompare("fill", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        (void) FormatLocaleString(pattern, 4096, "%s", token);
        if (GetImageArtifact(image, pattern) != ((const char *) 0))
          (void) DrawPatternPath(image, draw_info, token, &graphic_context[n]->fill_pattern);
        else
        {
          status = QueryColorDatabase(token, &graphic_context[n]->fill, &image->exception);
          if (status == MagickFalse)
          {
            ImageInfo *pattern_info;
            pattern_info = AcquireImageInfo();
            (void) CopyMagickString(pattern_info->filename, token, 4096);
            graphic_context[n]->fill_pattern = ReadImage(pattern_info, &image->exception);
            CatchException(&image->exception);
            pattern_info = DestroyImageInfo(pattern_info);
          }

        }

        break;
      }

      if (LocaleCompare("fill-opacity", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        factor = (strchr(token, '%') != ((char *) 0)) ? (0.01) : (1.0);
        graphic_context[n]->fill.opacity = ClampToQuantum(((MagickRealType) QuantumRange) * (1.0 - (factor * InterpretLocaleValue(token, (char **) 0))));
        break;
      }

      if (LocaleCompare("fill-rule", keyword) == 0)
      {
        ssize_t fill_rule;
        GetMagickToken(q, &q, token);
        fill_rule = ParseCommandOption(MagickFillRuleOptions, MagickFalse, token);
        if (fill_rule == (-1))
        {
          status = MagickFalse;
          break;
        }

        graphic_context[n]->fill_rule = (FillRule) fill_rule;
        break;
      }

      if (LocaleCompare("font", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        (void) CloneString(&graphic_context[n]->font, token);
        if (LocaleCompare("none", token) == 0)
          graphic_context[n]->font = (char *) RelinquishMagickMemory(graphic_context[n]->font);

        break;
      }

      if (LocaleCompare("font-family", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        (void) CloneString(&graphic_context[n]->family, token);
        break;
      }

      if (LocaleCompare("font-size", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        graphic_context[n]->pointsize = InterpretLocaleValue(token, (char **) 0);
        break;
      }

      if (LocaleCompare("font-stretch", keyword) == 0)
      {
        ssize_t stretch;
        GetMagickToken(q, &q, token);
        stretch = ParseCommandOption(MagickStretchOptions, MagickFalse, token);
        if (stretch == (-1))
        {
          status = MagickFalse;
          break;
        }

        graphic_context[n]->stretch = (StretchType) stretch;
        break;
      }

      if (LocaleCompare("font-style", keyword) == 0)
      {
        ssize_t style;
        GetMagickToken(q, &q, token);
        style = ParseCommandOption(MagickStyleOptions, MagickFalse, token);
        if (style == (-1))
        {
          status = MagickFalse;
          break;
        }

        graphic_context[n]->style = (StyleType) style;
        break;
      }

      if (LocaleCompare("font-weight", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        graphic_context[n]->weight = StringToUnsignedLong(token);
        if (LocaleCompare(token, "all") == 0)
          graphic_context[n]->weight = 0;

        if (LocaleCompare(token, "bold") == 0)
          graphic_context[n]->weight = 700;

        if (LocaleCompare(token, "bolder") == 0)
          if (graphic_context[n]->weight <= 800)
          graphic_context[n]->weight += 100;


        if (LocaleCompare(token, "lighter") == 0)
          if (graphic_context[n]->weight >= 100)
          graphic_context[n]->weight -= 100;


        if (LocaleCompare(token, "normal") == 0)
          graphic_context[n]->weight = 400;

        break;
      }

      status = MagickFalse;
      break;
    }

    case 'g':

    case 'G':
    {
      if (LocaleCompare("gradient-units", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        break;
      }

      if (LocaleCompare("gravity", keyword) == 0)
      {
        ssize_t gravity;
        GetMagickToken(q, &q, token);
        gravity = ParseCommandOption(MagickGravityOptions, MagickFalse, token);
        if (gravity == (-1))
        {
          status = MagickFalse;
          break;
        }

        graphic_context[n]->gravity = (GravityType) gravity;
        break;
      }

      status = MagickFalse;
      break;
    }

    case 'i':

    case 'I':
    {
      if (LocaleCompare("image", keyword) == 0)
      {
        ssize_t compose;
        primitive_type = ImagePrimitive;
        GetMagickToken(q, &q, token);
        compose = ParseCommandOption(MagickComposeOptions, MagickFalse, token);
        if (compose == (-1))
        {
          status = MagickFalse;
          break;
        }

        graphic_context[n]->compose = (CompositeOperator) compose;
        break;
      }

      if (LocaleCompare("interline-spacing", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        graphic_context[n]->interline_spacing = InterpretLocaleValue(token, (char **) 0);
        break;
      }

      if (LocaleCompare("interword-spacing", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        graphic_context[n]->interword_spacing = InterpretLocaleValue(token, (char **) 0);
        break;
      }

      status = MagickFalse;
      break;
    }

    case 'k':

    case 'K':
    {
      if (LocaleCompare("kerning", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        graphic_context[n]->kerning = InterpretLocaleValue(token, (char **) 0);
        break;
      }

      status = MagickFalse;
      break;
    }

    case 'l':

    case 'L':
    {
      if (LocaleCompare("line", keyword) == 0)
      {
        primitive_type = LinePrimitive;
        break;
      }

      status = MagickFalse;
      break;
    }

    case 'm':

    case 'M':
    {
      if (LocaleCompare("matte", keyword) == 0)
      {
        primitive_type = MattePrimitive;
        break;
      }

      status = MagickFalse;
      break;
    }

    case 'o':

    case 'O':
    {
      if (LocaleCompare("offset", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        break;
      }

      if (LocaleCompare("opacity", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        factor = (strchr(token, '%') != ((char *) 0)) ? (0.01) : (1.0);
        graphic_context[n]->opacity = ClampToQuantum(((MagickRealType) QuantumRange) * (1.0 - (((1.0 - ((((double) 1.0) / ((double) QuantumRange)) * graphic_context[n]->opacity)) * factor) * InterpretLocaleValue(token, (char **) 0))));
        graphic_context[n]->fill.opacity = graphic_context[n]->opacity;
        graphic_context[n]->stroke.opacity = graphic_context[n]->opacity;
        break;
      }

      status = MagickFalse;
      break;
    }

    case 'p':

    case 'P':
    {
      if (LocaleCompare("path", keyword) == 0)
      {
        primitive_type = PathPrimitive;
        break;
      }

      if (LocaleCompare("point", keyword) == 0)
      {
        primitive_type = PointPrimitive;
        break;
      }

      if (LocaleCompare("polyline", keyword) == 0)
      {
        primitive_type = PolylinePrimitive;
        break;
      }

      if (LocaleCompare("polygon", keyword) == 0)
      {
        primitive_type = PolygonPrimitive;
        break;
      }

      if (LocaleCompare("pop", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        if (LocaleCompare("clip-path", token) == 0)
          break;

        if (LocaleCompare("defs", token) == 0)
          break;

        if (LocaleCompare("gradient", token) == 0)
          break;

        if (LocaleCompare("graphic-context", token) == 0)
        {
          if (n <= 0)
          {
            (void) ThrowMagickException(&image->exception, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 2265, DrawError, "UnbalancedGraphicContextPushPop", "`%s'", token);
            n = 0;
            break;
          }

          if (graphic_context[n]->clip_mask != ((char *) 0))
            if (LocaleCompare(graphic_context[n]->clip_mask, graphic_context[n - 1]->clip_mask) != 0)
            (void) SetImageClipMask(image, (Image *) 0);


          graphic_context[n] = DestroyDrawInfo(graphic_context[n]);
          n--;
          break;
        }

        if (LocaleCompare("pattern", token) == 0)
          break;

        status = MagickFalse;
        break;
      }

      if (LocaleCompare("push", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        if (LocaleCompare("clip-path", token) == 0)
        {
          char name[4096];
          GetMagickToken(q, &q, token);
          (void) FormatLocaleString(name, 4096, "%s", token);
          for (p = q; (*q) != '\0';)
          {
            GetMagickToken(q, &q, token);
            if (LocaleCompare(token, "pop") != 0)
              continue;

            GetMagickToken(q, (const char **) 0, token);
            if (LocaleCompare(token, "clip-path") != 0)
              continue;

            break;
          }

          (void) CopyMagickString(token, p, (size_t) (((q - p) - 4) + 1));
          (void) SetImageArtifact(image, name, token);
          GetMagickToken(q, &q, token);
          break;
        }

        if (LocaleCompare("gradient", token) == 0)
        {
          char key[2 * 4096];
          char name[4096];
          char type[4096];
          SegmentInfo segment;
          GetMagickToken(q, &q, token);
          (void) CopyMagickString(name, token, 4096);
          GetMagickToken(q, &q, token);
          (void) CopyMagickString(type, token, 4096);
          GetMagickToken(q, &q, token);
          segment.x1 = InterpretLocaleValue(token, (char **) 0);
          GetMagickToken(q, &q, token);
          if ((*token) == ',')
            GetMagickToken(q, &q, token);

          segment.y1 = InterpretLocaleValue(token, (char **) 0);
          GetMagickToken(q, &q, token);
          if ((*token) == ',')
            GetMagickToken(q, &q, token);

          segment.x2 = InterpretLocaleValue(token, (char **) 0);
          GetMagickToken(q, &q, token);
          if ((*token) == ',')
            GetMagickToken(q, &q, token);

          segment.y2 = InterpretLocaleValue(token, (char **) 0);
          if (LocaleCompare(type, "radial") == 0)
          {
            GetMagickToken(q, &q, token);
            if ((*token) == ',')
              GetMagickToken(q, &q, token);

          }

          for (p = q; (*q) != '\0';)
          {
            GetMagickToken(q, &q, token);
            if (LocaleCompare(token, "pop") != 0)
              continue;

            GetMagickToken(q, (const char **) 0, token);
            if (LocaleCompare(token, "gradient") != 0)
              continue;

            break;
          }

          (void) CopyMagickString(token, p, (size_t) (((q - p) - 4) + 1));
          bounds.x1 = ((graphic_context[n]->affine.sx * segment.x1) + (graphic_context[n]->affine.ry * segment.y1)) + graphic_context[n]->affine.tx;
          bounds.y1 = ((graphic_context[n]->affine.rx * segment.x1) + (graphic_context[n]->affine.sy * segment.y1)) + graphic_context[n]->affine.ty;
          bounds.x2 = ((graphic_context[n]->affine.sx * segment.x2) + (graphic_context[n]->affine.ry * segment.y2)) + graphic_context[n]->affine.tx;
          bounds.y2 = ((graphic_context[n]->affine.rx * segment.x2) + (graphic_context[n]->affine.sy * segment.y2)) + graphic_context[n]->affine.ty;
          (void) FormatLocaleString(key, 4096, "%s", name);
          (void) SetImageArtifact(image, key, token);
          (void) FormatLocaleString(key, 4096, "%s-geometry", name);
          (void) FormatLocaleString(geometry, 4096, "%gx%g%+.15g%+.15g", MagickMax(fabs((bounds.x2 - bounds.x1) + 1.0), 1.0), MagickMax(fabs((bounds.y2 - bounds.y1) + 1.0), 1.0), bounds.x1, bounds.y1);
          (void) SetImageArtifact(image, key, geometry);
          GetMagickToken(q, &q, token);
          break;
        }

        if (LocaleCompare("pattern", token) == 0)
        {
          RectangleInfo bounds;
          GetMagickToken(q, &q, token);
          (void) CopyMagickString(name, token, 4096);
          GetMagickToken(q, &q, token);
          bounds.x = (ssize_t) ceil(InterpretLocaleValue(token, (char **) 0) - 0.5);
          GetMagickToken(q, &q, token);
          if ((*token) == ',')
            GetMagickToken(q, &q, token);

          bounds.y = (ssize_t) ceil(InterpretLocaleValue(token, (char **) 0) - 0.5);
          GetMagickToken(q, &q, token);
          if ((*token) == ',')
            GetMagickToken(q, &q, token);

          bounds.width = (size_t) floor(InterpretLocaleValue(token, (char **) 0) + 0.5);
          GetMagickToken(q, &q, token);
          if ((*token) == ',')
            GetMagickToken(q, &q, token);

          bounds.height = (size_t) floor(InterpretLocaleValue(token, (char **) 0) + 0.5);
          for (p = q; (*q) != '\0';)
          {
            GetMagickToken(q, &q, token);
            if (LocaleCompare(token, "pop") != 0)
              continue;

            GetMagickToken(q, (const char **) 0, token);
            if (LocaleCompare(token, "pattern") != 0)
              continue;

            break;
          }

          (void) CopyMagickString(token, p, (size_t) (((q - p) - 4) + 1));
          (void) FormatLocaleString(key, 4096, "%s", name);
          (void) SetImageArtifact(image, key, token);
          (void) FormatLocaleString(key, 4096, "%s-geometry", name);
          (void) FormatLocaleString(geometry, 4096, "%.20gx%.20g%+.20g%+.20g", (double) bounds.width, (double) bounds.height, (double) bounds.x, (double) bounds.y);
          (void) SetImageArtifact(image, key, geometry);
          GetMagickToken(q, &q, token);
          break;
        }

        if (LocaleCompare("graphic-context", token) == 0)
        {
          n++;
          graphic_context = (DrawInfo **) ResizeQuantumMemory(graphic_context, (size_t) (n + 1), sizeof(*graphic_context));
          if (graphic_context == ((DrawInfo **) 0))
          {
            (void) ThrowMagickException(&image->exception, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 2431, ResourceLimitError, "MemoryAllocationFailed", "`%s'", image->filename);
            break;
          }

          graphic_context[n] = CloneDrawInfo((ImageInfo *) 0, graphic_context[n - 1]);
          break;
        }

        if (LocaleCompare("defs", token) == 0)
          break;

        status = MagickFalse;
        break;
      }

      status = MagickFalse;
      break;
    }

    case 'r':

    case 'R':
    {
      if (LocaleCompare("rectangle", keyword) == 0)
      {
        primitive_type = RectanglePrimitive;
        break;
      }

      if (LocaleCompare("rotate", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        angle = InterpretLocaleValue(token, (char **) 0);
        affine.sx = cos(DegreesToRadians(fmod((double) angle, 360.0)));
        affine.rx = sin(DegreesToRadians(fmod((double) angle, 360.0)));
        affine.ry = -sin(DegreesToRadians(fmod((double) angle, 360.0)));
        affine.sy = cos(DegreesToRadians(fmod((double) angle, 360.0)));
        break;
      }

      if (LocaleCompare("roundRectangle", keyword) == 0)
      {
        primitive_type = RoundRectanglePrimitive;
        break;
      }

      status = MagickFalse;
      break;
    }

    case 's':

    case 'S':
    {
      if (LocaleCompare("scale", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        affine.sx = InterpretLocaleValue(token, (char **) 0);
        GetMagickToken(q, &q, token);
        if ((*token) == ',')
          GetMagickToken(q, &q, token);

        affine.sy = InterpretLocaleValue(token, (char **) 0);
        break;
      }

      if (LocaleCompare("skewX", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        angle = InterpretLocaleValue(token, (char **) 0);
        affine.ry = sin(DegreesToRadians(angle));
        break;
      }

      if (LocaleCompare("skewY", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        angle = InterpretLocaleValue(token, (char **) 0);
        affine.rx = -tan(DegreesToRadians(angle) / 2.0);
        break;
      }

      if (LocaleCompare("stop-color", keyword) == 0)
      {
        PixelPacket stop_color;
        GetMagickToken(q, &q, token);
        (void) QueryColorDatabase(token, &stop_color, &image->exception);
        (void) GradientImage(image, LinearGradient, ReflectSpread, &start_color, &stop_color);
        start_color = stop_color;
        GetMagickToken(q, &q, token);
        break;
      }

      if (LocaleCompare("stroke", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        (void) FormatLocaleString(pattern, 4096, "%s", token);
        if (GetImageArtifact(image, pattern) != ((const char *) 0))
          (void) DrawPatternPath(image, draw_info, token, &graphic_context[n]->stroke_pattern);
        else
        {
          status = QueryColorDatabase(token, &graphic_context[n]->stroke, &image->exception);
          if (status == MagickFalse)
          {
            ImageInfo *pattern_info;
            pattern_info = AcquireImageInfo();
            (void) CopyMagickString(pattern_info->filename, token, 4096);
            graphic_context[n]->stroke_pattern = ReadImage(pattern_info, &image->exception);
            CatchException(&image->exception);
            pattern_info = DestroyImageInfo(pattern_info);
          }

        }

        break;
      }

      if (LocaleCompare("stroke-antialias", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        graphic_context[n]->stroke_antialias = (StringToLong(token) != 0) ? (MagickTrue) : (MagickFalse);
        break;
      }

      if (LocaleCompare("stroke-dasharray", keyword) == 0)
      {
        if (graphic_context[n]->dash_pattern != ((double *) 0))
          graphic_context[n]->dash_pattern = (double *) RelinquishMagickMemory(graphic_context[n]->dash_pattern);

        if (IsPoint(q) != MagickFalse)
        {
          const char *p;
          p = q;
          GetMagickToken(p, &p, token);
          if ((*token) == ',')
            GetMagickToken(p, &p, token);

          for (x = 0; IsPoint(token) != MagickFalse; x++)
          {
            GetMagickToken(p, &p, token);
            if ((*token) == ',')
              GetMagickToken(p, &p, token);

          }

          graphic_context[n]->dash_pattern = (double *) AcquireQuantumMemory((size_t) ((2UL * x) + 1UL), sizeof(*graphic_context[n]->dash_pattern));
          if (graphic_context[n]->dash_pattern == ((double *) 0))
          {
            (void) ThrowMagickException(&image->exception, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 2573, ResourceLimitError, "MemoryAllocationFailed", "`%s'", image->filename);
            break;
          }

          for (j = 0; j < x; j++)
          {
            GetMagickToken(q, &q, token);
            if ((*token) == ',')
              GetMagickToken(q, &q, token);

            graphic_context[n]->dash_pattern[j] = InterpretLocaleValue(token, (char **) 0);
          }

          if ((x & 0x01) != 0)
            for (; j < (2 * x); j++)
            graphic_context[n]->dash_pattern[j] = graphic_context[n]->dash_pattern[j - x];


          graphic_context[n]->dash_pattern[j] = 0.0;
          break;
        }

        GetMagickToken(q, &q, token);
        break;
      }

      if (LocaleCompare("stroke-dashoffset", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        graphic_context[n]->dash_offset = InterpretLocaleValue(token, (char **) 0);
        break;
      }

      if (LocaleCompare("stroke-linecap", keyword) == 0)
      {
        ssize_t linecap;
        GetMagickToken(q, &q, token);
        linecap = ParseCommandOption(MagickLineCapOptions, MagickFalse, token);
        if (linecap == (-1))
        {
          status = MagickFalse;
          break;
        }

        graphic_context[n]->linecap = (LineCap) linecap;
        break;
      }

      if (LocaleCompare("stroke-linejoin", keyword) == 0)
      {
        ssize_t linejoin;
        GetMagickToken(q, &q, token);
        linejoin = ParseCommandOption(MagickLineJoinOptions, MagickFalse, token);
        if (linejoin == (-1))
        {
          status = MagickFalse;
          break;
        }

        graphic_context[n]->linejoin = (LineJoin) linejoin;
        break;
      }

      if (LocaleCompare("stroke-miterlimit", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        graphic_context[n]->miterlimit = StringToUnsignedLong(token);
        break;
      }

      if (LocaleCompare("stroke-opacity", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        factor = (strchr(token, '%') != ((char *) 0)) ? (0.01) : (1.0);
        graphic_context[n]->stroke.opacity = ClampToQuantum(((MagickRealType) QuantumRange) * (1.0 - (factor * InterpretLocaleValue(token, (char **) 0))));
        break;
      }

      if (LocaleCompare("stroke-width", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        graphic_context[n]->stroke_width = InterpretLocaleValue(token, (char **) 0);
        break;
      }

      status = MagickFalse;
      break;
    }

    case 't':

    case 'T':
    {
      if (LocaleCompare("text", keyword) == 0)
      {
        primitive_type = TextPrimitive;
        break;
      }

      if (LocaleCompare("text-align", keyword) == 0)
      {
        ssize_t align;
        GetMagickToken(q, &q, token);
        align = ParseCommandOption(MagickAlignOptions, MagickFalse, token);
        if (align == (-1))
        {
          status = MagickFalse;
          break;
        }

        graphic_context[n]->align = (AlignType) align;
        break;
      }

      if (LocaleCompare("text-anchor", keyword) == 0)
      {
        ssize_t align;
        GetMagickToken(q, &q, token);
        align = ParseCommandOption(MagickAlignOptions, MagickFalse, token);
        if (align == (-1))
        {
          status = MagickFalse;
          break;
        }

        graphic_context[n]->align = (AlignType) align;
        break;
      }

      if (LocaleCompare("text-antialias", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        graphic_context[n]->text_antialias = (StringToLong(token) != 0) ? (MagickTrue) : (MagickFalse);
        break;
      }

      if (LocaleCompare("text-undercolor", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        (void) QueryColorDatabase(token, &graphic_context[n]->undercolor, &image->exception);
        break;
      }

      if (LocaleCompare("translate", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        affine.tx = InterpretLocaleValue(token, (char **) 0);
        GetMagickToken(q, &q, token);
        if ((*token) == ',')
          GetMagickToken(q, &q, token);

        affine.ty = InterpretLocaleValue(token, (char **) 0);
        break;
      }

      status = MagickFalse;
      break;
    }

    case 'v':

    case 'V':
    {
      if (LocaleCompare("viewbox", keyword) == 0)
      {
        GetMagickToken(q, &q, token);
        graphic_context[n]->viewbox.x = (ssize_t) ceil(InterpretLocaleValue(token, (char **) 0) - 0.5);
        GetMagickToken(q, &q, token);
        if ((*token) == ',')
          GetMagickToken(q, &q, token);

        graphic_context[n]->viewbox.y = (ssize_t) ceil(InterpretLocaleValue(token, (char **) 0) - 0.5);
        GetMagickToken(q, &q, token);
        if ((*token) == ',')
          GetMagickToken(q, &q, token);

        graphic_context[n]->viewbox.width = (size_t) floor(InterpretLocaleValue(token, (char **) 0) + 0.5);
        GetMagickToken(q, &q, token);
        if ((*token) == ',')
          GetMagickToken(q, &q, token);

        graphic_context[n]->viewbox.height = (size_t) floor(InterpretLocaleValue(token, (char **) 0) + 0.5);
        break;
      }

      status = MagickFalse;
      break;
    }

    default:
    {
      status = MagickFalse;
      break;
    }

  }

  if (status == MagickFalse)
    break;

  if ((((((affine.sx != 1.0) || (affine.rx != 0.0)) || (affine.ry != 0.0)) || (affine.sy != 1.0)) || (affine.tx != 0.0)) || (affine.ty != 0.0))
  {
    graphic_context[n]->affine.sx = (current.sx * affine.sx) + (current.ry * affine.rx);
    graphic_context[n]->affine.rx = (current.rx * affine.sx) + (current.sy * affine.rx);
    graphic_context[n]->affine.ry = (current.sx * affine.ry) + (current.ry * affine.sy);
    graphic_context[n]->affine.sy = (current.rx * affine.ry) + (current.sy * affine.sy);
    graphic_context[n]->affine.tx = ((current.sx * affine.tx) + (current.ry * affine.ty)) + current.tx;
    graphic_context[n]->affine.ty = ((current.rx * affine.tx) + (current.sy * affine.ty)) + current.ty;
  }

  if (primitive_type == UndefinedPrimitive)
  {
    if (image->debug != MagickFalse)
      (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 2773, "  %.*s", (int) (q - p), p);

    continue;
  }

  i = 0;
  j = 0;
  primitive_info[0].point.x = 0.0;
  primitive_info[0].point.y = 0.0;
  for (x = 0; (*q) != '\0'; x++)
  {
    if (IsPoint(q) == MagickFalse)
      break;

    GetMagickToken(q, &q, token);
    point.x = InterpretLocaleValue(token, (char **) 0);
    GetMagickToken(q, &q, token);
    if ((*token) == ',')
      GetMagickToken(q, &q, token);

    point.y = InterpretLocaleValue(token, (char **) 0);
    GetMagickToken(q, (const char **) 0, token);
    if ((*token) == ',')
      GetMagickToken(q, &q, token);

    primitive_info[i].primitive = primitive_type;
    primitive_info[i].point = point;
    primitive_info[i].coordinates = 0;
    primitive_info[i].method = FloodfillMethod;
    i++;
    if (i < ((ssize_t) number_points))
      continue;

    number_points <<= 1;
    primitive_info = (PrimitiveInfo *) ResizeQuantumMemory(primitive_info, (size_t) number_points, sizeof(*primitive_info));
    if (primitive_info == ((PrimitiveInfo *) 0))
    {
      (void) ThrowMagickException(&image->exception, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 2812, ResourceLimitError, "MemoryAllocationFailed", "`%s'", image->filename);
      break;
    }

  }

  primitive_info[j].primitive = primitive_type;
  primitive_info[j].coordinates = (size_t) x;
  primitive_info[j].method = FloodfillMethod;
  primitive_info[j].text = (char *) 0;
  bounds.x1 = primitive_info[j].point.x;
  bounds.y1 = primitive_info[j].point.y;
  bounds.x2 = primitive_info[j].point.x;
  bounds.y2 = primitive_info[j].point.y;
  for (k = 1; k < ((ssize_t) primitive_info[j].coordinates); k++)
  {
    point = primitive_info[j + k].point;
    if (point.x < bounds.x1)
      bounds.x1 = point.x;

    if (point.y < bounds.y1)
      bounds.y1 = point.y;

    if (point.x > bounds.x2)
      bounds.x2 = point.x;

    if (point.y > bounds.y2)
      bounds.y2 = point.y;

  }

  length = primitive_info[j].coordinates;
  switch (primitive_type)
  {
    case RectanglePrimitive:
    {
      length *= 5;
      break;
    }

    case RoundRectanglePrimitive:
    {
      length *= 5 + (8 * 200);
      break;
    }

    case BezierPrimitive:
    {
      if (primitive_info[j].coordinates > 107)
        (void) ThrowMagickException(&image->exception, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 2859, DrawError, "TooManyBezierCoordinates", "`%s'", token);

      length = 200 * primitive_info[j].coordinates;
      break;
    }

    case PathPrimitive:
    {
      char *s;
      char *t;
      GetMagickToken(q, &q, token);
      length = 1;
      t = token;
      for (s = token; (*s) != '\0'; s = t)
      {
        double value;
        value = InterpretLocaleValue(s, &t);
        (void) value;
        if (s == t)
        {
          t++;
          continue;
        }

        length++;
      }

      length = (length * 200) / 2;
      break;
    }

    case CirclePrimitive:

    case ArcPrimitive:

    case EllipsePrimitive:
    {
      MagickRealType alpha;
      MagickRealType beta;
      MagickRealType radius;
      alpha = bounds.x2 - bounds.x1;
      beta = bounds.y2 - bounds.y1;
      radius = hypot((double) alpha, (double) beta);
      length = ((2 * ((size_t) ceil(((double) 3.14159265358979323846264338327950288419716939937510L) * radius))) + (6 * 200)) + 360;
      break;
    }

    default:
      break;

  }

  if (((size_t) (i + length)) >= number_points)
  {
    number_points += length + 1;
    primitive_info = (PrimitiveInfo *) ResizeQuantumMemory(primitive_info, (size_t) number_points, sizeof(*primitive_info));
    if (primitive_info == ((PrimitiveInfo *) 0))
    {
      (void) ThrowMagickException(&image->exception, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 2918, ResourceLimitError, "MemoryAllocationFailed", "`%s'", image->filename);
      break;
    }

  }

  switch (primitive_type)
  {
    case PointPrimitive:

    default:
    {
      if (primitive_info[j].coordinates != 1)
      {
        status = MagickFalse;
        break;
      }

      TracePoint(primitive_info + j, primitive_info[j].point);
      i = (ssize_t) (j + primitive_info[j].coordinates);
      break;
    }

    case LinePrimitive:
    {
      if (primitive_info[j].coordinates != 2)
      {
        status = MagickFalse;
        break;
      }

      TraceLine(primitive_info + j, primitive_info[j].point, primitive_info[j + 1].point);
      i = (ssize_t) (j + primitive_info[j].coordinates);
      break;
    }

    case RectanglePrimitive:
    {
      if (primitive_info[j].coordinates != 2)
      {
        status = MagickFalse;
        break;
      }

      TraceRectangle(primitive_info + j, primitive_info[j].point, primitive_info[j + 1].point);
      i = (ssize_t) (j + primitive_info[j].coordinates);
      break;
    }

    case RoundRectanglePrimitive:
    {
      if (primitive_info[j].coordinates != 3)
      {
        status = MagickFalse;
        break;
      }

      TraceRoundRectangle(primitive_info + j, primitive_info[j].point, primitive_info[j + 1].point, primitive_info[j + 2].point);
      i = (ssize_t) (j + primitive_info[j].coordinates);
      break;
    }

    case ArcPrimitive:
    {
      if (primitive_info[j].coordinates != 3)
      {
        primitive_type = UndefinedPrimitive;
        break;
      }

      TraceArc(primitive_info + j, primitive_info[j].point, primitive_info[j + 1].point, primitive_info[j + 2].point);
      i = (ssize_t) (j + primitive_info[j].coordinates);
      break;
    }

    case EllipsePrimitive:
    {
      if (primitive_info[j].coordinates != 3)
      {
        status = MagickFalse;
        break;
      }

      TraceEllipse(primitive_info + j, primitive_info[j].point, primitive_info[j + 1].point, primitive_info[j + 2].point);
      i = (ssize_t) (j + primitive_info[j].coordinates);
      break;
    }

    case CirclePrimitive:
    {
      if (primitive_info[j].coordinates != 2)
      {
        status = MagickFalse;
        break;
      }

      TraceCircle(primitive_info + j, primitive_info[j].point, primitive_info[j + 1].point);
      i = (ssize_t) (j + primitive_info[j].coordinates);
      break;
    }

    case PolylinePrimitive:
      break;

    case PolygonPrimitive:
    {
      primitive_info[i] = primitive_info[j];
      primitive_info[i].coordinates = 0;
      primitive_info[j].coordinates++;
      i++;
      break;
    }

    case BezierPrimitive:
    {
      if (primitive_info[j].coordinates < 3)
      {
        status = MagickFalse;
        break;
      }

      TraceBezier(primitive_info + j, primitive_info[j].coordinates);
      i = (ssize_t) (j + primitive_info[j].coordinates);
      break;
    }

    case PathPrimitive:
    {
      i = (ssize_t) (j + TracePath(primitive_info + j, token));
      break;
    }

    case ColorPrimitive:

    case MattePrimitive:
    {
      ssize_t method;
      if (primitive_info[j].coordinates != 1)
      {
        status = MagickFalse;
        break;
      }

      GetMagickToken(q, &q, token);
      method = ParseCommandOption(MagickMethodOptions, MagickFalse, token);
      if (method == (-1))
      {
        status = MagickFalse;
        break;
      }

      primitive_info[j].method = (PaintMethod) method;
      break;
    }

    case TextPrimitive:
    {
      if (primitive_info[j].coordinates != 1)
      {
        status = MagickFalse;
        break;
      }

      if ((*token) != ',')
        GetMagickToken(q, &q, token);

      primitive_info[j].text = AcquireString(token);
      break;
    }

    case ImagePrimitive:
    {
      if (primitive_info[j].coordinates != 2)
      {
        status = MagickFalse;
        break;
      }

      GetMagickToken(q, &q, token);
      primitive_info[j].text = AcquireString(token);
      break;
    }

  }

  if (primitive_info == ((PrimitiveInfo *) 0))
    break;

  if (image->debug != MagickFalse)
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 3084, "  %.*s", (int) (q - p), p);

  if (status == MagickFalse)
    break;

  primitive_info[i].primitive = UndefinedPrimitive;
  if (i == 0)
    continue;

  for (i = 0; primitive_info[i].primitive != UndefinedPrimitive; i++)
  {
    point = primitive_info[i].point;
    primitive_info[i].point.x = ((graphic_context[n]->affine.sx * point.x) + (graphic_context[n]->affine.ry * point.y)) + graphic_context[n]->affine.tx;
    primitive_info[i].point.y = ((graphic_context[n]->affine.rx * point.x) + (graphic_context[n]->affine.sy * point.y)) + graphic_context[n]->affine.ty;
    point = primitive_info[i].point;
    if (point.x < graphic_context[n]->bounds.x1)
      graphic_context[n]->bounds.x1 = point.x;

    if (point.y < graphic_context[n]->bounds.y1)
      graphic_context[n]->bounds.y1 = point.y;

    if (point.x > graphic_context[n]->bounds.x2)
      graphic_context[n]->bounds.x2 = point.x;

    if (point.y > graphic_context[n]->bounds.y2)
      graphic_context[n]->bounds.y2 = point.y;

    if (primitive_info[i].primitive == ImagePrimitive)
      break;

    if (i >= ((ssize_t) number_points))
    {
      char *message;
      ExceptionInfo exception;
      GetExceptionInfo(&exception);
      message = GetExceptionMessage(errno);
      (void) ThrowMagickException(&exception, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 3112, ResourceLimitFatalError, ("MemoryAllocationFailed" == ((const char *) 0)) ? ("unknown") : ("MemoryAllocationFailed"), "`%s'", message);
      message = DestroyString(message);
      CatchException(&exception);
      (void) DestroyExceptionInfo(&exception);
      _exit(1);
    }

    ;
  }

  if (graphic_context[n]->render != MagickFalse)
  {
    if (((n != 0) && (graphic_context[n]->clip_mask != ((char *) 0))) && (LocaleCompare(graphic_context[n]->clip_mask, graphic_context[n - 1]->clip_mask) != 0))
      (void) DrawClipPath(image, graphic_context[n], graphic_context[n]->clip_mask);

    (void) DrawPrimitive(image, graphic_context[n], primitive_info);
  }

  if (primitive_info->text != ((char *) 0))
    primitive_info->text = (char *) RelinquishMagickMemory(primitive_info->text);

  proceed = SetImageProgress(image, "Render/Image", q - primitive, (MagickSizeType) primitive_extent);
  if (proceed == MagickFalse)
    break;

}

void GetAffineMatrix(AffineMatrix *affine_matrix)
{
  (void) LogMagickEvent(TraceEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 4694, "...");
  assert(affine_matrix != ((AffineMatrix *) 0));
  (void) ResetMagickMemory(affine_matrix, 0, sizeof(*affine_matrix));
  affine_matrix->sx = 1.0;
  affine_matrix->sy = 1.0;
}


MagickBooleanType DrawClipPath(Image *image, const DrawInfo *draw_info, const char *name)
{
  char clip_mask[4096];
  const char *value;
  DrawInfo *clone_info;
  MagickStatusType status;
  assert(image != ((Image *) 0));
  assert(image->signature == 0xabacadabUL);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(TraceEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 1415, "%s", image->filename);

  assert(draw_info != ((const DrawInfo *) 0));
  (void) FormatLocaleString(clip_mask, 4096, "%s", name);
  value = GetImageArtifact(image, clip_mask);
  if (value == ((const char *) 0))
    return MagickFalse;

  if (image->clip_mask == ((Image *) 0))
  {
    Image *clip_mask;
    clip_mask = CloneImage(image, image->columns, image->rows, MagickTrue, &image->exception);
    if (clip_mask == ((Image *) 0))
      return MagickFalse;

    (void) SetImageClipMask(image, clip_mask);
    clip_mask = DestroyImage(clip_mask);
  }

  (void) QueryColorDatabase("#00000000", &image->clip_mask->background_color, &image->exception);
  image->clip_mask->background_color.opacity = (Quantum) TransparentOpacity;
  (void) SetImageBackgroundColor(image->clip_mask);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 1438, "\nbegin clip-path %s", draw_info->clip_mask);

  clone_info = CloneDrawInfo((ImageInfo *) 0, draw_info);
  (void) CloneString(&clone_info->primitive, value);
  (void) QueryColorDatabase("#ffffff", &clone_info->fill, &image->exception);
  clone_info->clip_mask = (char *) 0;
  status = DrawImage(image->clip_mask, clone_info);
  status |= NegateImage(image->clip_mask, MagickFalse);
  clone_info = DestroyDrawInfo(clone_info);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 1448, "end clip-path");

  return (status != 0) ? (MagickTrue) : (MagickFalse);
}


void GetAffineMatrix(AffineMatrix *affine_matrix)
{
  (void) LogMagickEvent(TraceEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 4694, "...");
  assert(affine_matrix != ((AffineMatrix *) 0));
  (void) ResetMagickMemory(affine_matrix, 0, sizeof(*affine_matrix));
  affine_matrix->sx = 1.0;
  affine_matrix->sy = 1.0;
}


MagickBooleanType DrawPatternPath(Image *image, const DrawInfo *draw_info, const char *name, Image **pattern)
{
  char property[4096];
  const char *geometry;
  const char *path;
  DrawInfo *clone_info;
  ImageInfo *image_info;
  MagickBooleanType status;
  assert(image != ((Image *) 0));
  assert(image->signature == 0xabacadabUL);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(TraceEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 3517, "%s", image->filename);

  assert(draw_info != ((const DrawInfo *) 0));
  assert(name != ((const char *) 0));
  (void) FormatLocaleString(property, 4096, "%s", name);
  path = GetImageArtifact(image, property);
  if (path == ((const char *) 0))
    return MagickFalse;

  (void) FormatLocaleString(property, 4096, "%s-geometry", name);
  geometry = GetImageArtifact(image, property);
  if (geometry == ((const char *) 0))
    return MagickFalse;

  if ((*pattern) != ((Image *) 0))
    *pattern = DestroyImage(*pattern);

  image_info = AcquireImageInfo();
  image_info->size = AcquireString(geometry);
  *pattern = AcquireImage(image_info);
  image_info = DestroyImageInfo(image_info);
  (void) QueryColorDatabase("#00000000", &(*pattern)->background_color, &image->exception);
  (void) SetImageBackgroundColor(*pattern);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 3538, "begin pattern-path %s %s", name, geometry);

  clone_info = CloneDrawInfo((ImageInfo *) 0, draw_info);
  clone_info->fill_pattern = NewImageList();
  clone_info->stroke_pattern = NewImageList();
  (void) CloneString(&clone_info->primitive, path);
  status = DrawImage(*pattern, clone_info);
  clone_info = DestroyDrawInfo(clone_info);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 3547, "end pattern-path");

  return status;
}


inline static unsigned long StringToUnsignedLong(const char *value)
{
  return strtoul(value, (char **) 0, 10);
}


DrawInfo *DestroyDrawInfo(DrawInfo *draw_info)
{
  if (draw_info->debug != MagickFalse)
    (void) LogMagickEvent(TraceEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 817, "...");

  assert(draw_info != ((DrawInfo *) 0));
  assert(draw_info->signature == 0xabacadabUL);
  if (draw_info->primitive != ((char *) 0))
    draw_info->primitive = DestroyString(draw_info->primitive);

  if (draw_info->text != ((char *) 0))
    draw_info->text = DestroyString(draw_info->text);

  if (draw_info->geometry != ((char *) 0))
    draw_info->geometry = DestroyString(draw_info->geometry);

  if (draw_info->tile != ((Image *) 0))
    draw_info->tile = DestroyImage(draw_info->tile);

  if (draw_info->fill_pattern != ((Image *) 0))
    draw_info->fill_pattern = DestroyImage(draw_info->fill_pattern);

  if (draw_info->stroke_pattern != ((Image *) 0))
    draw_info->stroke_pattern = DestroyImage(draw_info->stroke_pattern);

  if (draw_info->font != ((char *) 0))
    draw_info->font = DestroyString(draw_info->font);

  if (draw_info->metrics != ((char *) 0))
    draw_info->metrics = DestroyString(draw_info->metrics);

  if (draw_info->family != ((char *) 0))
    draw_info->family = DestroyString(draw_info->family);

  if (draw_info->encoding != ((char *) 0))
    draw_info->encoding = DestroyString(draw_info->encoding);

  if (draw_info->density != ((char *) 0))
    draw_info->density = DestroyString(draw_info->density);

  if (draw_info->server_name != ((char *) 0))
    draw_info->server_name = (char *) RelinquishMagickMemory(draw_info->server_name);

  if (draw_info->dash_pattern != ((double *) 0))
    draw_info->dash_pattern = (double *) RelinquishMagickMemory(draw_info->dash_pattern);

  if (draw_info->gradient.stops != ((StopInfo *) 0))
    draw_info->gradient.stops = (StopInfo *) RelinquishMagickMemory(draw_info->gradient.stops);

  if (draw_info->clip_mask != ((char *) 0))
    draw_info->clip_mask = DestroyString(draw_info->clip_mask);

  draw_info->signature = ~0xabacadabUL;
  draw_info = (DrawInfo *) RelinquishMagickMemory(draw_info);
  return draw_info;
}


inline static double MagickMax(const double x, const double y)
{
  if (x > y)
    return x;

  return y;
}


inline static double MagickMax(const double x, const double y)
{
  if (x > y)
    return x;

  return y;
}


DrawInfo *CloneDrawInfo(const ImageInfo *image_info, const DrawInfo *draw_info)
{
  DrawInfo *clone_info;
  clone_info = (DrawInfo *) AcquireMagickMemory(sizeof(*clone_info));
  if (clone_info == ((DrawInfo *) 0))
  {
    char *message;
    ExceptionInfo exception;
    GetExceptionInfo(&exception);
    message = GetExceptionMessage(errno);
    (void) ThrowMagickException(&exception, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 242, ResourceLimitFatalError, ("MemoryAllocationFailed" == ((const char *) 0)) ? ("unknown") : ("MemoryAllocationFailed"), "`%s'", message);
    message = DestroyString(message);
    CatchException(&exception);
    (void) DestroyExceptionInfo(&exception);
    _exit(1);
  }

  ;
  GetDrawInfo(image_info, clone_info);
  if (draw_info == ((DrawInfo *) 0))
    return clone_info;

  if (clone_info->primitive != ((char *) 0))
    (void) CloneString(&clone_info->primitive, draw_info->primitive);

  if (draw_info->geometry != ((char *) 0))
    (void) CloneString(&clone_info->geometry, draw_info->geometry);

  clone_info->viewbox = draw_info->viewbox;
  clone_info->affine = draw_info->affine;
  clone_info->gravity = draw_info->gravity;
  clone_info->fill = draw_info->fill;
  clone_info->stroke = draw_info->stroke;
  clone_info->stroke_width = draw_info->stroke_width;
  if (draw_info->fill_pattern != ((Image *) 0))
    clone_info->fill_pattern = CloneImage(draw_info->fill_pattern, 0, 0, MagickTrue, &draw_info->fill_pattern->exception);
  else
    if (draw_info->tile != ((Image *) 0))
    clone_info->fill_pattern = CloneImage(draw_info->tile, 0, 0, MagickTrue, &draw_info->tile->exception);


  clone_info->tile = NewImageList();
  if (draw_info->stroke_pattern != ((Image *) 0))
    clone_info->stroke_pattern = CloneImage(draw_info->stroke_pattern, 0, 0, MagickTrue, &draw_info->stroke_pattern->exception);

  clone_info->stroke_antialias = draw_info->stroke_antialias;
  clone_info->text_antialias = draw_info->text_antialias;
  clone_info->fill_rule = draw_info->fill_rule;
  clone_info->linecap = draw_info->linecap;
  clone_info->linejoin = draw_info->linejoin;
  clone_info->miterlimit = draw_info->miterlimit;
  clone_info->dash_offset = draw_info->dash_offset;
  clone_info->decorate = draw_info->decorate;
  clone_info->compose = draw_info->compose;
  if (draw_info->text != ((char *) 0))
    (void) CloneString(&clone_info->text, draw_info->text);

  if (draw_info->font != ((char *) 0))
    (void) CloneString(&clone_info->font, draw_info->font);

  if (draw_info->metrics != ((char *) 0))
    (void) CloneString(&clone_info->metrics, draw_info->metrics);

  if (draw_info->family != ((char *) 0))
    (void) CloneString(&clone_info->family, draw_info->family);

  clone_info->style = draw_info->style;
  clone_info->stretch = draw_info->stretch;
  clone_info->weight = draw_info->weight;
  if (draw_info->encoding != ((char *) 0))
    (void) CloneString(&clone_info->encoding, draw_info->encoding);

  clone_info->pointsize = draw_info->pointsize;
  clone_info->kerning = draw_info->kerning;
  clone_info->interline_spacing = draw_info->interline_spacing;
  clone_info->interword_spacing = draw_info->interword_spacing;
  clone_info->direction = draw_info->direction;
  if (draw_info->density != ((char *) 0))
    (void) CloneString(&clone_info->density, draw_info->density);

  clone_info->align = draw_info->align;
  clone_info->undercolor = draw_info->undercolor;
  clone_info->border_color = draw_info->border_color;
  if (draw_info->server_name != ((char *) 0))
    (void) CloneString(&clone_info->server_name, draw_info->server_name);

  if (draw_info->dash_pattern != ((double *) 0))
  {
    register ssize_t x;
    for (x = 0; draw_info->dash_pattern[x] != 0.0; x++)
      ;

    clone_info->dash_pattern = (double *) AcquireQuantumMemory(((size_t) x) + 1UL, sizeof(*clone_info->dash_pattern));
    if (clone_info->dash_pattern == ((double *) 0))
    {
      char *message;
      ExceptionInfo exception;
      GetExceptionInfo(&exception);
      message = GetExceptionMessage(errno);
      (void) ThrowMagickException(&exception, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 311, ResourceLimitFatalError, ("UnableToAllocateDashPattern" == ((const char *) 0)) ? ("unknown") : ("UnableToAllocateDashPattern"), "`%s'", message);
      message = DestroyString(message);
      CatchException(&exception);
      (void) DestroyExceptionInfo(&exception);
      _exit(1);
    }

    ;
    (void) CopyMagickMemory(clone_info->dash_pattern, draw_info->dash_pattern, ((size_t) (x + 1)) * (sizeof(*clone_info->dash_pattern)));
  }

  clone_info->gradient = draw_info->gradient;
  if (draw_info->gradient.stops != ((StopInfo *) 0))
  {
    size_t number_stops;
    number_stops = clone_info->gradient.number_stops;
    clone_info->gradient.stops = (StopInfo *) AcquireQuantumMemory((size_t) number_stops, sizeof(*clone_info->gradient.stops));
    if (clone_info->gradient.stops == ((StopInfo *) 0))
    {
      char *message;
      ExceptionInfo exception;
      GetExceptionInfo(&exception);
      message = GetExceptionMessage(errno);
      (void) ThrowMagickException(&exception, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 326, ResourceLimitFatalError, ("UnableToAllocateDashPattern" == ((const char *) 0)) ? ("unknown") : ("UnableToAllocateDashPattern"), "`%s'", message);
      message = DestroyString(message);
      CatchException(&exception);
      (void) DestroyExceptionInfo(&exception);
      _exit(1);
    }

    ;
    (void) CopyMagickMemory(clone_info->gradient.stops, draw_info->gradient.stops, ((size_t) number_stops) * (sizeof(*clone_info->gradient.stops)));
  }

  if (draw_info->clip_mask != ((char *) 0))
    (void) CloneString(&clone_info->clip_mask, draw_info->clip_mask);

  clone_info->bounds = draw_info->bounds;
  clone_info->clip_units = draw_info->clip_units;
  clone_info->render = draw_info->render;
  clone_info->opacity = draw_info->opacity;
  clone_info->element_reference = draw_info->element_reference;
  clone_info->debug = IsEventLogging();
  return clone_info;
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


inline static double DegreesToRadians(const double degrees)
{
  return (double) ((3.14159265358979323846264338327950288419716939937510L * degrees) / 180.0);
}


MagickBooleanType DrawPatternPath(Image *image, const DrawInfo *draw_info, const char *name, Image **pattern)
{
  char property[4096];
  const char *geometry;
  const char *path;
  DrawInfo *clone_info;
  ImageInfo *image_info;
  MagickBooleanType status;
  assert(image != ((Image *) 0));
  assert(image->signature == 0xabacadabUL);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(TraceEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 3517, "%s", image->filename);

  assert(draw_info != ((const DrawInfo *) 0));
  assert(name != ((const char *) 0));
  (void) FormatLocaleString(property, 4096, "%s", name);
  path = GetImageArtifact(image, property);
  if (path == ((const char *) 0))
    return MagickFalse;

  (void) FormatLocaleString(property, 4096, "%s-geometry", name);
  geometry = GetImageArtifact(image, property);
  if (geometry == ((const char *) 0))
    return MagickFalse;

  if ((*pattern) != ((Image *) 0))
    *pattern = DestroyImage(*pattern);

  image_info = AcquireImageInfo();
  image_info->size = AcquireString(geometry);
  *pattern = AcquireImage(image_info);
  image_info = DestroyImageInfo(image_info);
  (void) QueryColorDatabase("#00000000", &(*pattern)->background_color, &image->exception);
  (void) SetImageBackgroundColor(*pattern);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 3538, "begin pattern-path %s %s", name, geometry);

  clone_info = CloneDrawInfo((ImageInfo *) 0, draw_info);
  clone_info->fill_pattern = NewImageList();
  clone_info->stroke_pattern = NewImageList();
  (void) CloneString(&clone_info->primitive, path);
  status = DrawImage(*pattern, clone_info);
  clone_info = DestroyDrawInfo(clone_info);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 3547, "end pattern-path");

  return status;
}


inline static long StringToLong(const char *value)
{
  return strtol(value, (char **) 0, 10);
}


inline static MagickBooleanType IsPoint(const char *point)
{
  char *p;
  double value;
  value = InterpretLocaleValue(point, &p);
  return ((value == 0.0) && (p == point)) ? (MagickFalse) : (MagickTrue);
}


inline static MagickBooleanType IsPoint(const char *point)
{
  char *p;
  double value;
  value = InterpretLocaleValue(point, &p);
  return ((value == 0.0) && (p == point)) ? (MagickFalse) : (MagickTrue);
}


inline static unsigned long StringToUnsignedLong(const char *value)
{
  return strtoul(value, (char **) 0, 10);
}


inline static long StringToLong(const char *value)
{
  return strtol(value, (char **) 0, 10);
}


inline static MagickBooleanType IsPoint(const char *point)
{
  char *p;
  double value;
  value = InterpretLocaleValue(point, &p);
  return ((value == 0.0) && (p == point)) ? (MagickFalse) : (MagickTrue);
}


inline static void TracePoint(PrimitiveInfo *primitive_info, const PointInfo point)
{
  primitive_info->coordinates = 1;
  primitive_info->point = point;
}


static void TraceLine(PrimitiveInfo *primitive_info, const PointInfo start, const PointInfo end)
{
  TracePoint(primitive_info, start);
  if ((fabs(start.x - end.x) <= MagickEpsilon) && (fabs(start.y - end.y) <= MagickEpsilon))
  {
    primitive_info->primitive = PointPrimitive;
    primitive_info->coordinates = 1;
    return;
  }

  TracePoint(primitive_info + 1, end);
  (primitive_info + 1)->primitive = primitive_info->primitive;
  primitive_info->coordinates = 2;
}


static void TraceRectangle(PrimitiveInfo *primitive_info, const PointInfo start, const PointInfo end)
{
  PointInfo point;
  register PrimitiveInfo *p;
  register ssize_t i;
  p = primitive_info;
  TracePoint(p, start);
  p += p->coordinates;
  point.x = start.x;
  point.y = end.y;
  TracePoint(p, point);
  p += p->coordinates;
  TracePoint(p, end);
  p += p->coordinates;
  point.x = end.x;
  point.y = start.y;
  TracePoint(p, point);
  p += p->coordinates;
  TracePoint(p, start);
  p += p->coordinates;
  primitive_info->coordinates = (size_t) (p - primitive_info);
  for (i = 0; i < ((ssize_t) primitive_info->coordinates); i++)
  {
    p->primitive = primitive_info->primitive;
    p--;
  }

}


static void TraceRoundRectangle(PrimitiveInfo *primitive_info, const PointInfo start, const PointInfo end, PointInfo arc)
{
  PointInfo degrees;
  PointInfo offset;
  PointInfo point;
  register PrimitiveInfo *p;
  register ssize_t i;
  p = primitive_info;
  offset.x = fabs(end.x - start.x);
  offset.y = fabs(end.y - start.y);
  if (arc.x > (0.5 * offset.x))
    arc.x = 0.5 * offset.x;

  if (arc.y > (0.5 * offset.y))
    arc.y = 0.5 * offset.y;

  point.x = (start.x + offset.x) - arc.x;
  point.y = start.y + arc.y;
  degrees.x = 270.0;
  degrees.y = 360.0;
  TraceEllipse(p, point, arc, degrees);
  p += p->coordinates;
  point.x = (start.x + offset.x) - arc.x;
  point.y = (start.y + offset.y) - arc.y;
  degrees.x = 0.0;
  degrees.y = 90.0;
  TraceEllipse(p, point, arc, degrees);
  p += p->coordinates;
  point.x = start.x + arc.x;
  point.y = (start.y + offset.y) - arc.y;
  degrees.x = 90.0;
  degrees.y = 180.0;
  TraceEllipse(p, point, arc, degrees);
  p += p->coordinates;
  point.x = start.x + arc.x;
  point.y = start.y + arc.y;
  degrees.x = 180.0;
  degrees.y = 270.0;
  TraceEllipse(p, point, arc, degrees);
  p += p->coordinates;
  TracePoint(p, primitive_info->point);
  p += p->coordinates;
  primitive_info->coordinates = (size_t) (p - primitive_info);
  for (i = 0; i < ((ssize_t) primitive_info->coordinates); i++)
  {
    p->primitive = primitive_info->primitive;
    p--;
  }

}


static void TraceArc(PrimitiveInfo *primitive_info, const PointInfo start, const PointInfo end, const PointInfo degrees)
{
  PointInfo center;
  PointInfo radii;
  center.x = 0.5 * (end.x + start.x);
  center.y = 0.5 * (end.y + start.y);
  radii.x = fabs(center.x - start.x);
  radii.y = fabs(center.y - start.y);
  TraceEllipse(primitive_info, center, radii, degrees);
}


static void TraceEllipse(PrimitiveInfo *primitive_info, const PointInfo start, const PointInfo stop, const PointInfo degrees)
{
  MagickRealType delta;
  MagickRealType step;
  MagickRealType y;
  PointInfo angle;
  PointInfo point;
  register PrimitiveInfo *p;
  register ssize_t i;
  if ((stop.x == 0.0) && (stop.y == 0.0))
  {
    TracePoint(primitive_info, start);
    return;
  }

  delta = 2.0 / MagickMax(stop.x, stop.y);
  step = (MagickRealType) (3.14159265358979323846264338327950288419716939937510L / 8.0);
  if ((delta >= 0.0) && (delta < ((MagickRealType) (3.14159265358979323846264338327950288419716939937510L / 8.0))))
    step = (MagickRealType) (3.14159265358979323846264338327950288419716939937510L / (4 * (((3.14159265358979323846264338327950288419716939937510L / delta) / 2) + 0.5)));

  angle.x = DegreesToRadians(degrees.x);
  y = degrees.y;
  while (y < degrees.x)
    y += 360.0;

  angle.y = (double) (DegreesToRadians(y) - MagickEpsilon);
  for (p = primitive_info; angle.x < angle.y; angle.x += step)
  {
    point.x = (cos(fmod(angle.x, DegreesToRadians(360.0))) * stop.x) + start.x;
    point.y = (sin(fmod(angle.x, DegreesToRadians(360.0))) * stop.y) + start.y;
    TracePoint(p, point);
    p += p->coordinates;
  }

  point.x = (cos(fmod(angle.y, DegreesToRadians(360.0))) * stop.x) + start.x;
  point.y = (sin(fmod(angle.y, DegreesToRadians(360.0))) * stop.y) + start.y;
  TracePoint(p, point);
  p += p->coordinates;
  primitive_info->coordinates = (size_t) (p - primitive_info);
  for (i = 0; i < ((ssize_t) primitive_info->coordinates); i++)
  {
    p->primitive = primitive_info->primitive;
    p--;
  }

}


static void TraceCircle(PrimitiveInfo *primitive_info, const PointInfo start, const PointInfo end)
{
  MagickRealType alpha;
  MagickRealType beta;
  MagickRealType radius;
  PointInfo offset;
  PointInfo degrees;
  alpha = end.x - start.x;
  beta = end.y - start.y;
  radius = hypot((double) alpha, (double) beta);
  offset.x = (double) radius;
  offset.y = (double) radius;
  degrees.x = 0.0;
  degrees.y = 360.0;
  TraceEllipse(primitive_info, start, offset, degrees);
}


static void TraceBezier(PrimitiveInfo *primitive_info, const size_t number_coordinates)
{
  MagickRealType alpha;
  MagickRealType *coefficients;
  MagickRealType weight;
  PointInfo end;
  PointInfo point;
  PointInfo *points;
  register PrimitiveInfo *p;
  register ssize_t i;
  register ssize_t j;
  size_t control_points;
  size_t quantum;
  quantum = number_coordinates;
  for (i = 0; i < ((ssize_t) number_coordinates); i++)
  {
    for (j = i + 1; j < ((ssize_t) number_coordinates); j++)
    {
      alpha = fabs(primitive_info[j].point.x - primitive_info[i].point.x);
      if (alpha > ((MagickRealType) quantum))
        quantum = (size_t) alpha;

      alpha = fabs(primitive_info[j].point.y - primitive_info[i].point.y);
      if (alpha > ((MagickRealType) quantum))
        quantum = (size_t) alpha;

    }

  }

  quantum = (size_t) MagickMin(((double) quantum) / number_coordinates, (double) 200);
  control_points = quantum * number_coordinates;
  coefficients = (MagickRealType *) AcquireQuantumMemory((size_t) number_coordinates, sizeof(*coefficients));
  points = (PointInfo *) AcquireQuantumMemory((size_t) control_points, sizeof(*points));
  if ((coefficients == ((MagickRealType *) 0)) || (points == ((PointInfo *) 0)))
  {
    char *message;
    ExceptionInfo exception;
    GetExceptionInfo(&exception);
    message = GetExceptionMessage(errno);
    (void) ThrowMagickException(&exception, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 5060, ResourceLimitFatalError, ("MemoryAllocationFailed" == ((const char *) 0)) ? ("unknown") : ("MemoryAllocationFailed"), "`%s'", message);
    message = DestroyString(message);
    CatchException(&exception);
    (void) DestroyExceptionInfo(&exception);
    _exit(1);
  }

  ;
  end = primitive_info[number_coordinates - 1].point;
  for (i = 0; i < ((ssize_t) number_coordinates); i++)
    coefficients[i] = Permutate(((ssize_t) number_coordinates) - 1, i);

  weight = 0.0;
  for (i = 0; i < ((ssize_t) control_points); i++)
  {
    p = primitive_info;
    point.x = 0.0;
    point.y = 0.0;
    alpha = pow((double) (1.0 - weight), ((double) number_coordinates) - 1.0);
    for (j = 0; j < ((ssize_t) number_coordinates); j++)
    {
      point.x += (alpha * coefficients[j]) * p->point.x;
      point.y += (alpha * coefficients[j]) * p->point.y;
      alpha *= weight / (1.0 - weight);
      p++;
    }

    points[i] = point;
    weight += 1.0 / control_points;
  }

  p = primitive_info;
  for (i = 0; i < ((ssize_t) control_points); i++)
  {
    TracePoint(p, points[i]);
    p += p->coordinates;
  }

  TracePoint(p, end);
  p += p->coordinates;
  primitive_info->coordinates = (size_t) (p - primitive_info);
  for (i = 0; i < ((ssize_t) primitive_info->coordinates); i++)
  {
    p->primitive = primitive_info->primitive;
    p--;
  }

  points = (PointInfo *) RelinquishMagickMemory(points);
  coefficients = (MagickRealType *) RelinquishMagickMemory(coefficients);
}


static size_t TracePath(PrimitiveInfo *primitive_info, const char *path)
{
  char token[4096];
  const char *p;
  int attribute;
  int last_attribute;
  MagickRealType x;
  MagickRealType y;
  PointInfo end;
  PointInfo points[4];
  PointInfo point;
  PointInfo start;
  PrimitiveType primitive_type;
  register PrimitiveInfo *q;
  register ssize_t i;
  size_t number_coordinates;
  size_t z_count;
  attribute = 0;
  point.x = 0.0;
  point.y = 0.0;
  start.x = 0.0;
  start.y = 0.0;
  number_coordinates = 0;
  z_count = 0;
  primitive_type = primitive_info->primitive;
  q = primitive_info;
  for (p = path; (*p) != '\0';)
  {
    while (isspace((int) ((unsigned char) (*p))) != 0)
      p++;

    if ((*p) == '\0')
      break;

    last_attribute = attribute;
    attribute = (int) (*(p++));
    switch (attribute)
    {
      case 'a':

      case 'A':
      {
        MagickBooleanType large_arc;
        MagickBooleanType sweep;
        MagickRealType angle;
        PointInfo arc;
        do
        {
          GetMagickToken(p, &p, token);
          if ((*token) == ',')
            GetMagickToken(p, &p, token);

          arc.x = InterpretLocaleValue(token, (char **) 0);
          GetMagickToken(p, &p, token);
          if ((*token) == ',')
            GetMagickToken(p, &p, token);

          arc.y = InterpretLocaleValue(token, (char **) 0);
          GetMagickToken(p, &p, token);
          if ((*token) == ',')
            GetMagickToken(p, &p, token);

          angle = InterpretLocaleValue(token, (char **) 0);
          GetMagickToken(p, &p, token);
          if ((*token) == ',')
            GetMagickToken(p, &p, token);

          large_arc = (StringToLong(token) != 0) ? (MagickTrue) : (MagickFalse);
          GetMagickToken(p, &p, token);
          if ((*token) == ',')
            GetMagickToken(p, &p, token);

          sweep = (StringToLong(token) != 0) ? (MagickTrue) : (MagickFalse);
          GetMagickToken(p, &p, token);
          if ((*token) == ',')
            GetMagickToken(p, &p, token);

          x = InterpretLocaleValue(token, (char **) 0);
          GetMagickToken(p, &p, token);
          if ((*token) == ',')
            GetMagickToken(p, &p, token);

          y = InterpretLocaleValue(token, (char **) 0);
          end.x = (double) ((attribute == ((int) 'A')) ? (x) : (point.x + x));
          end.y = (double) ((attribute == ((int) 'A')) ? (y) : (point.y + y));
          TraceArcPath(q, point, end, arc, angle, large_arc, sweep);
          q += q->coordinates;
          point = end;
        }
        while (IsPoint(p) != MagickFalse);
        break;
      }

      case 'c':

      case 'C':
      {
        do
        {
          points[0] = point;
          for (i = 1; i < 4; i++)
          {
            GetMagickToken(p, &p, token);
            if ((*token) == ',')
              GetMagickToken(p, &p, token);

            x = InterpretLocaleValue(token, (char **) 0);
            GetMagickToken(p, &p, token);
            if ((*token) == ',')
              GetMagickToken(p, &p, token);

            y = InterpretLocaleValue(token, (char **) 0);
            end.x = (double) ((attribute == ((int) 'C')) ? (x) : (point.x + x));
            end.y = (double) ((attribute == ((int) 'C')) ? (y) : (point.y + y));
            points[i] = end;
          }

          for (i = 0; i < 4; i++)
            (q + i)->point = points[i];

          TraceBezier(q, 4);
          q += q->coordinates;
          point = end;
        }
        while (IsPoint(p) != MagickFalse);
        break;
      }

      case 'H':

      case 'h':
      {
        do
        {
          GetMagickToken(p, &p, token);
          if ((*token) == ',')
            GetMagickToken(p, &p, token);

          x = InterpretLocaleValue(token, (char **) 0);
          point.x = (double) ((attribute == ((int) 'H')) ? (x) : (point.x + x));
          TracePoint(q, point);
          q += q->coordinates;
        }
        while (IsPoint(p) != MagickFalse);
        break;
      }

      case 'l':

      case 'L':
      {
        do
        {
          GetMagickToken(p, &p, token);
          if ((*token) == ',')
            GetMagickToken(p, &p, token);

          x = InterpretLocaleValue(token, (char **) 0);
          GetMagickToken(p, &p, token);
          if ((*token) == ',')
            GetMagickToken(p, &p, token);

          y = InterpretLocaleValue(token, (char **) 0);
          point.x = (double) ((attribute == ((int) 'L')) ? (x) : (point.x + x));
          point.y = (double) ((attribute == ((int) 'L')) ? (y) : (point.y + y));
          TracePoint(q, point);
          q += q->coordinates;
        }
        while (IsPoint(p) != MagickFalse);
        break;
      }

      case 'M':

      case 'm':
      {
        if (q != primitive_info)
        {
          primitive_info->coordinates = (size_t) (q - primitive_info);
          number_coordinates += primitive_info->coordinates;
          primitive_info = q;
        }

        i = 0;
        do
        {
          GetMagickToken(p, &p, token);
          if ((*token) == ',')
            GetMagickToken(p, &p, token);

          x = InterpretLocaleValue(token, (char **) 0);
          GetMagickToken(p, &p, token);
          if ((*token) == ',')
            GetMagickToken(p, &p, token);

          y = InterpretLocaleValue(token, (char **) 0);
          point.x = (double) ((attribute == ((int) 'M')) ? (x) : (point.x + x));
          point.y = (double) ((attribute == ((int) 'M')) ? (y) : (point.y + y));
          if (i == 0)
            start = point;

          i++;
          TracePoint(q, point);
          q += q->coordinates;
          if ((i != 0) && (attribute == ((int) 'M')))
          {
            TracePoint(q, point);
            q += q->coordinates;
          }

        }
        while (IsPoint(p) != MagickFalse);
        break;
      }

      case 'q':

      case 'Q':
      {
        do
        {
          points[0] = point;
          for (i = 1; i < 3; i++)
          {
            GetMagickToken(p, &p, token);
            if ((*token) == ',')
              GetMagickToken(p, &p, token);

            x = InterpretLocaleValue(token, (char **) 0);
            GetMagickToken(p, &p, token);
            if ((*token) == ',')
              GetMagickToken(p, &p, token);

            y = InterpretLocaleValue(token, (char **) 0);
            if ((*p) == ',')
              p++;

            end.x = (double) ((attribute == ((int) 'Q')) ? (x) : (point.x + x));
            end.y = (double) ((attribute == ((int) 'Q')) ? (y) : (point.y + y));
            points[i] = end;
          }

          for (i = 0; i < 3; i++)
            (q + i)->point = points[i];

          TraceBezier(q, 3);
          q += q->coordinates;
          point = end;
        }
        while (IsPoint(p) != MagickFalse);
        break;
      }

      case 's':

      case 'S':
      {
        do
        {
          points[0] = points[3];
          points[1].x = (2.0 * points[3].x) - points[2].x;
          points[1].y = (2.0 * points[3].y) - points[2].y;
          for (i = 2; i < 4; i++)
          {
            GetMagickToken(p, &p, token);
            if ((*token) == ',')
              GetMagickToken(p, &p, token);

            x = InterpretLocaleValue(token, (char **) 0);
            GetMagickToken(p, &p, token);
            if ((*token) == ',')
              GetMagickToken(p, &p, token);

            y = InterpretLocaleValue(token, (char **) 0);
            if ((*p) == ',')
              p++;

            end.x = (double) ((attribute == ((int) 'S')) ? (x) : (point.x + x));
            end.y = (double) ((attribute == ((int) 'S')) ? (y) : (point.y + y));
            points[i] = end;
          }

          if (strchr("CcSs", last_attribute) == ((char *) 0))
          {
            points[0] = points[2];
            points[1] = points[3];
          }

          for (i = 0; i < 4; i++)
            (q + i)->point = points[i];

          TraceBezier(q, 4);
          q += q->coordinates;
          point = end;
        }
        while (IsPoint(p) != MagickFalse);
        break;
      }

      case 't':

      case 'T':
      {
        do
        {
          points[0] = points[2];
          points[1].x = (2.0 * points[2].x) - points[1].x;
          points[1].y = (2.0 * points[2].y) - points[1].y;
          for (i = 2; i < 3; i++)
          {
            GetMagickToken(p, &p, token);
            if ((*token) == ',')
              GetMagickToken(p, &p, token);

            x = InterpretLocaleValue(token, (char **) 0);
            GetMagickToken(p, &p, token);
            if ((*token) == ',')
              GetMagickToken(p, &p, token);

            y = InterpretLocaleValue(token, (char **) 0);
            end.x = (double) ((attribute == ((int) 'T')) ? (x) : (point.x + x));
            end.y = (double) ((attribute == ((int) 'T')) ? (y) : (point.y + y));
            points[i] = end;
          }

          if (strchr("QqTt", last_attribute) == ((char *) 0))
          {
            points[0] = points[2];
            points[1] = points[3];
          }

          for (i = 0; i < 3; i++)
            (q + i)->point = points[i];

          TraceBezier(q, 3);
          q += q->coordinates;
          point = end;
        }
        while (IsPoint(p) != MagickFalse);
        break;
      }

      case 'v':

      case 'V':
      {
        do
        {
          GetMagickToken(p, &p, token);
          if ((*token) == ',')
            GetMagickToken(p, &p, token);

          y = InterpretLocaleValue(token, (char **) 0);
          point.y = (double) ((attribute == ((int) 'V')) ? (y) : (point.y + y));
          TracePoint(q, point);
          q += q->coordinates;
        }
        while (IsPoint(p) != MagickFalse);
        break;
      }

      case 'z':

      case 'Z':
      {
        point = start;
        TracePoint(q, point);
        q += q->coordinates;
        primitive_info->coordinates = (size_t) (q - primitive_info);
        number_coordinates += primitive_info->coordinates;
        primitive_info = q;
        z_count++;
        break;
      }

      default:
      {
        if (isalpha((int) ((unsigned char) attribute)) != 0)
          (void) FormatLocaleFile(stderr, "attribute not recognized: %c\n", attribute);

        break;
      }

    }

  }

  primitive_info->coordinates = (size_t) (q - primitive_info);
  number_coordinates += primitive_info->coordinates;
  for (i = 0; i < ((ssize_t) number_coordinates); i++)
  {
    q--;
    q->primitive = primitive_type;
    if (z_count > 1)
      q->method = FillToBorderMethod;

  }

  q = primitive_info;
  return number_coordinates;
}


MagickBooleanType DrawClipPath(Image *image, const DrawInfo *draw_info, const char *name)
{
  char clip_mask[4096];
  const char *value;
  DrawInfo *clone_info;
  MagickStatusType status;
  assert(image != ((Image *) 0));
  assert(image->signature == 0xabacadabUL);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(TraceEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 1415, "%s", image->filename);

  assert(draw_info != ((const DrawInfo *) 0));
  (void) FormatLocaleString(clip_mask, 4096, "%s", name);
  value = GetImageArtifact(image, clip_mask);
  if (value == ((const char *) 0))
    return MagickFalse;

  if (image->clip_mask == ((Image *) 0))
  {
    Image *clip_mask;
    clip_mask = CloneImage(image, image->columns, image->rows, MagickTrue, &image->exception);
    if (clip_mask == ((Image *) 0))
      return MagickFalse;

    (void) SetImageClipMask(image, clip_mask);
    clip_mask = DestroyImage(clip_mask);
  }

  (void) QueryColorDatabase("#00000000", &image->clip_mask->background_color, &image->exception);
  image->clip_mask->background_color.opacity = (Quantum) TransparentOpacity;
  (void) SetImageBackgroundColor(image->clip_mask);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 1438, "\nbegin clip-path %s", draw_info->clip_mask);

  clone_info = CloneDrawInfo((ImageInfo *) 0, draw_info);
  (void) CloneString(&clone_info->primitive, value);
  (void) QueryColorDatabase("#ffffff", &clone_info->fill, &image->exception);
  clone_info->clip_mask = (char *) 0;
  status = DrawImage(image->clip_mask, clone_info);
  status |= NegateImage(image->clip_mask, MagickFalse);
  clone_info = DestroyDrawInfo(clone_info);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 1448, "end clip-path");

  return (status != 0) ? (MagickTrue) : (MagickFalse);
}


MagickBooleanType DrawPrimitive(Image *image, const DrawInfo *draw_info, const PrimitiveInfo *primitive_info)
{
  CacheView *image_view;
  ExceptionInfo *exception;
  MagickStatusType status;
  register ssize_t i;
  register ssize_t x;
  ssize_t y;
  if (image->debug != MagickFalse)
  {
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 4151, "  begin draw-primitive");
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 4153, "    affine: %g %g %g %g %g %g", draw_info->affine.sx, draw_info->affine.rx, draw_info->affine.ry, draw_info->affine.sy, draw_info->affine.tx, draw_info->affine.ty);
  }

  status = MagickTrue;
  exception = &image->exception;
  x = (ssize_t) ceil(primitive_info->point.x - 0.5);
  y = (ssize_t) ceil(primitive_info->point.y - 0.5);
  image_view = AcquireCacheView(image);
  switch (primitive_info->primitive)
  {
    case PointPrimitive:
    {
      PixelPacket fill_color;
      PixelPacket *q;
      if ((y < 0) || (y >= ((ssize_t) image->rows)))
        break;

      if ((x < 0) || (x >= ((ssize_t) image->columns)))
        break;

      q = GetCacheViewAuthenticPixels(image_view, x, y, 1, 1, exception);
      if (q == ((PixelPacket *) 0))
        break;

      (void) GetFillColor(draw_info, x, y, &fill_color);
      MagickCompositeOver(&fill_color, (MagickRealType) fill_color.opacity, q, (MagickRealType) q->opacity, q);
      (void) SyncCacheViewAuthenticPixels(image_view, exception);
      break;
    }

    case ColorPrimitive:
    {
      switch (primitive_info->method)
      {
        case PointMethod:

        default:
        {
          PixelPacket *q;
          q = GetCacheViewAuthenticPixels(image_view, x, y, 1, 1, exception);
          if (q == ((PixelPacket *) 0))
            break;

          (void) GetFillColor(draw_info, x, y, q);
          (void) SyncCacheViewAuthenticPixels(image_view, exception);
          break;
        }

        case ReplaceMethod:
        {
          MagickBooleanType sync;
          PixelPacket target;
          (void) GetOneCacheViewVirtualPixel(image_view, x, y, &target, exception);
          for (y = 0; y < ((ssize_t) image->rows); y++)
          {
            register PixelPacket * restrict q;
            q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
            if (q == ((PixelPacket *) 0))
              break;

            for (x = 0; x < ((ssize_t) image->columns); x++)
            {
              if (IsColorSimilar(image, q, &target) == MagickFalse)
              {
                q++;
                continue;
              }

              (void) GetFillColor(draw_info, x, y, q);
              q++;
            }

            sync = SyncCacheViewAuthenticPixels(image_view, exception);
            if (sync == MagickFalse)
              break;

          }

          break;
        }

        case FloodfillMethod:

        case FillToBorderMethod:
        {
          MagickPixelPacket target;
          (void) GetOneVirtualMagickPixel(image, x, y, &target, exception);
          if (primitive_info->method == FillToBorderMethod)
          {
            target.red = (MagickRealType) draw_info->border_color.red;
            target.green = (MagickRealType) draw_info->border_color.green;
            target.blue = (MagickRealType) draw_info->border_color.blue;
          }

          (void) FloodfillPaintImage(image, DefaultChannels, draw_info, &target, x, y, (primitive_info->method == FloodfillMethod) ? (MagickFalse) : (MagickTrue));
          break;
        }

        case ResetMethod:
        {
          MagickBooleanType sync;
          for (y = 0; y < ((ssize_t) image->rows); y++)
          {
            register PixelPacket * restrict q;
            register ssize_t x;
            q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
            if (q == ((PixelPacket *) 0))
              break;

            for (x = 0; x < ((ssize_t) image->columns); x++)
            {
              (void) GetFillColor(draw_info, x, y, q);
              q++;
            }

            sync = SyncCacheViewAuthenticPixels(image_view, exception);
            if (sync == MagickFalse)
              break;

          }

          break;
        }

      }

      break;
    }

    case MattePrimitive:
    {
      if (image->matte == MagickFalse)
        (void) SetImageAlphaChannel(image, OpaqueAlphaChannel);

      switch (primitive_info->method)
      {
        case PointMethod:

        default:
        {
          PixelPacket pixel;
          PixelPacket *q;
          q = GetCacheViewAuthenticPixels(image_view, x, y, 1, 1, exception);
          if (q == ((PixelPacket *) 0))
            break;

          (void) GetFillColor(draw_info, x, y, &pixel);
          SetPixelOpacity(q, pixel.opacity);
          (void) SyncCacheViewAuthenticPixels(image_view, exception);
          break;
        }

        case ReplaceMethod:
        {
          MagickBooleanType sync;
          PixelPacket pixel;
          PixelPacket target;
          (void) GetOneCacheViewVirtualPixel(image_view, x, y, &target, exception);
          for (y = 0; y < ((ssize_t) image->rows); y++)
          {
            register PixelPacket * restrict q;
            register ssize_t x;
            q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
            if (q == ((PixelPacket *) 0))
              break;

            for (x = 0; x < ((ssize_t) image->columns); x++)
            {
              if (IsColorSimilar(image, q, &target) == MagickFalse)
              {
                q++;
                continue;
              }

              (void) GetFillColor(draw_info, x, y, &pixel);
              SetPixelOpacity(q, pixel.opacity);
              q++;
            }

            sync = SyncCacheViewAuthenticPixels(image_view, exception);
            if (sync == MagickFalse)
              break;

          }

          break;
        }

        case FloodfillMethod:

        case FillToBorderMethod:
        {
          MagickPixelPacket target;
          (void) GetOneVirtualMagickPixel(image, x, y, &target, exception);
          if (primitive_info->method == FillToBorderMethod)
          {
            target.red = (MagickRealType) draw_info->border_color.red;
            target.green = (MagickRealType) draw_info->border_color.green;
            target.blue = (MagickRealType) draw_info->border_color.blue;
          }

          (void) FloodfillPaintImage(image, OpacityChannel, draw_info, &target, x, y, (primitive_info->method == FloodfillMethod) ? (MagickFalse) : (MagickTrue));
          break;
        }

        case ResetMethod:
        {
          MagickBooleanType sync;
          PixelPacket pixel;
          for (y = 0; y < ((ssize_t) image->rows); y++)
          {
            register PixelPacket * restrict q;
            register ssize_t x;
            q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
            if (q == ((PixelPacket *) 0))
              break;

            for (x = 0; x < ((ssize_t) image->columns); x++)
            {
              (void) GetFillColor(draw_info, x, y, &pixel);
              SetPixelOpacity(q, pixel.opacity);
              q++;
            }

            sync = SyncCacheViewAuthenticPixels(image_view, exception);
            if (sync == MagickFalse)
              break;

          }

          break;
        }

      }

      break;
    }

    case TextPrimitive:
    {
      char geometry[4096];
      DrawInfo *clone_info;
      if (primitive_info->text == ((char *) 0))
        break;

      clone_info = CloneDrawInfo((ImageInfo *) 0, draw_info);
      (void) CloneString(&clone_info->text, primitive_info->text);
      (void) FormatLocaleString(geometry, 4096, "%+f%+f", primitive_info->point.x, primitive_info->point.y);
      (void) CloneString(&clone_info->geometry, geometry);
      status = AnnotateImage(image, clone_info);
      clone_info = DestroyDrawInfo(clone_info);
      break;
    }

    case ImagePrimitive:
    {
      AffineMatrix affine;
      char composite_geometry[4096];
      Image *composite_image;
      ImageInfo *clone_info;
      RectangleInfo geometry;
      ssize_t x1;
      ssize_t y1;
      if (primitive_info->text == ((char *) 0))
        break;

      clone_info = AcquireImageInfo();
      if (LocaleNCompare(primitive_info->text, "data:", 5) == 0)
        composite_image = ReadInlineImage(clone_info, primitive_info->text, &image->exception);
      else
      {
        (void) CopyMagickString(clone_info->filename, primitive_info->text, 4096);
        composite_image = ReadImage(clone_info, &image->exception);
      }

      clone_info = DestroyImageInfo(clone_info);
      if (composite_image == ((Image *) 0))
        break;

      (void) SetImageProgressMonitor(composite_image, (MagickProgressMonitor) 0, (void *) 0);
      x1 = (ssize_t) ceil(primitive_info[1].point.x - 0.5);
      y1 = (ssize_t) ceil(primitive_info[1].point.y - 0.5);
      if (((x1 != 0L) && (x1 != ((ssize_t) composite_image->columns))) || ((y1 != 0L) && (y1 != ((ssize_t) composite_image->rows))))
      {
        char geometry[4096];
        (void) FormatLocaleString(geometry, 4096, "%gx%g!", primitive_info[1].point.x, primitive_info[1].point.y);
        composite_image->filter = image->filter;
        (void) TransformImage(&composite_image, (char *) 0, geometry);
      }

      if (composite_image->matte == MagickFalse)
        (void) SetImageAlphaChannel(composite_image, OpaqueAlphaChannel);

      if (draw_info->opacity != OpaqueOpacity)
        (void) SetImageOpacity(composite_image, draw_info->opacity);

      SetGeometry(image, &geometry);
      image->gravity = draw_info->gravity;
      geometry.x = x;
      geometry.y = y;
      (void) FormatLocaleString(composite_geometry, 4096, "%.20gx%.20g%+.20g%+.20g", (double) composite_image->columns, (double) composite_image->rows, (double) geometry.x, (double) geometry.y);
      (void) ParseGravityGeometry(image, composite_geometry, &geometry, &image->exception);
      affine = draw_info->affine;
      affine.tx = (double) geometry.x;
      affine.ty = (double) geometry.y;
      composite_image->interpolate = image->interpolate;
      if (draw_info->compose == OverCompositeOp)
        (void) DrawAffineImage(image, composite_image, &affine);
      else
        (void) CompositeImage(image, draw_info->compose, composite_image, geometry.x, geometry.y);

      composite_image = DestroyImage(composite_image);
      break;
    }

    default:
    {
      MagickRealType mid;
      MagickRealType scale;
      DrawInfo *clone_info;
      if (IsEventLogging() != MagickFalse)
        LogPrimitiveInfo(primitive_info);

      scale = ExpandAffine(&draw_info->affine);
      if ((((draw_info->dash_pattern != ((double *) 0)) && (draw_info->dash_pattern[0] != 0.0)) && ((scale * draw_info->stroke_width) > MagickEpsilon)) && (draw_info->stroke.opacity != ((Quantum) TransparentOpacity)))
      {
        clone_info = CloneDrawInfo((ImageInfo *) 0, draw_info);
        clone_info->stroke_width = 0.0;
        clone_info->stroke.opacity = (Quantum) TransparentOpacity;
        status = DrawPolygonPrimitive(image, clone_info, primitive_info);
        clone_info = DestroyDrawInfo(clone_info);
        (void) DrawDashPolygon(draw_info, primitive_info, image);
        break;
      }

      mid = (ExpandAffine(&draw_info->affine) * draw_info->stroke_width) / 2.0;
      if ((mid > 1.0) && (draw_info->stroke.opacity != ((Quantum) TransparentOpacity)))
      {
        MagickBooleanType closed_path;
        for (i = 0; primitive_info[i].primitive != UndefinedPrimitive; i++)
          ;

        closed_path = ((primitive_info[i - 1].point.x == primitive_info[0].point.x) && (primitive_info[i - 1].point.y == primitive_info[0].point.y)) ? (MagickTrue) : (MagickFalse);
        i = (ssize_t) primitive_info[0].coordinates;
        if ((((draw_info->linecap == RoundCap) || (closed_path != MagickFalse)) && (draw_info->linejoin == RoundJoin)) || (primitive_info[i].primitive != UndefinedPrimitive))
        {
          (void) DrawPolygonPrimitive(image, draw_info, primitive_info);
          break;
        }

        clone_info = CloneDrawInfo((ImageInfo *) 0, draw_info);
        clone_info->stroke_width = 0.0;
        clone_info->stroke.opacity = (Quantum) TransparentOpacity;
        status = DrawPolygonPrimitive(image, clone_info, primitive_info);
        clone_info = DestroyDrawInfo(clone_info);
        status |= DrawStrokePolygon(image, draw_info, primitive_info);
        break;
      }

      status = DrawPolygonPrimitive(image, draw_info, primitive_info);
      break;
    }

  }

  image_view = DestroyCacheView(image_view);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 4565, "  end draw-primitive");

  return (status != 0) ? (MagickTrue) : (MagickFalse);
}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

