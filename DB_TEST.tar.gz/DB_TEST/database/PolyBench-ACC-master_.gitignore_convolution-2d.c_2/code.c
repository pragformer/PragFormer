for (i = 0; i < ni; i++)
  for (j = 0; j < nj; j++)
{
  fprintf(stderr, "%0.2lf ", B[i][j]);
  if ((((i * 4096) + j) % 20) == 0)
    fprintf(stderr, "\n");

}

