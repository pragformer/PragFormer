for (i = 0; i < ((ssize_t) number_children); i++)
  if (node_info->child[i] != ((NodeInfo *) 0))
  ClosestColor(image, cube_info, node_info->child[i]);


static void ClosestColor(const Image *image, CubeInfo *cube_info, const NodeInfo *node_info)
{
  register ssize_t i;
  size_t number_children;
  number_children = (cube_info->associate_alpha == MagickFalse) ? (8UL) : (16UL);
  for (i = 0; i < ((ssize_t) number_children); i++)
    if (node_info->child[i] != ((NodeInfo *) 0))
    ClosestColor(image, cube_info, node_info->child[i]);


  if (node_info->number_unique != 0)
  {
    MagickRealType pixel;
    register MagickRealType alpha;
    register MagickRealType beta;
    register MagickRealType distance;
    register PixelPacket * restrict p;
    register RealPixelPacket * restrict q;
    p = image->colormap + node_info->color_number;
    q = &cube_info->target;
    alpha = 1.0;
    beta = 1.0;
    if (cube_info->associate_alpha != MagickFalse)
    {
      alpha = (MagickRealType) ((((double) 1.0) / ((double) QuantumRange)) * GetPixelAlpha(p));
      beta = (MagickRealType) ((((double) 1.0) / ((double) QuantumRange)) * GetPixelAlpha(q));
    }

    pixel = (alpha * GetPixelRed(p)) - (beta * GetPixelRed(q));
    distance = pixel * pixel;
    if (distance <= cube_info->distance)
    {
      pixel = (alpha * GetPixelGreen(p)) - (beta * GetPixelGreen(q));
      distance += pixel * pixel;
      if (distance <= cube_info->distance)
      {
        pixel = (alpha * GetPixelBlue(p)) - (beta * GetPixelBlue(q));
        distance += pixel * pixel;
        if (distance <= cube_info->distance)
        {
          pixel = alpha - beta;
          distance += pixel * pixel;
          if (distance <= cube_info->distance)
          {
            cube_info->distance = distance;
            cube_info->color_number = node_info->color_number;
          }

        }

      }

    }

  }

}

