for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  if (sharpen != MagickFalse)
  {
    sigmoidal_map[i] = (MagickRealType) ScaleMapToQuantum((MagickRealType) (((MaxMap * ((1.0 / (1.0 + exp(contrast * ((midpoint / ((double) QuantumRange)) - (((double) i) / MaxMap))))) - (1.0 / (1.0 + exp(contrast * (midpoint / ((double) QuantumRange))))))) / ((1.0 / (1.0 + exp(contrast * ((midpoint / ((double) QuantumRange)) - 1.0)))) - (1.0 / (1.0 + exp(contrast * (midpoint / ((double) QuantumRange))))))) + 0.5));
    continue;
  }

  sigmoidal_map[i] = (MagickRealType) ScaleMapToQuantum((MagickRealType) (MaxMap * (((((double) 1.0) / ((double) QuantumRange)) * midpoint) - (log((1.0 - ((1.0 / (1.0 + exp((midpoint / ((double) QuantumRange)) * contrast))) + ((((double) i) / MaxMap) * ((1.0 / (1.0 + exp(contrast * ((midpoint / ((double) QuantumRange)) - 1.0)))) - (1.0 / (1.0 + exp((midpoint / ((double) QuantumRange)) * contrast))))))) / ((1.0 / (1.0 + exp((midpoint / ((double) QuantumRange)) * contrast))) + ((((double) i) / MaxMap) * ((1.0 / (1.0 + exp(contrast * ((midpoint / ((double) QuantumRange)) - 1.0)))) - (1.0 / (1.0 + exp((midpoint / ((double) QuantumRange)) * contrast))))))) / contrast))));
}
