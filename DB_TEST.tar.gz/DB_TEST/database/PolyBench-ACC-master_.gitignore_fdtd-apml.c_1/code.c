for (i = 0; i <= cz; i++)
{
  czm[i] = (((double) i) + 1) / cxm;
  czp[i] = (((double) i) + 2) / cxm;
}
