for (i = 0; i < ((ssize_t) number_coordinates); i++)
{
  for (j = i + 1; j < ((ssize_t) number_coordinates); j++)
  {
    alpha = fabs(primitive_info[j].point.x - primitive_info[i].point.x);
    if (alpha > ((MagickRealType) quantum))
      quantum = (size_t) alpha;

    alpha = fabs(primitive_info[j].point.y - primitive_info[i].point.y);
    if (alpha > ((MagickRealType) quantum))
      quantum = (size_t) alpha;

  }

}
