for (depth = 1; colors != 0; depth++)
  colors >>= 2;
