for (i = 0; i < ((ssize_t) control_points); i++)
{
  TracePoint(p, points[i]);
  p += p->coordinates;
}

inline static void TracePoint(PrimitiveInfo *primitive_info, const PointInfo point)
{
  primitive_info->coordinates = 1;
  primitive_info->point = point;
}

