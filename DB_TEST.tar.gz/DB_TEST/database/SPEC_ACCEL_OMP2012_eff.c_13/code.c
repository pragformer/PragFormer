for (i = 0; i < (dim * prm->Natom); i++)
{
  grad[i] = 0.0;
}
