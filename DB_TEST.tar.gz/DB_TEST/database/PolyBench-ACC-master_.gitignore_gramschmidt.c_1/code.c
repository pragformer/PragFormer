for (i = 0; i < ni; i++)
  for (j = 0; j < nj; j++)
{
  A[i][j] = (((double) i) * j) / ni;
  Q[i][j] = (((double) i) * (j + 1)) / nj;
}

