for (y = 0; y < ((ssize_t) image->rows); y++)
{
  MagickBooleanType sync;
  register const PixelPacket * restrict p;
  register IndexPacket * restrict transverse_indexes;
  register IndexPacket * restrict indexes;
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  q = QueueCacheViewAuthenticPixels(transverse_view, (ssize_t) ((image->rows - y) - 1), 0, 1, transverse_image->rows, exception);
  if ((p == ((const PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
  {
    status = MagickFalse;
    continue;
  }

  q += image->columns;
  for (x = 0; x < ((ssize_t) image->columns); x++)
    *(--q) = *(p++);

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  if (indexes != ((IndexPacket *) 0))
  {
    transverse_indexes = GetCacheViewAuthenticIndexQueue(transverse_view);
    if (transverse_indexes != ((IndexPacket *) 0))
      for (x = 0; x < ((ssize_t) image->columns); x++)
      SetPixelIndex(((transverse_indexes + image->columns) - x) - 1, GetPixelIndex(indexes + x));


  }

  sync = SyncCacheViewAuthenticPixels(transverse_view, exception);
  if (sync == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_TransverseImage)
    proceed = SetImageProgress(image, "Transverse/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

