for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  for (x = (ssize_t) image->columns; x != 0; x--)
  {
    SetPixelRed(q, logmap[ScaleQuantumToMap(GetPixelRed(q))]);
    SetPixelGreen(q, logmap[ScaleQuantumToMap(GetPixelGreen(q))]);
    SetPixelBlue(q, logmap[ScaleQuantumToMap(GetPixelBlue(q))]);
    q++;
  }

  sync = SyncCacheViewAuthenticPixels(image_view, exception);
  if (sync == MagickFalse)
    status = MagickFalse;

}
