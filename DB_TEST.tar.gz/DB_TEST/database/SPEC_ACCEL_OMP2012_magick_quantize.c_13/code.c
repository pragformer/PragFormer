for (depth = 1; i != 0; depth++)
  i >>= 1;
