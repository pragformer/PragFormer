for (i = 0; i < ((ssize_t) control_points); i++)
{
  p = primitive_info;
  point.x = 0.0;
  point.y = 0.0;
  alpha = pow((double) (1.0 - weight), ((double) number_coordinates) - 1.0);
  for (j = 0; j < ((ssize_t) number_coordinates); j++)
  {
    point.x += (alpha * coefficients[j]) * p->point.x;
    point.y += (alpha * coefficients[j]) * p->point.y;
    alpha *= weight / (1.0 - weight);
    p++;
  }

  points[i] = point;
  weight += 1.0 / control_points;
}
