for (i = 0; i < nr; i++)
  for (j = 0; j < nq; j++)
  for (k = 0; k < np; k++)
  A[i][j][k] = ((((double) i) * j) + k) / np;


