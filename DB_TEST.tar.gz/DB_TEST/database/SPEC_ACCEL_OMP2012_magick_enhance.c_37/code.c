for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register const PixelPacket * restrict p;
  register PixelPacket * restrict q;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, -2, y - 2, image->columns + 4, 5, exception);
  q = QueueCacheViewAuthenticPixels(enhance_view, 0, y, enhance_image->columns, 1, exception);
  if ((p == ((const PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
  {
    status = MagickFalse;
    continue;
  }

  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    MagickPixelPacket aggregate;
    MagickRealType distance;
    MagickRealType distance_squared;
    MagickRealType mean;
    MagickRealType total_weight;
    PixelPacket pixel;
    register const PixelPacket * restrict r;
    aggregate = zero;
    total_weight = 0.0;
    r = (p + (2 * (image->columns + 4))) + 2;
    pixel = *r;
    r = p;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 5.0 * GetPixelRed(r);
      aggregate.green += 5.0 * GetPixelGreen(r);
      aggregate.blue += 5.0 * GetPixelBlue(r);
      aggregate.opacity += 5.0 * GetPixelOpacity(r);
      total_weight += 5.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 8.0 * GetPixelRed(r);
      aggregate.green += 8.0 * GetPixelGreen(r);
      aggregate.blue += 8.0 * GetPixelBlue(r);
      aggregate.opacity += 8.0 * GetPixelOpacity(r);
      total_weight += 8.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 10.0 * GetPixelRed(r);
      aggregate.green += 10.0 * GetPixelGreen(r);
      aggregate.blue += 10.0 * GetPixelBlue(r);
      aggregate.opacity += 10.0 * GetPixelOpacity(r);
      total_weight += 10.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 8.0 * GetPixelRed(r);
      aggregate.green += 8.0 * GetPixelGreen(r);
      aggregate.blue += 8.0 * GetPixelBlue(r);
      aggregate.opacity += 8.0 * GetPixelOpacity(r);
      total_weight += 8.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 5.0 * GetPixelRed(r);
      aggregate.green += 5.0 * GetPixelGreen(r);
      aggregate.blue += 5.0 * GetPixelBlue(r);
      aggregate.opacity += 5.0 * GetPixelOpacity(r);
      total_weight += 5.0;
    }

    r++;
    ;
    r = p + (image->columns + 4);
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 8.0 * GetPixelRed(r);
      aggregate.green += 8.0 * GetPixelGreen(r);
      aggregate.blue += 8.0 * GetPixelBlue(r);
      aggregate.opacity += 8.0 * GetPixelOpacity(r);
      total_weight += 8.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 20.0 * GetPixelRed(r);
      aggregate.green += 20.0 * GetPixelGreen(r);
      aggregate.blue += 20.0 * GetPixelBlue(r);
      aggregate.opacity += 20.0 * GetPixelOpacity(r);
      total_weight += 20.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 40.0 * GetPixelRed(r);
      aggregate.green += 40.0 * GetPixelGreen(r);
      aggregate.blue += 40.0 * GetPixelBlue(r);
      aggregate.opacity += 40.0 * GetPixelOpacity(r);
      total_weight += 40.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 20.0 * GetPixelRed(r);
      aggregate.green += 20.0 * GetPixelGreen(r);
      aggregate.blue += 20.0 * GetPixelBlue(r);
      aggregate.opacity += 20.0 * GetPixelOpacity(r);
      total_weight += 20.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 8.0 * GetPixelRed(r);
      aggregate.green += 8.0 * GetPixelGreen(r);
      aggregate.blue += 8.0 * GetPixelBlue(r);
      aggregate.opacity += 8.0 * GetPixelOpacity(r);
      total_weight += 8.0;
    }

    r++;
    ;
    r = p + (2 * (image->columns + 4));
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 10.0 * GetPixelRed(r);
      aggregate.green += 10.0 * GetPixelGreen(r);
      aggregate.blue += 10.0 * GetPixelBlue(r);
      aggregate.opacity += 10.0 * GetPixelOpacity(r);
      total_weight += 10.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 40.0 * GetPixelRed(r);
      aggregate.green += 40.0 * GetPixelGreen(r);
      aggregate.blue += 40.0 * GetPixelBlue(r);
      aggregate.opacity += 40.0 * GetPixelOpacity(r);
      total_weight += 40.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 80.0 * GetPixelRed(r);
      aggregate.green += 80.0 * GetPixelGreen(r);
      aggregate.blue += 80.0 * GetPixelBlue(r);
      aggregate.opacity += 80.0 * GetPixelOpacity(r);
      total_weight += 80.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 40.0 * GetPixelRed(r);
      aggregate.green += 40.0 * GetPixelGreen(r);
      aggregate.blue += 40.0 * GetPixelBlue(r);
      aggregate.opacity += 40.0 * GetPixelOpacity(r);
      total_weight += 40.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 10.0 * GetPixelRed(r);
      aggregate.green += 10.0 * GetPixelGreen(r);
      aggregate.blue += 10.0 * GetPixelBlue(r);
      aggregate.opacity += 10.0 * GetPixelOpacity(r);
      total_weight += 10.0;
    }

    r++;
    ;
    r = p + (3 * (image->columns + 4));
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 8.0 * GetPixelRed(r);
      aggregate.green += 8.0 * GetPixelGreen(r);
      aggregate.blue += 8.0 * GetPixelBlue(r);
      aggregate.opacity += 8.0 * GetPixelOpacity(r);
      total_weight += 8.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 20.0 * GetPixelRed(r);
      aggregate.green += 20.0 * GetPixelGreen(r);
      aggregate.blue += 20.0 * GetPixelBlue(r);
      aggregate.opacity += 20.0 * GetPixelOpacity(r);
      total_weight += 20.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 40.0 * GetPixelRed(r);
      aggregate.green += 40.0 * GetPixelGreen(r);
      aggregate.blue += 40.0 * GetPixelBlue(r);
      aggregate.opacity += 40.0 * GetPixelOpacity(r);
      total_weight += 40.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 20.0 * GetPixelRed(r);
      aggregate.green += 20.0 * GetPixelGreen(r);
      aggregate.blue += 20.0 * GetPixelBlue(r);
      aggregate.opacity += 20.0 * GetPixelOpacity(r);
      total_weight += 20.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 8.0 * GetPixelRed(r);
      aggregate.green += 8.0 * GetPixelGreen(r);
      aggregate.blue += 8.0 * GetPixelBlue(r);
      aggregate.opacity += 8.0 * GetPixelOpacity(r);
      total_weight += 8.0;
    }

    r++;
    ;
    r = p + (4 * (image->columns + 4));
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 5.0 * GetPixelRed(r);
      aggregate.green += 5.0 * GetPixelGreen(r);
      aggregate.blue += 5.0 * GetPixelBlue(r);
      aggregate.opacity += 5.0 * GetPixelOpacity(r);
      total_weight += 5.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 8.0 * GetPixelRed(r);
      aggregate.green += 8.0 * GetPixelGreen(r);
      aggregate.blue += 8.0 * GetPixelBlue(r);
      aggregate.opacity += 8.0 * GetPixelOpacity(r);
      total_weight += 8.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 10.0 * GetPixelRed(r);
      aggregate.green += 10.0 * GetPixelGreen(r);
      aggregate.blue += 10.0 * GetPixelBlue(r);
      aggregate.opacity += 10.0 * GetPixelOpacity(r);
      total_weight += 10.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 8.0 * GetPixelRed(r);
      aggregate.green += 8.0 * GetPixelGreen(r);
      aggregate.blue += 8.0 * GetPixelBlue(r);
      aggregate.opacity += 8.0 * GetPixelOpacity(r);
      total_weight += 8.0;
    }

    r++;
    ;
    mean = (((MagickRealType) GetPixelRed(r)) + pixel.red) / 2;
    distance = ((MagickRealType) GetPixelRed(r)) - ((MagickRealType) pixel.red);
    distance_squared = (((((double) 1.0) / ((double) QuantumRange)) * ((2.0 * (((MagickRealType) QuantumRange) + 1.0)) + mean)) * distance) * distance;
    mean = (((MagickRealType) GetPixelGreen(r)) + pixel.green) / 2;
    distance = ((MagickRealType) GetPixelGreen(r)) - ((MagickRealType) pixel.green);
    distance_squared += (4.0 * distance) * distance;
    mean = (((MagickRealType) GetPixelBlue(r)) + pixel.blue) / 2;
    distance = ((MagickRealType) GetPixelBlue(r)) - ((MagickRealType) pixel.blue);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    mean = (((MagickRealType) r->opacity) + pixel.opacity) / 2;
    distance = ((MagickRealType) r->opacity) - ((MagickRealType) pixel.opacity);
    distance_squared += (((((double) 1.0) / ((double) QuantumRange)) * (((3.0 * (((MagickRealType) QuantumRange) + 1.0)) - 1.0) - mean)) * distance) * distance;
    if (distance_squared < ((((MagickRealType) QuantumRange) * ((MagickRealType) QuantumRange)) / 25.0f))
    {
      aggregate.red += 5.0 * GetPixelRed(r);
      aggregate.green += 5.0 * GetPixelGreen(r);
      aggregate.blue += 5.0 * GetPixelBlue(r);
      aggregate.opacity += 5.0 * GetPixelOpacity(r);
      total_weight += 5.0;
    }

    r++;
    ;
    SetPixelRed(q, ((aggregate.red + (total_weight / 2)) - 1) / total_weight);
    SetPixelGreen(q, ((aggregate.green + (total_weight / 2)) - 1) / total_weight);
    SetPixelBlue(q, ((aggregate.blue + (total_weight / 2)) - 1) / total_weight);
    SetPixelOpacity(q, ((aggregate.opacity + (total_weight / 2)) - 1) / total_weight);
    p++;
    q++;
  }

  if (SyncCacheViewAuthenticPixels(enhance_view, exception) == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_EnhanceImage)
    proceed = SetImageProgress(image, "Enhance/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

