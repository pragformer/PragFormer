for (y = 0; y < ((ssize_t) image->rows); y++)
{
  MagickBooleanType sync;
  MagickPixelPacket pixel;
  Quantum quantum;
  register const PixelPacket * restrict p;
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  q = QueueCacheViewAuthenticPixels(shift_view, 0, y, shift_image->columns, 1, exception);
  if ((p == ((const PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
  {
    status = MagickFalse;
    continue;
  }

  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    quantum = GetPixelRed(p);
    if (GetPixelGreen(p) < quantum)
      quantum = GetPixelGreen(p);

    if (GetPixelBlue(p) < quantum)
      quantum = GetPixelBlue(p);

    pixel.red = 0.5 * (GetPixelRed(p) + (factor * quantum));
    pixel.green = 0.5 * (GetPixelGreen(p) + (factor * quantum));
    pixel.blue = 0.5 * (GetPixelBlue(p) + (factor * quantum));
    quantum = GetPixelRed(p);
    if (GetPixelGreen(p) > quantum)
      quantum = GetPixelGreen(p);

    if (GetPixelBlue(p) > quantum)
      quantum = GetPixelBlue(p);

    pixel.red = 0.5 * (pixel.red + (factor * quantum));
    pixel.green = 0.5 * (pixel.green + (factor * quantum));
    pixel.blue = 0.5 * (pixel.blue + (factor * quantum));
    SetPixelRed(q, ClampToQuantum(pixel.red));
    SetPixelGreen(q, ClampToQuantum(pixel.green));
    SetPixelBlue(q, ClampToQuantum(pixel.blue));
    p++;
    q++;
  }

  sync = SyncCacheViewAuthenticPixels(shift_view, exception);
  if (sync == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_BlueShiftImage)
    proceed = SetImageProgress(image, "BlueShift/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

