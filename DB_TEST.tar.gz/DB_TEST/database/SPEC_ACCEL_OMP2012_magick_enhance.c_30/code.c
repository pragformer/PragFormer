for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  intensity += histogram[i].blue;
  if (intensity > black_point)
    break;

}
