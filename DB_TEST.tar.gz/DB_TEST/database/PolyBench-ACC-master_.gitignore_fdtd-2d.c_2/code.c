for (i = 0; i < POLYBENCH_LOOP_BOUND(1000, nx); i++)
  for (j = 1; j < POLYBENCH_LOOP_BOUND(1000, ny); j++)
  ex[i][j] = ex[i][j] - (0.5 * (hz[i][j] - hz[i][j - 1]));

