for (i = (ssize_t) MaxMap; i != 0; i--)
{
  intensity += histogram[i].blue;
  if (intensity > ((((double) image->columns) * image->rows) - white_point))
    break;

}
