for (i = 0; i < ((ssize_t) number_grays); i++)
{
  cooccurrence[i] = (ChannelStatistics *) AcquireQuantumMemory(number_grays, sizeof(*(*cooccurrence)));
  Q[i] = (ChannelStatistics *) AcquireQuantumMemory(number_grays, sizeof(*(*Q)));
  if ((cooccurrence[i] == ((ChannelStatistics *) 0)) || (Q[i] == ((ChannelStatistics *) 0)))
    break;

  (void) ResetMagickMemory(cooccurrence[i], 0, number_grays * (sizeof(*(*cooccurrence))));
  (void) ResetMagickMemory(Q[i], 0, number_grays * (sizeof(*(*Q))));
}
