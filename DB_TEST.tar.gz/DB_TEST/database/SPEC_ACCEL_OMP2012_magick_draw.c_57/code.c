for (; i < ((ssize_t) ((p + q) + closed_path)); i++)
{
  stroke_polygon[i] = polygon_primitive[0];
  stroke_polygon[i].point = path_q[((p + q) + closed_path) - (i + 1)];
}
