for (j = 0; j < ((ssize_t) polygon_info->number_edges); j++, p++)
{
  if (y <= p->bounds.y1)
    break;

  if ((y > p->bounds.y2) || (x <= p->bounds.x1))
    continue;

  if (x > p->bounds.x2)
  {
    winding_number += (p->direction) ? (1) : (-1);
    continue;
  }

  i = (ssize_t) MagickMax((double) p->highwater, 1.0);
  for (; i < ((ssize_t) p->number_points); i++)
    if (y <= p->points[i].y)
    break;


  q = (p->points + i) - 1;
  if ((((q + 1)->x - q->x) * (y - q->y)) <= (((q + 1)->y - q->y) * (x - q->x)))
    winding_number += (p->direction) ? (1) : (-1);

}

inline static double MagickMax(const double x, const double y)
{
  if (x > y)
    return x;

  return y;
}

