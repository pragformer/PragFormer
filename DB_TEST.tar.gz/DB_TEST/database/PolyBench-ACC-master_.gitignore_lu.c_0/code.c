for (k = 0; k < POLYBENCH_LOOP_BOUND(1024, n); k++)
{
  for (j = k + 1; j < POLYBENCH_LOOP_BOUND(1024, n); j++)
    A[k][j] = A[k][j] / A[k][k];

  for (i = k + 1; i < POLYBENCH_LOOP_BOUND(1024, n); i++)
    for (j = k + 1; j < POLYBENCH_LOOP_BOUND(1024, n); j++)
    A[i][j] = A[i][j] - (A[i][k] * A[k][j]);


}
