for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register const PixelPacket * restrict p;
  register ssize_t x;
  p = GetVirtualPixels(image, 0, y, image->columns, 1, exception);
  if (p == ((const PixelPacket *) 0))
    break;

  for (x = ((ssize_t) image->columns) - 1; x >= 0; x--)
  {
    histogram[ScaleQuantumToMap(PixelIntensityToQuantum(p))]++;
    p++;
  }

}

inline static Quantum PixelIntensityToQuantum(const PixelPacket *pixel)
{
  if ((GetPixelRed(pixel) == GetPixelGreen(pixel)) && (GetPixelGreen(pixel) == GetPixelBlue(pixel)))
    return GetPixelRed(pixel);

  return (Quantum) ((((0.299 * GetPixelRed(pixel)) + (0.587 * GetPixelGreen(pixel))) + (0.114 * GetPixelBlue(pixel))) + 0.5);
}

