for (i = 0; i < 4; i++)
{
  point = extent[i];
  extent[i].x = ((point.x * affine->sx) + (point.y * affine->ry)) + affine->tx;
  extent[i].y = ((point.x * affine->rx) + (point.y * affine->sy)) + affine->ty;
}
