for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register IndexPacket * restrict indexes;
  register const PixelPacket * restrict q;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    register size_t intensity;
    intensity = ScaleQuantumToMap(GetPixelRed(q));
    if (colormap_index[intensity] < 0)
    {
      #pragma omp critical (MagickCore_SetGrayscaleImage)
      if (colormap_index[intensity] < 0)
      {
        colormap_index[intensity] = (ssize_t) image->colors;
        image->colormap[image->colors].red = GetPixelRed(q);
        image->colormap[image->colors].green = GetPixelGreen(q);
        image->colormap[image->colors].blue = GetPixelBlue(q);
        image->colors++;
      }

    }

    SetPixelIndex(indexes + x, colormap_index[intensity]);
    q++;
  }

  if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
    status = MagickFalse;

}
