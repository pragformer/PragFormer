for (i = 0; i < tmax; i++)
  _fict_[i] = (double) i;
