for (i = 0; i < 256; i++)
{
  byte = (unsigned char) i;
  for (count = 0; byte != 0; byte >>= 1)
    count += byte & 0x01;

  bits[i] = (unsigned short) count;
}
