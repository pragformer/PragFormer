for (i = 0; i < (POLYBENCH_LOOP_BOUND(1000, nx) - 1); i++)
  for (j = 0; j < (POLYBENCH_LOOP_BOUND(1000, ny) - 1); j++)
  hz[i][j] = hz[i][j] - (0.7 * (((ex[i][j + 1] - ex[i][j]) + ey[i + 1][j]) - ey[i][j]));

