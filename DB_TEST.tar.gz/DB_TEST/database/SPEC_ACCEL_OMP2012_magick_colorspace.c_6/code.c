for (i = 0; i <= ((ssize_t) MaxMap); i++)
  logmap[i] = ScaleMapToQuantum((MagickRealType) ((MaxMap * (reference_white + (log10(black + ((((MagickRealType) i) / MaxMap) * (1.0 - black))) / (((gamma / density) * 0.002) / film_gamma)))) / 1024.0));
