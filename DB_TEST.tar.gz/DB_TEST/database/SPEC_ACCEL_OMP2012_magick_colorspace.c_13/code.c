for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  MagickRealType v;
  v = ((MagickRealType) i) / ((MagickRealType) MaxMap);
  if ((((MagickRealType) i) / ((MagickRealType) MaxMap)) <= 0.04045f)
    v /= 12.92f;
  else
    v = (MagickRealType) pow(((((double) i) / MaxMap) + 0.055) / 1.055, 2.4);

  x_map[i].x = (1.0f * MaxMap) * v;
  y_map[i].x = (0.0f * MaxMap) * v;
  z_map[i].x = (0.0f * MaxMap) * v;
  x_map[i].y = (0.0f * MaxMap) * v;
  y_map[i].y = (1.0f * MaxMap) * v;
  z_map[i].y = (0.0f * MaxMap) * v;
  x_map[i].z = (0.0f * MaxMap) * v;
  y_map[i].z = (0.0f * MaxMap) * v;
  z_map[i].z = (1.0f * MaxMap) * v;
}
