for (j = 0; j <= (POLYBENCH_LOOP_BOUND(6, maxgrid) - 1); j++)
{
  for (i = j; i <= (POLYBENCH_LOOP_BOUND(6, maxgrid) - 1); i++)
  {
    sum_diff[j][i][0] = diff[j][i][0];
    for (cnt = 1; cnt <= (POLYBENCH_LOOP_BOUND(64, length) - 1); cnt++)
      sum_diff[j][i][cnt] = sum_diff[j][i][cnt - 1] + diff[j][i][cnt];

    mean[j][i] = sum_diff[j][i][POLYBENCH_LOOP_BOUND(64, length) - 1];
  }

}
