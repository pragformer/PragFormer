for (i = 0; i < ((ssize_t) image->colors); i++)
{
  if ((channel & RedChannel) != 0)
    image->colormap[i].red = ClampToQuantum(((MagickRealType) QuantumRange) * pow(scale * (((double) image->colormap[i].red) - black_point), 1.0 / gamma));

  if ((channel & GreenChannel) != 0)
    image->colormap[i].green = ClampToQuantum(((MagickRealType) QuantumRange) * pow(scale * (((double) image->colormap[i].green) - black_point), 1.0 / gamma));

  if ((channel & BlueChannel) != 0)
    image->colormap[i].blue = ClampToQuantum(((MagickRealType) QuantumRange) * pow(scale * (((double) image->colormap[i].blue) - black_point), 1.0 / gamma));

  if ((channel & OpacityChannel) != 0)
    image->colormap[i].opacity = ClampToQuantum(((MagickRealType) QuantumRange) * pow(scale * (((double) image->colormap[i].opacity) - black_point), 1.0 / gamma));

}

inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}


inline static Quantum ClampToQuantum(const MagickRealType value)
{
  if (value <= 0.0)
    return (Quantum) 0;

  if (value >= ((MagickRealType) QuantumRange))
    return (Quantum) QuantumRange;

  return (Quantum) (value + 0.5);
}

