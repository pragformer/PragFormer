for (j = 0; j <= (i - 1); j++)
  x[i] = x[i] - (A[i][j] * x[j]);
