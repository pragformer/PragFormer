for (; i <= ((ssize_t) MaxMap); i++)
  logmap[i] = (Quantum) QuantumRange;
