for (i = 0; i < length; i++)
  for (j = 0; j < length; j++)
{
  c[i][j] = (i * j) % 2;
  W[i][j] = (((int) i) - j) / length;
}

