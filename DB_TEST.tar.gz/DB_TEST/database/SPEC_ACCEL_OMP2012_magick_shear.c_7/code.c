for (i = 1; i < 4; i++)
{
  if (min.x > extent[i].x)
    min.x = extent[i].x;

  if (min.y > extent[i].y)
    min.y = extent[i].y;

  if (max.x < extent[i].x)
    max.x = extent[i].x;

  if (max.y < extent[i].y)
    max.y = extent[i].y;

}
