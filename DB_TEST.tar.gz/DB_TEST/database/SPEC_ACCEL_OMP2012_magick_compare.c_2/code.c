for (y = 0; y < ((ssize_t) image->rows); y++)
{
  double channel_distortion[CompositeChannels + 1];
  register const IndexPacket * restrict indexes;
  register const IndexPacket * restrict reconstruct_indexes;
  register const PixelPacket * restrict p;
  register const PixelPacket * restrict q;
  register ssize_t i;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  q = GetCacheViewVirtualPixels(reconstruct_view, 0, y, reconstruct_image->columns, 1, exception);
  if ((p == ((const PixelPacket *) 0)) || (q == ((const PixelPacket *) 0)))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewVirtualIndexQueue(image_view);
  reconstruct_indexes = GetCacheViewVirtualIndexQueue(reconstruct_view);
  (void) ResetMagickMemory(channel_distortion, 0, sizeof(channel_distortion));
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    MagickRealType distance;
    if ((channel & RedChannel) != 0)
    {
      distance = (((double) 1.0) / ((double) QuantumRange)) * (GetPixelRed(p) - ((MagickRealType) GetPixelRed(q)));
      channel_distortion[RedChannel] += distance * distance;
      channel_distortion[CompositeChannels] += distance * distance;
    }

    if ((channel & GreenChannel) != 0)
    {
      distance = (((double) 1.0) / ((double) QuantumRange)) * (GetPixelGreen(p) - ((MagickRealType) GetPixelGreen(q)));
      channel_distortion[GreenChannel] += distance * distance;
      channel_distortion[CompositeChannels] += distance * distance;
    }

    if ((channel & BlueChannel) != 0)
    {
      distance = (((double) 1.0) / ((double) QuantumRange)) * (GetPixelBlue(p) - ((MagickRealType) GetPixelBlue(q)));
      channel_distortion[BlueChannel] += distance * distance;
      channel_distortion[CompositeChannels] += distance * distance;
    }

    if (((channel & OpacityChannel) != 0) && ((image->matte != MagickFalse) || (reconstruct_image->matte != MagickFalse)))
    {
      distance = (((double) 1.0) / ((double) QuantumRange)) * (((image->matte != MagickFalse) ? (GetPixelOpacity(p)) : (OpaqueOpacity)) - ((reconstruct_image->matte != MagickFalse) ? (GetPixelOpacity(q)) : (OpaqueOpacity)));
      channel_distortion[OpacityChannel] += distance * distance;
      channel_distortion[CompositeChannels] += distance * distance;
    }

    if ((((channel & IndexChannel) != 0) && (image->colorspace == CMYKColorspace)) && (reconstruct_image->colorspace == CMYKColorspace))
    {
      distance = (((double) 1.0) / ((double) QuantumRange)) * (GetPixelIndex(indexes + x) - ((MagickRealType) GetPixelIndex(reconstruct_indexes + x)));
      channel_distortion[BlackChannel] += distance * distance;
      channel_distortion[CompositeChannels] += distance * distance;
    }

    p++;
    q++;
  }

  #pragma omp critical (MagickCore_GetMeanSquaredError)
  for (i = 0; i <= ((ssize_t) CompositeChannels); i++)
    distortion[i] += channel_distortion[i];

}
