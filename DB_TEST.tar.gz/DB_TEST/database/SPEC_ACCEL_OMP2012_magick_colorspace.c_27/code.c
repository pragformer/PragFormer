for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  x_map[i].x = (MagickRealType) i;
  y_map[i].x = 0.000000f;
  z_map[i].x = (1.574800f * 0.50000f) * ((2.00000f * ((MagickRealType) i)) - ((MagickRealType) MaxMap));
  x_map[i].y = (MagickRealType) i;
  y_map[i].y = ((-0.187324f) * 0.50000f) * ((2.00000f * ((MagickRealType) i)) - ((MagickRealType) MaxMap));
  z_map[i].y = ((-0.468124f) * 0.50000f) * ((2.00000f * ((MagickRealType) i)) - ((MagickRealType) MaxMap));
  x_map[i].z = (MagickRealType) i;
  y_map[i].z = (1.855600f * 0.50000f) * ((2.00000f * ((MagickRealType) i)) - ((MagickRealType) MaxMap));
  z_map[i].z = 0.00000f;
}
