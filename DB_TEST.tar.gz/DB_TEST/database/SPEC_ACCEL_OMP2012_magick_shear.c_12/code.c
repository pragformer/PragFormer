for (width = 1; width < ((image->columns + 7) / 8); width <<= 1)
  ;
