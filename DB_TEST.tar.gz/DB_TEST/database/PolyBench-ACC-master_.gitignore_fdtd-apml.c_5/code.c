for (i = 0; i <= cz; i++)
  for (j = 0; j <= cym; j++)
  for (k = 0; k <= cxm; k++)
{
  fprintf(stderr, "%0.2lf ", Bza[i][j][k]);
  fprintf(stderr, "%0.2lf ", Ex[i][j][k]);
  fprintf(stderr, "%0.2lf ", Ey[i][j][k]);
  fprintf(stderr, "%0.2lf ", Hz[i][j][k]);
  if ((((i * cxm) + j) % 20) == 0)
    fprintf(stderr, "\n");

}


