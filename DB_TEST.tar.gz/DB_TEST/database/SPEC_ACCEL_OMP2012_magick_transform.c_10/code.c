for (y = 0; y < ((ssize_t) splice_geometry.y); y++)
{
  register const PixelPacket * restrict p;
  register IndexPacket * restrict indexes;
  register IndexPacket * restrict splice_indexes;
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  q = QueueCacheViewAuthenticPixels(splice_view, 0, y, splice_image->columns, 1, exception);
  if ((p == ((const PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  splice_indexes = GetCacheViewAuthenticIndexQueue(splice_view);
  for (x = 0; x < splice_geometry.x; x++)
  {
    SetPixelRed(q, GetPixelRed(p));
    SetPixelGreen(q, GetPixelGreen(p));
    SetPixelBlue(q, GetPixelBlue(p));
    SetPixelOpacity(q, (Quantum) 0UL);
    if (image->matte != MagickFalse)
      SetPixelOpacity(q, GetPixelOpacity(p));

    if (image->colorspace == CMYKColorspace)
      SetPixelIndex(splice_indexes + x, GetPixelIndex(indexes));

    indexes++;
    p++;
    q++;
  }

  for (; x < ((ssize_t) (splice_geometry.x + splice_geometry.width)); x++)
    q++;

  for (; x < ((ssize_t) splice_image->columns); x++)
  {
    SetPixelRed(q, GetPixelRed(p));
    SetPixelGreen(q, GetPixelGreen(p));
    SetPixelBlue(q, GetPixelBlue(p));
    SetPixelOpacity(q, (Quantum) 0UL);
    if (image->matte != MagickFalse)
      SetPixelOpacity(q, GetPixelOpacity(p));

    if (image->colorspace == CMYKColorspace)
      SetPixelIndex(splice_indexes + x, GetPixelIndex(indexes));

    indexes++;
    p++;
    q++;
  }

  if (SyncCacheViewAuthenticPixels(splice_view, exception) == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_TransposeImage)
    proceed = SetImageProgress(image, "Splice/Image", progress++, splice_image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

