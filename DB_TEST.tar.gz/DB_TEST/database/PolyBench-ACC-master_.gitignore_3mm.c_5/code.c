for (i = 0; i < nj; i++)
  for (j = 0; j < nm; j++)
  C[i][j] = (((double) i) * (j + 3)) / nl;

