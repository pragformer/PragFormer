for (y = 0; y < ((ssize_t) image->rows); y++)
{
  const int id = GetOpenMPThreadId();
  register const IndexPacket * restrict indexes;
  register const PixelPacket * restrict p;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  if (p == ((const PixelPacket *) 0))
    continue;

  indexes = GetCacheViewVirtualIndexQueue(image_view);
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    while (current_depth[id] < MAGICKCORE_QUANTUM_DEPTH)
    {
      MagickStatusType status;
      QuantumAny range;
      status = 0;
      range = GetQuantumRange(current_depth[id]);
      if ((channel & RedChannel) != 0)
        status |= p->red != ScaleAnyToQuantum(ScaleQuantumToAny(p->red, range), range);

      if ((channel & GreenChannel) != 0)
        status |= p->green != ScaleAnyToQuantum(ScaleQuantumToAny(p->green, range), range);

      if ((channel & BlueChannel) != 0)
        status |= p->blue != ScaleAnyToQuantum(ScaleQuantumToAny(p->blue, range), range);

      if (((channel & OpacityChannel) != 0) && (image->matte != MagickFalse))
        status |= p->opacity != ScaleAnyToQuantum(ScaleQuantumToAny(p->opacity, range), range);

      if (((channel & IndexChannel) != 0) && (image->colorspace == CMYKColorspace))
        status |= (*(indexes + x)) != ScaleAnyToQuantum(ScaleQuantumToAny(*(indexes + x), range), range);

      if (status == 0)
        break;

      current_depth[id]++;
    }

    p++;
  }

  if (current_depth[id] == MAGICKCORE_QUANTUM_DEPTH)
    status = MagickFalse;

}

inline static int GetOpenMPThreadId(void)
{
  return 0;
}

