for (j1 = 0; j1 < POLYBENCH_LOOP_BOUND(1000, m); j1++)
  for (j2 = j1; j2 < POLYBENCH_LOOP_BOUND(1000, m); j2++)
{
  symmat[j1][j2] = 0.0;
  for (i = 0; i < POLYBENCH_LOOP_BOUND(1000, n); i++)
    symmat[j1][j2] += data[i][j1] * data[i][j2];

  symmat[j2][j1] = symmat[j1][j2];
}

