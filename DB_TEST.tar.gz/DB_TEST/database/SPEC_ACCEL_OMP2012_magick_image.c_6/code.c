for (; next != ((Image *) 0); next = GetNextImageInList(next))
{
  if (next->matte != MagickFalse)
    matte = MagickTrue;

  number_images++;
  if (stack != MagickFalse)
  {
    if (next->columns > width)
      width = next->columns;

    height += next->rows;
    continue;
  }

  width += next->columns;
  if (next->rows > height)
    height = next->rows;

}
