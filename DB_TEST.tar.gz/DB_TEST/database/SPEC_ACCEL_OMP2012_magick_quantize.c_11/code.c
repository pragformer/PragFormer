for (i = 0; i < 16; i++)
{
  pixel.red += p->weights[i] * p->error[i].red;
  pixel.green += p->weights[i] * p->error[i].green;
  pixel.blue += p->weights[i] * p->error[i].blue;
  if (cube_info->associate_alpha != MagickFalse)
    pixel.opacity += p->weights[i] * p->error[i].opacity;

}
