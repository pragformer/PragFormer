for (i = 0; i < n; i++)
{
  alpha[i] = i;
  beta[i] = ((i + 1) / n) / 2.0;
  r[i] = ((i + 1) / n) / 4.0;
  for (j = 0; j < n; j++)
  {
    y[i][j] = (((double) i) * j) / n;
    sum[i][j] = (((double) i) * j) / n;
  }

}
