for (i = 0; i < nx; i++)
  for (j = 0; j < ny; j++)
{
  ex[i][j] = (((double) i) * (j + 1)) / nx;
  ey[i][j] = (((double) i) * (j + 2)) / ny;
  hz[i][j] = (((double) i) * (j + 3)) / nx;
}

