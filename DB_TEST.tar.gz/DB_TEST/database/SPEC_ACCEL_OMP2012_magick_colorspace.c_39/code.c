for (i = 0; i <= ((ssize_t) ((reference_black * MaxMap) / 1024.0)); i++)
  logmap[i] = (Quantum) 0;
