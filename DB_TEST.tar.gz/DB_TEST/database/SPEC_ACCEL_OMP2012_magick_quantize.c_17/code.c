for (i = 0; i < 16; i++)
{
  cube_info->weights[i] /= weight;
  sum += cube_info->weights[i];
}
