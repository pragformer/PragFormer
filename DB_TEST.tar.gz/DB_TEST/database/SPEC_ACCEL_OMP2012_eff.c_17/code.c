for (k = 0; k < prm->Natom; k++)
{
  if (frozen[k])
  {
    f[(dim * k) + 0] = (f[(dim * k) + 1] = (f[(dim * k) + 2] = 0.0));
    if (dim == 4)
    {
      f[(dim * k) + 3] = 0.0;
    }

  }

}
