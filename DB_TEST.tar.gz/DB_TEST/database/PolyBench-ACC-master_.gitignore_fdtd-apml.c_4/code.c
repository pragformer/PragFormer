for (i = 0; i <= cz; i++)
  for (j = 0; j <= cym; j++)
{
  Ry[i][j] = ((((double) i) * (j + 1)) + 10) / cym;
  Ax[i][j] = ((((double) i) * (j + 2)) + 11) / cym;
  for (k = 0; k <= cxm; k++)
  {
    Ex[i][j][k] = (((((double) i) * (j + 3)) + k) + 1) / cxm;
    Ey[i][j][k] = (((((double) i) * (j + 4)) + k) + 2) / cym;
    Hz[i][j][k] = (((((double) i) * (j + 5)) + k) + 3) / cz;
  }

}

