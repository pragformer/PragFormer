for (i = 0; i <= cym; i++)
{
  cymh[i] = (((double) i) + 5) / cxm;
  cyph[i] = (((double) i) + 6) / cxm;
}
