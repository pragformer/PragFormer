for (i = 0; i < ((ssize_t) primitive_info->coordinates); i++)
{
  p->primitive = primitive_info->primitive;
  p--;
}
