for (i = 0; i < (dim * prm->Natom); i++)
{
  f[i] = grad[i];
}
