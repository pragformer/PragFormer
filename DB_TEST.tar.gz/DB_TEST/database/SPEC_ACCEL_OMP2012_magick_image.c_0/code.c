for (y = 0; y < ((ssize_t) image->rows); y++)
{
  MagickBooleanType sync;
  register const IndexPacket * restrict indexes;
  register const PixelPacket * restrict p;
  register IndexPacket * restrict append_indexes;
  register PixelPacket * restrict q;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  q = QueueCacheViewAuthenticPixels(append_view, x_offset, y + y_offset, image->columns, 1, exception);
  if ((p == ((const PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewVirtualIndexQueue(image_view);
  append_indexes = GetCacheViewAuthenticIndexQueue(append_view);
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    SetPixelRed(q, GetPixelRed(p));
    SetPixelGreen(q, GetPixelGreen(p));
    SetPixelBlue(q, GetPixelBlue(p));
    SetPixelOpacity(q, OpaqueOpacity);
    if (image->matte != MagickFalse)
      SetPixelOpacity(q, GetPixelOpacity(p));

    if ((image->colorspace == CMYKColorspace) && (append_image->colorspace == CMYKColorspace))
      SetPixelIndex(append_indexes + x, GetPixelIndex(indexes + x));

    p++;
    q++;
  }

  sync = SyncCacheViewAuthenticPixels(append_view, exception);
  if (sync == MagickFalse)
    status = MagickFalse;

}
