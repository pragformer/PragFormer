for (i = 1; i < (POLYBENCH_LOOP_BOUND(10000, n) - 1); i++)
  B[i] = 0.33333 * ((A[i - 1] + A[i]) + A[i + 1]);
