for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  x_map[i].x = 1.0f * ((MagickRealType) i);
  y_map[i].x = 0.0f * ((MagickRealType) i);
  z_map[i].x = 0.0f * ((MagickRealType) i);
  x_map[i].y = 0.0f * ((MagickRealType) i);
  y_map[i].y = 1.0f * ((MagickRealType) i);
  z_map[i].y = 0.0f * ((MagickRealType) i);
  x_map[i].z = 0.0f * ((MagickRealType) i);
  y_map[i].z = 0.0f * ((MagickRealType) i);
  z_map[i].z = 1.0f * ((MagickRealType) i);
}
