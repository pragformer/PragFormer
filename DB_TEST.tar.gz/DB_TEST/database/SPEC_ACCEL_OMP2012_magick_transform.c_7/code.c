for (y = 0; y < ((ssize_t) excerpt_image->rows); y++)
{
  register const PixelPacket * restrict p;
  register IndexPacket * restrict excerpt_indexes;
  register IndexPacket * restrict indexes;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, geometry->x, geometry->y + y, geometry->width, 1, exception);
  q = GetCacheViewAuthenticPixels(excerpt_view, 0, y, excerpt_image->columns, 1, exception);
  if ((p == ((const PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
  {
    status = MagickFalse;
    continue;
  }

  (void) CopyMagickMemory(q, p, ((size_t) excerpt_image->columns) * (sizeof(*q)));
  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  if (indexes != ((IndexPacket *) 0))
  {
    excerpt_indexes = GetCacheViewAuthenticIndexQueue(excerpt_view);
    if (excerpt_indexes != ((IndexPacket *) 0))
      (void) CopyMagickMemory(excerpt_indexes, indexes, ((size_t) excerpt_image->columns) * (sizeof(*excerpt_indexes)));

  }

  if (SyncCacheViewAuthenticPixels(excerpt_view, exception) == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_ExcerptImage)
    proceed = SetImageProgress(image, "Excerpt/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

