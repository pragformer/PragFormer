for (y = 0; y < ((ssize_t) image->rows); y++)
{
  MagickPixelPacket pixel;
  register ssize_t x;
  register PixelPacket * restrict q;
  register size_t blue;
  register size_t green;
  register size_t red;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    red = ScaleQuantumToMap(GetPixelRed(q));
    green = ScaleQuantumToMap(GetPixelGreen(q));
    blue = ScaleQuantumToMap(GetPixelBlue(q));
    pixel.red = ((x_map[red].x + y_map[green].x) + z_map[blue].x) + ((MagickRealType) primary_info.x);
    pixel.green = ((x_map[red].y + y_map[green].y) + z_map[blue].y) + ((MagickRealType) primary_info.y);
    pixel.blue = ((x_map[red].z + y_map[green].z) + z_map[blue].z) + ((MagickRealType) primary_info.z);
    SetPixelRed(q, ScaleMapToQuantum(pixel.red));
    SetPixelGreen(q, ScaleMapToQuantum(pixel.green));
    SetPixelBlue(q, ScaleMapToQuantum(pixel.blue));
    q++;
  }

  sync = SyncCacheViewAuthenticPixels(image_view, exception);
  if (sync == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_RGBTransformImage)
    proceed = SetImageProgress(image, "RGBTransform/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

