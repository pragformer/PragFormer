for (y = 0; y < ((ssize_t) (frame_info->y - bevel_width)); y++)
{
  for (x = 0; x < ((ssize_t) frame_info->outer_bevel); x++)
  {
    SetPixelPacket(frame_image, &highlight, q, frame_indexes);
    q++;
    frame_indexes++;
  }

  width = frame_image->columns - (2 * frame_info->outer_bevel);
  for (x = 0; x < ((ssize_t) width); x++)
  {
    SetPixelPacket(frame_image, &matte, q, frame_indexes);
    q++;
    frame_indexes++;
  }

  for (x = 0; x < ((ssize_t) frame_info->outer_bevel); x++)
  {
    SetPixelPacket(frame_image, &shadow, q, frame_indexes);
    q++;
    frame_indexes++;
  }

}

inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}

