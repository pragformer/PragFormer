for (i = 0; i < 4; i++)
{
  double normalize;
  register ssize_t y;
  switch (i)
  {
    case 0:

    default:
    {
      normalize = (2.0 * image->rows) * (image->columns - distance);
      break;
    }

    case 1:
    {
      normalize = (2.0 * (image->rows - distance)) * image->columns;
      break;
    }

    case 2:
    {
      normalize = (2.0 * (image->rows - distance)) * (image->columns - distance);
      break;
    }

    case 3:
    {
      normalize = (2.0 * (image->rows - distance)) * (image->columns - distance);
      break;
    }

  }

  normalize = 1.0 / ((fabs((double) normalize) <= MagickEpsilon) ? (1.0) : (normalize));
  for (y = 0; y < ((ssize_t) number_grays); y++)
  {
    register ssize_t x;
    for (x = 0; x < ((ssize_t) number_grays); x++)
    {
      cooccurrence[x][y].direction[i].red *= normalize;
      cooccurrence[x][y].direction[i].green *= normalize;
      cooccurrence[x][y].direction[i].blue *= normalize;
      if (image->colorspace == CMYKColorspace)
        cooccurrence[x][y].direction[i].index *= normalize;

      if (image->matte != MagickFalse)
        cooccurrence[x][y].direction[i].opacity *= normalize;

    }

  }

}
