for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  x_map[i].x = 0.212600f * ((MagickRealType) i);
  y_map[i].x = 0.715200f * ((MagickRealType) i);
  z_map[i].x = 0.072200f * ((MagickRealType) i);
  x_map[i].y = (-0.114572f) * ((MagickRealType) i);
  y_map[i].y = (-0.385428f) * ((MagickRealType) i);
  z_map[i].y = 0.500000f * ((MagickRealType) i);
  x_map[i].z = 0.500000f * ((MagickRealType) i);
  y_map[i].z = (-0.454153f) * ((MagickRealType) i);
  z_map[i].z = (-0.045847f) * ((MagickRealType) i);
}
