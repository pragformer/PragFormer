for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  if ((channel & RedChannel) != 0)
    intensity.red += histogram[i].red;

  if ((channel & GreenChannel) != 0)
    intensity.green += histogram[i].green;

  if ((channel & BlueChannel) != 0)
    intensity.blue += histogram[i].blue;

  if ((channel & OpacityChannel) != 0)
    intensity.opacity += histogram[i].opacity;

  if (((channel & IndexChannel) != 0) && (image->colorspace == CMYKColorspace))
    intensity.index += histogram[i].index;

  map[i] = intensity;
}
