for (i = 0; i < n; i++)
  for (j = 0; j < n; j++)
{
  fprintf(stderr, "%0.2lf ", A[i][j]);
  if ((((i * 1024) + j) % 20) == 0)
    fprintf(stderr, "\n");

}

