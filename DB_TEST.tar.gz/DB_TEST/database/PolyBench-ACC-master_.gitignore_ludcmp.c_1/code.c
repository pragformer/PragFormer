for (i = 0; i <= (POLYBENCH_LOOP_BOUND(1024, n) - 1); i++)
{
  w = y[(POLYBENCH_LOOP_BOUND(1024, n) - 1) - i];
  for (j = POLYBENCH_LOOP_BOUND(1024, n) - i; j <= POLYBENCH_LOOP_BOUND(1024, n); j++)
    w = w - (A[(POLYBENCH_LOOP_BOUND(1024, n) - 1) - i][j] * x[j]);

  x[(POLYBENCH_LOOP_BOUND(1024, n) - 1) - i] = w / A[(POLYBENCH_LOOP_BOUND(1024, n) - 1) - i][(POLYBENCH_LOOP_BOUND(1024, n) - 1) - i];
}
