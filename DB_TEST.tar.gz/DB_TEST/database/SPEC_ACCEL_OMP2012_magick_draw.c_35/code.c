for (i = 0; i < 4; i++)
  linecap[i] = *primitive_info;
