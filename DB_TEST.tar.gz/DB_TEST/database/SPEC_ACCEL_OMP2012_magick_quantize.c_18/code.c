for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register const PixelPacket * restrict p;
  register ssize_t x;
  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  if (p == ((const PixelPacket *) 0))
    break;

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    index = 1UL * GetPixelIndex(indexes + x);
    if (image->matte != MagickFalse)
    {
      alpha = (MagickRealType) ((((double) 1.0) / ((double) QuantumRange)) * GetPixelAlpha(p));
      beta = (MagickRealType) ((((double) 1.0) / ((double) QuantumRange)) * (QuantumRange - image->colormap[index].opacity));
    }

    distance = fabs((alpha * GetPixelRed(p)) - (beta * image->colormap[index].red));
    mean_error_per_pixel += distance;
    mean_error += distance * distance;
    if (distance > maximum_error)
      maximum_error = distance;

    distance = fabs((alpha * GetPixelGreen(p)) - (beta * image->colormap[index].green));
    mean_error_per_pixel += distance;
    mean_error += distance * distance;
    if (distance > maximum_error)
      maximum_error = distance;

    distance = fabs((alpha * GetPixelBlue(p)) - (beta * image->colormap[index].blue));
    mean_error_per_pixel += distance;
    mean_error += distance * distance;
    if (distance > maximum_error)
      maximum_error = distance;

    p++;
  }

}
