for (j = 1; j <= (POLYBENCH_LOOP_BOUND(6, maxgrid) - 1); j++)
  for (i = j; i <= (POLYBENCH_LOOP_BOUND(6, maxgrid) - 1); i++)
  path[j][i] = path[j - 1][i - 1] + mean[j][i];

