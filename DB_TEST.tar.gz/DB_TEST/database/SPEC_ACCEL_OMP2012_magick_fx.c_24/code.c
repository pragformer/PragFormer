for (i = 1; i < ((ssize_t) number_frames); i++)
{
  morph_image = CloneImage(image, 0, 0, MagickTrue, exception);
  if (morph_image == ((Image *) 0))
  {
    morph_images = DestroyImageList(morph_images);
    return (Image *) 0;
  }

  AppendImageToList(&morph_images, morph_image);
  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    proceed = SetImageProgress(image, "Morph/Image", (MagickOffsetType) i, number_frames);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

