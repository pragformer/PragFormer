for (i = 0; i <= (POLYBENCH_LOOP_BOUND(50, length) - 2); i++)
{
  for (j = i + 1; j <= (POLYBENCH_LOOP_BOUND(50, length) - 1); j++)
  {
    sum_c[i][j][i] = 0;
    for (k = i + 1; k <= (j - 1); k++)
      sum_c[i][j][k] = (sum_c[i][j][k - 1] + c[i][k]) + c[k][j];

    c[i][j] = sum_c[i][j][j - 1] + W[i][j];
  }

}
