for (offset.y = 0; offset.y < ((double) height);)
{
  if ((flags & AspectValue) == 0)
  {
    crop.y = (ssize_t) MagickRound((MagickRealType) (offset.y - ((geometry.y > 0) ? (0) : (geometry.y))));
    offset.y += delta.y;
    crop.height = (size_t) MagickRound((MagickRealType) (offset.y + ((geometry.y < 0) ? (0) : (geometry.y))));
  }
  else
  {
    crop.y = (ssize_t) MagickRound((MagickRealType) (offset.y - ((geometry.y > 0) ? (geometry.y) : (0))));
    offset.y += delta.y;
    crop.height = (size_t) MagickRound((MagickRealType) (offset.y + ((geometry.y < 0) ? (geometry.y) : (0))));
  }

  crop.height -= crop.y;
  crop.y += image->page.y;
  for (offset.x = 0; offset.x < ((double) width);)
  {
    if ((flags & AspectValue) == 0)
    {
      crop.x = (ssize_t) MagickRound((MagickRealType) (offset.x - ((geometry.x > 0) ? (0) : (geometry.x))));
      offset.x += +delta.x;
      crop.width = (size_t) MagickRound((MagickRealType) (offset.x + ((geometry.x < 0) ? (0) : (geometry.x))));
    }
    else
    {
      crop.x = (ssize_t) MagickRound((MagickRealType) (offset.x - ((geometry.x > 0) ? (geometry.x) : (0))));
      offset.x += +delta.x;
      crop.width = (size_t) MagickRound((MagickRealType) (offset.x + ((geometry.x < 0) ? (geometry.x) : (0))));
    }

    crop.width -= crop.x;
    crop.x += image->page.x;
    next = CropImage(image, &crop, exception);
    if (next == ((Image *) 0))
      break;

    AppendImageToList(&crop_image, next);
  }

  if (next == ((Image *) 0))
    break;

}

inline static ssize_t MagickRound(MagickRealType x)
{
  if (x >= 0.0)
    return (ssize_t) (x + 0.5);

  return (ssize_t) (x - 0.5);
}


inline static ssize_t MagickRound(MagickRealType x)
{
  if (x >= 0.0)
    return (ssize_t) (x + 0.5);

  return (ssize_t) (x - 0.5);
}


inline static ssize_t MagickRound(MagickRealType x)
{
  if (x >= 0.0)
    return (ssize_t) (x + 0.5);

  return (ssize_t) (x - 0.5);
}


inline static ssize_t MagickRound(MagickRealType x)
{
  if (x >= 0.0)
    return (ssize_t) (x + 0.5);

  return (ssize_t) (x - 0.5);
}


inline static ssize_t MagickRound(MagickRealType x)
{
  if (x >= 0.0)
    return (ssize_t) (x + 0.5);

  return (ssize_t) (x - 0.5);
}


inline static ssize_t MagickRound(MagickRealType x)
{
  if (x >= 0.0)
    return (ssize_t) (x + 0.5);

  return (ssize_t) (x - 0.5);
}


inline static ssize_t MagickRound(MagickRealType x)
{
  if (x >= 0.0)
    return (ssize_t) (x + 0.5);

  return (ssize_t) (x - 0.5);
}


inline static ssize_t MagickRound(MagickRealType x)
{
  if (x >= 0.0)
    return (ssize_t) (x + 0.5);

  return (ssize_t) (x - 0.5);
}


Image *CropImage(const Image *image, const RectangleInfo *geometry, ExceptionInfo *exception)
{
  CacheView *crop_view;
  CacheView *image_view;
  Image *crop_image;
  MagickBooleanType status;
  MagickOffsetType progress;
  RectangleInfo bounding_box;
  RectangleInfo page;
  ssize_t y;
  assert(image != ((const Image *) 0));
  assert(image->signature == 0xabacadabUL);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(TraceEvent, GetMagickModule(), "%s", image->filename);

  assert(geometry != ((const RectangleInfo *) 0));
  assert(exception != ((ExceptionInfo *) 0));
  assert(exception->signature == 0xabacadabUL);
  bounding_box = image->page;
  if ((bounding_box.width == 0) || (bounding_box.height == 0))
  {
    bounding_box.width = image->columns;
    bounding_box.height = image->rows;
  }

  page = *geometry;
  if (page.width == 0)
    page.width = bounding_box.width;

  if (page.height == 0)
    page.height = bounding_box.height;

  if (((((bounding_box.x - page.x) >= ((ssize_t) page.width)) || ((bounding_box.y - page.y) >= ((ssize_t) page.height))) || ((page.x - bounding_box.x) > ((ssize_t) image->columns))) || ((page.y - bounding_box.y) > ((ssize_t) image->rows)))
  {
    (void) ThrowMagickException(exception, GetMagickModule(), OptionWarning, "GeometryDoesNotContainImage", "`%s'", image->filename);
    crop_image = CloneImage(image, 1, 1, MagickTrue, exception);
    if (crop_image == ((Image *) 0))
      return (Image *) 0;

    crop_image->background_color.opacity = (Quantum) ((Quantum) QuantumRange);
    (void) SetImageBackgroundColor(crop_image);
    crop_image->page = bounding_box;
    crop_image->page.x = -1;
    crop_image->page.y = -1;
    if (crop_image->dispose == BackgroundDispose)
      crop_image->dispose = NoneDispose;

    return crop_image;
  }

  if ((page.x < 0) && (bounding_box.x >= 0))
  {
    page.width += page.x - bounding_box.x;
    page.x = 0;
  }
  else
  {
    page.width -= bounding_box.x - page.x;
    page.x -= bounding_box.x;
    if (page.x < 0)
      page.x = 0;

  }

  if ((page.y < 0) && (bounding_box.y >= 0))
  {
    page.height += page.y - bounding_box.y;
    page.y = 0;
  }
  else
  {
    page.height -= bounding_box.y - page.y;
    page.y -= bounding_box.y;
    if (page.y < 0)
      page.y = 0;

  }

  if (((size_t) (page.x + page.width)) > image->columns)
    page.width = image->columns - page.x;

  if ((geometry->width != 0) && (page.width > geometry->width))
    page.width = geometry->width;

  if (((size_t) (page.y + page.height)) > image->rows)
    page.height = image->rows - page.y;

  if ((geometry->height != 0) && (page.height > geometry->height))
    page.height = geometry->height;

  bounding_box.x += page.x;
  bounding_box.y += page.y;
  if ((page.width == 0) || (page.height == 0))
  {
    (void) ThrowMagickException(exception, GetMagickModule(), OptionWarning, "GeometryDoesNotContainImage", "`%s'", image->filename);
    return (Image *) 0;
  }

  crop_image = CloneImage(image, page.width, page.height, MagickTrue, exception);
  if (crop_image == ((Image *) 0))
    return (Image *) 0;

  crop_image->page.width = image->page.width;
  crop_image->page.height = image->page.height;
  if ((((ssize_t) (bounding_box.x + bounding_box.width)) > ((ssize_t) image->page.width)) || (((ssize_t) (bounding_box.y + bounding_box.height)) > ((ssize_t) image->page.height)))
  {
    crop_image->page.width = bounding_box.width;
    crop_image->page.height = bounding_box.height;
  }

  crop_image->page.x = bounding_box.x;
  crop_image->page.y = bounding_box.y;
  status = MagickTrue;
  progress = 0;
  image_view = AcquireCacheView(image);
  crop_view = AcquireCacheView(crop_image);
  #pragma omp parallel for schedule(dynamic,4) shared(progress,status) omp_throttle(1)
  for (y = 0; y < ((ssize_t) crop_image->rows); y++)
  {
    register const IndexPacket * restrict indexes;
    register const PixelPacket * restrict p;
    register IndexPacket * restrict crop_indexes;
    register PixelPacket * restrict q;
    if (status == MagickFalse)
      continue;

    p = GetCacheViewVirtualPixels(image_view, page.x, page.y + y, crop_image->columns, 1, exception);
    q = QueueCacheViewAuthenticPixels(crop_view, 0, y, crop_image->columns, 1, exception);
    if ((p == ((const PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
    {
      status = MagickFalse;
      continue;
    }

    indexes = GetCacheViewVirtualIndexQueue(image_view);
    crop_indexes = GetCacheViewAuthenticIndexQueue(crop_view);
    (void) CopyMagickMemory(q, p, ((size_t) crop_image->columns) * (sizeof(*p)));
    if ((indexes != ((IndexPacket *) 0)) && (crop_indexes != ((IndexPacket *) 0)))
      (void) CopyMagickMemory(crop_indexes, indexes, ((size_t) crop_image->columns) * (sizeof(*crop_indexes)));

    if (SyncCacheViewAuthenticPixels(crop_view, exception) == MagickFalse)
      status = MagickFalse;

    if (image->progress_monitor != ((MagickProgressMonitor) 0))
    {
      MagickBooleanType proceed;
      #pragma omp critical (MagickCore_CropImage)
      proceed = SetImageProgress(image, "Crop/Image", progress++, image->rows);
      if (proceed == MagickFalse)
        status = MagickFalse;

    }

  }

  crop_view = DestroyCacheView(crop_view);
  image_view = DestroyCacheView(image_view);
  crop_image->type = image->type;
  if (status == MagickFalse)
    crop_image = DestroyImage(crop_image);

  return crop_image;
}

