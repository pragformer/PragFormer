for (i = 0; i < POLYBENCH_LOOP_BOUND(1024, nj); i++)
  for (j = 0; j < POLYBENCH_LOOP_BOUND(1024, nl); j++)
{
  F[i][j] = 0;
  for (k = 0; k < POLYBENCH_LOOP_BOUND(1024, nm); ++k)
    F[i][j] += C[i][k] * D[k][j];

}

