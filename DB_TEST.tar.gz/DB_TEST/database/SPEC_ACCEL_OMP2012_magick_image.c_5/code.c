for (y = 0; y < ((ssize_t) image->rows); y++)
{
  IndexPacket index;
  register IndexPacket * restrict indexes;
  register PixelPacket * restrict q;
  register ssize_t x;
  if (status == MagickFalse)
    continue;

  q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    index = PushColormapIndex(image, (size_t) GetPixelIndex(indexes + x), &range_exception);
    if (image->matte == MagickFalse)
      SetPixelRGB(q, image->colormap + ((ssize_t) index));
    else
      SetPixelRGBO(q, image->colormap + ((ssize_t) index));

    q++;
  }

  if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
    status = MagickFalse;

}

inline static IndexPacket PushColormapIndex(Image *image, const size_t index, MagickBooleanType *range_exception)
{
  if (index < image->colors)
    return (IndexPacket) index;

  *range_exception = MagickTrue;
  return (IndexPacket) 0;
}

