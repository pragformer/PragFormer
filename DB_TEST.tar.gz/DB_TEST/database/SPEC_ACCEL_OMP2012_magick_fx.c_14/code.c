for (i = ((ssize_t) GetImageListLength(fx_info->images)) - 1; i >= 0; i--)
  fx_info->view[i] = DestroyCacheView(fx_info->view[i]);
