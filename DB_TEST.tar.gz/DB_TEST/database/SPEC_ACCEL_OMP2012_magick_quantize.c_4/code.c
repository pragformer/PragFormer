for (y = 0; y < ((ssize_t) image->rows); y++)
{
  register const PixelPacket * restrict p;
  register ssize_t x;
  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  if (p == ((const PixelPacket *) 0))
    break;

  if (cube_info->nodes > 266817)
  {
    PruneLevel(image, cube_info, cube_info->root);
    cube_info->depth--;
  }

  for (x = 0; x < ((ssize_t) image->columns); x += (ssize_t) count)
  {
    for (count = 1; (x + ((ssize_t) count)) < ((ssize_t) image->columns); count++)
      if (IsSameColor(image, p, p + count) == MagickFalse)
      break;


    AssociateAlphaPixel(cube_info, p, &pixel);
    index = 8 - 1;
    bisect = (((MagickRealType) QuantumRange) + 1.0) / 2.0;
    mid = midpoint;
    node_info = cube_info->root;
    for (level = 1; level <= 8; level++)
    {
      bisect *= 0.5;
      id = ColorToNodeId(cube_info, &pixel, index);
      mid.red += ((id & 1) != 0) ? (bisect) : (-bisect);
      mid.green += ((id & 2) != 0) ? (bisect) : (-bisect);
      mid.blue += ((id & 4) != 0) ? (bisect) : (-bisect);
      mid.opacity += ((id & 8) != 0) ? (bisect) : (-bisect);
      if (node_info->child[id] == ((NodeInfo *) 0))
      {
        node_info->child[id] = GetNodeInfo(cube_info, id, level, node_info);
        if (node_info->child[id] == ((NodeInfo *) 0))
          (void) ThrowMagickException(exception, GetMagickModule(), ResourceLimitError, "MemoryAllocationFailed", "`%s'", image->filename);

        if (level == 8)
          cube_info->colors++;

      }

      node_info = node_info->child[id];
      error.red = (((double) 1.0) / ((double) QuantumRange)) * (pixel.red - mid.red);
      error.green = (((double) 1.0) / ((double) QuantumRange)) * (pixel.green - mid.green);
      error.blue = (((double) 1.0) / ((double) QuantumRange)) * (pixel.blue - mid.blue);
      if (cube_info->associate_alpha != MagickFalse)
        error.opacity = (((double) 1.0) / ((double) QuantumRange)) * (pixel.opacity - mid.opacity);

      node_info->quantize_error += sqrt((double) (((((count * error.red) * error.red) + ((count * error.green) * error.green)) + ((count * error.blue) * error.blue)) + ((count * error.opacity) * error.opacity)));
      cube_info->root->quantize_error += node_info->quantize_error;
      index--;
    }

    node_info->number_unique += count;
    node_info->total_color.red += (count * (((double) 1.0) / ((double) QuantumRange))) * pixel.red;
    node_info->total_color.green += (count * (((double) 1.0) / ((double) QuantumRange))) * pixel.green;
    node_info->total_color.blue += (count * (((double) 1.0) / ((double) QuantumRange))) * pixel.blue;
    if (cube_info->associate_alpha != MagickFalse)
      node_info->total_color.opacity += (count * (((double) 1.0) / ((double) QuantumRange))) * pixel.opacity;

    p += count;
  }

  if (cube_info->colors > cube_info->maximum_colors)
  {
    PruneToCubeDepth(image, cube_info, cube_info->root);
    break;
  }

  proceed = SetImageProgress(image, "Classify/Image", (MagickOffsetType) y, image->rows);
  if (proceed == MagickFalse)
    break;

}

static void PruneLevel(const Image *image, CubeInfo *cube_info, const NodeInfo *node_info)
{
  register ssize_t i;
  size_t number_children;
  number_children = (cube_info->associate_alpha == MagickFalse) ? (8UL) : (16UL);
  for (i = 0; i < ((ssize_t) number_children); i++)
    if (node_info->child[i] != ((NodeInfo *) 0))
    PruneLevel(image, cube_info, node_info->child[i]);


  if (node_info->level == cube_info->depth)
    PruneChild(image, cube_info, node_info);

}


inline static MagickBooleanType IsSameColor(const Image *image, const PixelPacket *p, const PixelPacket *q)
{
  if (((GetPixelRed(p) != GetPixelRed(q)) || (GetPixelGreen(p) != GetPixelGreen(q))) || (GetPixelBlue(p) != GetPixelBlue(q)))
    return MagickFalse;

  if ((image->matte != MagickFalse) && (GetPixelOpacity(p) != GetPixelOpacity(q)))
    return MagickFalse;

  return MagickTrue;
}


inline static void AssociateAlphaPixel(const CubeInfo *cube_info, const PixelPacket *pixel, RealPixelPacket *alpha_pixel)
{
  MagickRealType alpha;
  if ((cube_info->associate_alpha == MagickFalse) || (pixel->opacity == ((Quantum) 0UL)))
  {
    alpha_pixel->red = (MagickRealType) GetPixelRed(pixel);
    alpha_pixel->green = (MagickRealType) GetPixelGreen(pixel);
    alpha_pixel->blue = (MagickRealType) GetPixelBlue(pixel);
    alpha_pixel->opacity = (MagickRealType) GetPixelOpacity(pixel);
    return;
  }

  alpha = (MagickRealType) ((((double) 1.0) / ((double) QuantumRange)) * (QuantumRange - GetPixelOpacity(pixel)));
  alpha_pixel->red = alpha * GetPixelRed(pixel);
  alpha_pixel->green = alpha * GetPixelGreen(pixel);
  alpha_pixel->blue = alpha * GetPixelBlue(pixel);
  alpha_pixel->opacity = (MagickRealType) GetPixelOpacity(pixel);
}


inline static size_t ColorToNodeId(const CubeInfo *cube_info, const RealPixelPacket *pixel, size_t index)
{
  size_t id;
  id = (size_t) ((((ScaleQuantumToChar(ClampToUnsignedQuantum(GetPixelRed(pixel))) >> index) & 0x01) | (((ScaleQuantumToChar(ClampToUnsignedQuantum(GetPixelGreen(pixel))) >> index) & 0x01) << 1)) | (((ScaleQuantumToChar(ClampToUnsignedQuantum(GetPixelBlue(pixel))) >> index) & 0x01) << 2));
  if (cube_info->associate_alpha != MagickFalse)
    id |= ((ScaleQuantumToChar(ClampToUnsignedQuantum(GetPixelOpacity(pixel))) >> index) & 0x1) << 3;

  return id;
}


static NodeInfo *GetNodeInfo(CubeInfo *cube_info, const size_t id, const size_t level, NodeInfo *parent)
{
  NodeInfo *node_info;
  if (cube_info->free_nodes == 0)
  {
    Nodes *nodes;
    nodes = (Nodes *) AcquireMagickMemory(sizeof(*nodes));
    if (nodes == ((Nodes *) 0))
      return (NodeInfo *) 0;

    nodes->nodes = (NodeInfo *) AcquireQuantumMemory(1920, sizeof(*nodes->nodes));
    if (nodes->nodes == ((NodeInfo *) 0))
      return (NodeInfo *) 0;

    nodes->next = cube_info->node_queue;
    cube_info->node_queue = nodes;
    cube_info->next_node = nodes->nodes;
    cube_info->free_nodes = 1920;
  }

  cube_info->nodes++;
  cube_info->free_nodes--;
  node_info = cube_info->next_node++;
  (void) ResetMagickMemory(node_info, 0, sizeof(*node_info));
  node_info->parent = parent;
  node_info->id = id;
  node_info->level = level;
  return node_info;
}


static void PruneToCubeDepth(const Image *image, CubeInfo *cube_info, const NodeInfo *node_info)
{
  register ssize_t i;
  size_t number_children;
  number_children = (cube_info->associate_alpha == MagickFalse) ? (8UL) : (16UL);
  for (i = 0; i < ((ssize_t) number_children); i++)
    if (node_info->child[i] != ((NodeInfo *) 0))
    PruneToCubeDepth(image, cube_info, node_info->child[i]);


  if (node_info->level > cube_info->depth)
    PruneChild(image, cube_info, node_info);

}


inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

