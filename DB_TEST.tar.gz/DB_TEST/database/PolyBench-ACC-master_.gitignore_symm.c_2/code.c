for (i = 0; i < nj; i++)
  for (j = 0; j < nj; j++)
  A[i][j] = (((double) i) * j) / ni;

