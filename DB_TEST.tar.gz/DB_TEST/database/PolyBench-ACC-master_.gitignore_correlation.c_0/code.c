for (j = 0; j < POLYBENCH_LOOP_BOUND(4000, m); j++)
{
  mean[j] = 0.0;
  for (i = 0; i < POLYBENCH_LOOP_BOUND(4000, n); i++)
    mean[j] += data[i][j];

  mean[j] /= float_n;
}
