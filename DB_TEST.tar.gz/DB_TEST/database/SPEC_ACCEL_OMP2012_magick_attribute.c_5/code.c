for (id = 0; id < ((ssize_t) number_threads); id++)
  current_depth[id] = 1;
