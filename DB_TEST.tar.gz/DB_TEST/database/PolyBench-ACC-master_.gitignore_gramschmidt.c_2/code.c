for (i = 0; i < nj; i++)
  for (j = 0; j < nj; j++)
  R[i][j] = (((double) i) * (j + 2)) / nj;

