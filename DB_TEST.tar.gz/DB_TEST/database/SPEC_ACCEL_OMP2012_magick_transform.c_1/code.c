for (y = 0; y < ((ssize_t) extent.y); y++)
{
  register const PixelPacket * restrict p;
  register IndexPacket * restrict chop_indexes;
  register IndexPacket * restrict indexes;
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  p = GetCacheViewVirtualPixels(image_view, 0, y, image->columns, 1, exception);
  q = QueueCacheViewAuthenticPixels(chop_view, 0, y, chop_image->columns, 1, exception);
  if ((p == ((const PixelPacket *) 0)) || (q == ((PixelPacket *) 0)))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewAuthenticIndexQueue(image_view);
  chop_indexes = GetCacheViewAuthenticIndexQueue(chop_view);
  for (x = 0; x < ((ssize_t) image->columns); x++)
  {
    if ((x < extent.x) || (x >= ((ssize_t) (extent.x + extent.width))))
    {
      *q = *p;
      if (indexes != ((IndexPacket *) 0))
      {
        if (chop_indexes != ((IndexPacket *) 0))
          *(chop_indexes++) = GetPixelIndex(indexes + x);

      }

      q++;
    }

    p++;
  }

  if (SyncCacheViewAuthenticPixels(chop_view, exception) == MagickFalse)
    status = MagickFalse;

  if (image->progress_monitor != ((MagickProgressMonitor) 0))
  {
    MagickBooleanType proceed;
    #pragma omp critical (MagickCore_ChopImage)
    proceed = SetImageProgress(image, "Chop/Image", progress++, image->rows);
    if (proceed == MagickFalse)
      status = MagickFalse;

  }

}

inline static MagickBooleanType SetImageProgress(const Image *image, const char *tag, const MagickOffsetType offset, const MagickSizeType extent)
{
  char message[4096];
  if (image->progress_monitor == ((MagickProgressMonitor) 0))
    return MagickTrue;

  (void) FormatLocaleString(message, 4096, "%s/%s", tag, image->filename);
  return image->progress_monitor(message, offset, extent, image->client_data);
}

