for (p = primitive_info; p->primitive != UndefinedPrimitive; p += p->coordinates)
{
  stroke_polygon = TraceStrokePolygon(draw_info, p);
  status = DrawPolygonPrimitive(image, clone_info, stroke_polygon);
  stroke_polygon = (PrimitiveInfo *) RelinquishMagickMemory(stroke_polygon);
  q = (p + p->coordinates) - 1;
  closed_path = ((q->point.x == p->point.x) && (q->point.y == p->point.y)) ? (MagickTrue) : (MagickFalse);
  if ((draw_info->linecap == RoundCap) && (closed_path == MagickFalse))
  {
    DrawRoundLinecap(image, draw_info, p);
    DrawRoundLinecap(image, draw_info, q);
  }

}

static PrimitiveInfo *TraceStrokePolygon(const DrawInfo *draw_info, const PrimitiveInfo *primitive_info)
{
  typedef struct _LineSegment
  {
    double p;
    double q;
  } LineSegment;
  LineSegment dx;
  LineSegment dy;
  LineSegment inverse_slope;
  LineSegment slope;
  LineSegment theta;
  MagickBooleanType closed_path;
  MagickRealType delta_theta;
  MagickRealType dot_product;
  MagickRealType mid;
  MagickRealType miterlimit;
  PointInfo box_p[5];
  PointInfo box_q[5];
  PointInfo center;
  PointInfo offset;
  PointInfo *path_p;
  PointInfo *path_q;
  PrimitiveInfo *polygon_primitive;
  PrimitiveInfo *stroke_polygon;
  register ssize_t i;
  size_t arc_segments;
  size_t max_strokes;
  size_t number_vertices;
  ssize_t j;
  ssize_t n;
  ssize_t p;
  ssize_t q;
  number_vertices = primitive_info->coordinates;
  max_strokes = ((2 * number_vertices) + (6 * 200)) + 360;
  path_p = (PointInfo *) AcquireQuantumMemory((size_t) max_strokes, sizeof(*path_p));
  path_q = (PointInfo *) AcquireQuantumMemory((size_t) max_strokes, sizeof(*path_q));
  polygon_primitive = (PrimitiveInfo *) AcquireQuantumMemory(((size_t) number_vertices) + 2UL, sizeof(*polygon_primitive));
  if (((path_p == ((PointInfo *) 0)) || (path_q == ((PointInfo *) 0))) || (polygon_primitive == ((PrimitiveInfo *) 0)))
    return (PrimitiveInfo *) 0;

  (void) CopyMagickMemory(polygon_primitive, primitive_info, ((size_t) number_vertices) * (sizeof(*polygon_primitive)));
  closed_path = ((primitive_info[number_vertices - 1].point.x == primitive_info[0].point.x) && (primitive_info[number_vertices - 1].point.y == primitive_info[0].point.y)) ? (MagickTrue) : (MagickFalse);
  if ((draw_info->linejoin == RoundJoin) || ((draw_info->linejoin == MiterJoin) && (closed_path != MagickFalse)))
  {
    polygon_primitive[number_vertices] = primitive_info[1];
    number_vertices++;
  }

  polygon_primitive[number_vertices].primitive = UndefinedPrimitive;
  dx.p = 0.0;
  dy.p = 0.0;
  for (n = 1; n < ((ssize_t) number_vertices); n++)
  {
    dx.p = polygon_primitive[n].point.x - polygon_primitive[0].point.x;
    dy.p = polygon_primitive[n].point.y - polygon_primitive[0].point.y;
    if ((fabs(dx.p) >= MagickEpsilon) || (fabs(dy.p) >= MagickEpsilon))
      break;

  }

  if (n == ((ssize_t) number_vertices))
    n = ((ssize_t) number_vertices) - 1L;

  slope.p = 0.0;
  inverse_slope.p = 0.0;
  if (fabs(dx.p) <= MagickEpsilon)
  {
    if (dx.p >= 0.0)
      slope.p = (dy.p < 0.0) ? ((-1.0) / MagickEpsilon) : (1.0 / MagickEpsilon);
    else
      slope.p = (dy.p < 0.0) ? (1.0 / MagickEpsilon) : ((-1.0) / MagickEpsilon);

  }
  else
    if (fabs(dy.p) <= MagickEpsilon)
  {
    if (dy.p >= 0.0)
      inverse_slope.p = (dx.p < 0.0) ? ((-1.0) / MagickEpsilon) : (1.0 / MagickEpsilon);
    else
      inverse_slope.p = (dx.p < 0.0) ? (1.0 / MagickEpsilon) : ((-1.0) / MagickEpsilon);

  }
  else
  {
    slope.p = dy.p / dx.p;
    inverse_slope.p = (-1.0) / slope.p;
  }


  mid = (ExpandAffine(&draw_info->affine) * draw_info->stroke_width) / 2.0;
  miterlimit = (MagickRealType) (((draw_info->miterlimit * draw_info->miterlimit) * mid) * mid);
  if ((draw_info->linecap == SquareCap) && (closed_path == MagickFalse))
    TraceSquareLinecap(polygon_primitive, number_vertices, mid);

  offset.x = sqrt((double) ((mid * mid) / ((inverse_slope.p * inverse_slope.p) + 1.0)));
  offset.y = (double) (offset.x * inverse_slope.p);
  if (((dy.p * offset.x) - (dx.p * offset.y)) > 0.0)
  {
    box_p[0].x = polygon_primitive[0].point.x - offset.x;
    box_p[0].y = polygon_primitive[0].point.y - (offset.x * inverse_slope.p);
    box_p[1].x = polygon_primitive[n].point.x - offset.x;
    box_p[1].y = polygon_primitive[n].point.y - (offset.x * inverse_slope.p);
    box_q[0].x = polygon_primitive[0].point.x + offset.x;
    box_q[0].y = polygon_primitive[0].point.y + (offset.x * inverse_slope.p);
    box_q[1].x = polygon_primitive[n].point.x + offset.x;
    box_q[1].y = polygon_primitive[n].point.y + (offset.x * inverse_slope.p);
  }
  else
  {
    box_p[0].x = polygon_primitive[0].point.x + offset.x;
    box_p[0].y = polygon_primitive[0].point.y + offset.y;
    box_p[1].x = polygon_primitive[n].point.x + offset.x;
    box_p[1].y = polygon_primitive[n].point.y + offset.y;
    box_q[0].x = polygon_primitive[0].point.x - offset.x;
    box_q[0].y = polygon_primitive[0].point.y - offset.y;
    box_q[1].x = polygon_primitive[n].point.x - offset.x;
    box_q[1].y = polygon_primitive[n].point.y - offset.y;
  }

  p = 0;
  q = 0;
  path_q[p++] = box_q[0];
  path_p[q++] = box_p[0];
  for (i = ((ssize_t) n) + 1; i < ((ssize_t) number_vertices); i++)
  {
    dx.q = polygon_primitive[i].point.x - polygon_primitive[n].point.x;
    dy.q = polygon_primitive[i].point.y - polygon_primitive[n].point.y;
    dot_product = (dx.q * dx.q) + (dy.q * dy.q);
    if (dot_product < 0.25)
      continue;

    slope.q = 0.0;
    inverse_slope.q = 0.0;
    if (fabs(dx.q) < MagickEpsilon)
    {
      if (dx.q >= 0.0)
        slope.q = (dy.q < 0.0) ? ((-1.0) / MagickEpsilon) : (1.0 / MagickEpsilon);
      else
        slope.q = (dy.q < 0.0) ? (1.0 / MagickEpsilon) : ((-1.0) / MagickEpsilon);

    }
    else
      if (fabs(dy.q) <= MagickEpsilon)
    {
      if (dy.q >= 0.0)
        inverse_slope.q = (dx.q < 0.0) ? ((-1.0) / MagickEpsilon) : (1.0 / MagickEpsilon);
      else
        inverse_slope.q = (dx.q < 0.0) ? (1.0 / MagickEpsilon) : ((-1.0) / MagickEpsilon);

    }
    else
    {
      slope.q = dy.q / dx.q;
      inverse_slope.q = (-1.0) / slope.q;
    }


    offset.x = sqrt((double) ((mid * mid) / ((inverse_slope.q * inverse_slope.q) + 1.0)));
    offset.y = (double) (offset.x * inverse_slope.q);
    dot_product = (dy.q * offset.x) - (dx.q * offset.y);
    if (dot_product > 0.0)
    {
      box_p[2].x = polygon_primitive[n].point.x - offset.x;
      box_p[2].y = polygon_primitive[n].point.y - offset.y;
      box_p[3].x = polygon_primitive[i].point.x - offset.x;
      box_p[3].y = polygon_primitive[i].point.y - offset.y;
      box_q[2].x = polygon_primitive[n].point.x + offset.x;
      box_q[2].y = polygon_primitive[n].point.y + offset.y;
      box_q[3].x = polygon_primitive[i].point.x + offset.x;
      box_q[3].y = polygon_primitive[i].point.y + offset.y;
    }
    else
    {
      box_p[2].x = polygon_primitive[n].point.x + offset.x;
      box_p[2].y = polygon_primitive[n].point.y + offset.y;
      box_p[3].x = polygon_primitive[i].point.x + offset.x;
      box_p[3].y = polygon_primitive[i].point.y + offset.y;
      box_q[2].x = polygon_primitive[n].point.x - offset.x;
      box_q[2].y = polygon_primitive[n].point.y - offset.y;
      box_q[3].x = polygon_primitive[i].point.x - offset.x;
      box_q[3].y = polygon_primitive[i].point.y - offset.y;
    }

    if (fabs((double) (slope.p - slope.q)) <= MagickEpsilon)
    {
      box_p[4] = box_p[1];
      box_q[4] = box_q[1];
    }
    else
    {
      box_p[4].x = (double) (((((slope.p * box_p[0].x) - box_p[0].y) - (slope.q * box_p[3].x)) + box_p[3].y) / (slope.p - slope.q));
      box_p[4].y = (double) ((slope.p * (box_p[4].x - box_p[0].x)) + box_p[0].y);
      box_q[4].x = (double) (((((slope.p * box_q[0].x) - box_q[0].y) - (slope.q * box_q[3].x)) + box_q[3].y) / (slope.p - slope.q));
      box_q[4].y = (double) ((slope.p * (box_q[4].x - box_q[0].x)) + box_q[0].y);
    }

    if (q >= ((ssize_t) ((max_strokes - (6 * 200)) - 360)))
    {
      max_strokes += (6 * 200) + 360;
      path_p = (PointInfo *) ResizeQuantumMemory(path_p, (size_t) max_strokes, sizeof(*path_p));
      path_q = (PointInfo *) ResizeQuantumMemory(path_q, (size_t) max_strokes, sizeof(*path_q));
      if ((path_p == ((PointInfo *) 0)) || (path_q == ((PointInfo *) 0)))
      {
        polygon_primitive = (PrimitiveInfo *) RelinquishMagickMemory(polygon_primitive);
        return (PrimitiveInfo *) 0;
      }

    }

    dot_product = (dx.q * dy.p) - (dx.p * dy.q);
    if (dot_product <= 0.0)
      switch (draw_info->linejoin)
    {
      case BevelJoin:
      {
        path_q[q++] = box_q[1];
        path_q[q++] = box_q[2];
        dot_product = ((box_q[4].x - box_p[4].x) * (box_q[4].x - box_p[4].x)) + ((box_q[4].y - box_p[4].y) * (box_q[4].y - box_p[4].y));
        if (dot_product <= miterlimit)
          path_p[p++] = box_p[4];
        else
        {
          path_p[p++] = box_p[1];
          path_p[p++] = box_p[2];
        }

        break;
      }

      case MiterJoin:
      {
        dot_product = ((box_q[4].x - box_p[4].x) * (box_q[4].x - box_p[4].x)) + ((box_q[4].y - box_p[4].y) * (box_q[4].y - box_p[4].y));
        if (dot_product <= miterlimit)
        {
          path_q[q++] = box_q[4];
          path_p[p++] = box_p[4];
        }
        else
        {
          path_q[q++] = box_q[1];
          path_q[q++] = box_q[2];
          path_p[p++] = box_p[1];
          path_p[p++] = box_p[2];
        }

        break;
      }

      case RoundJoin:
      {
        dot_product = ((box_q[4].x - box_p[4].x) * (box_q[4].x - box_p[4].x)) + ((box_q[4].y - box_p[4].y) * (box_q[4].y - box_p[4].y));
        if (dot_product <= miterlimit)
          path_p[p++] = box_p[4];
        else
        {
          path_p[p++] = box_p[1];
          path_p[p++] = box_p[2];
        }

        center = polygon_primitive[n].point;
        theta.p = atan2(box_q[1].y - center.y, box_q[1].x - center.x);
        theta.q = atan2(box_q[2].y - center.y, box_q[2].x - center.x);
        if (theta.q < theta.p)
          theta.q += (MagickRealType) (2.0 * 3.14159265358979323846264338327950288419716939937510L);

        arc_segments = (size_t) ceil((double) ((theta.q - theta.p) / (2.0 * sqrt((double) (1.0 / mid)))));
        path_q[q].x = box_q[1].x;
        path_q[q].y = box_q[1].y;
        q++;
        for (j = 1; j < ((ssize_t) arc_segments); j++)
        {
          delta_theta = (MagickRealType) ((j * (theta.q - theta.p)) / arc_segments);
          path_q[q].x = (double) (center.x + (mid * cos(fmod((double) (theta.p + delta_theta), DegreesToRadians(360.0)))));
          path_q[q].y = (double) (center.y + (mid * sin(fmod((double) (theta.p + delta_theta), DegreesToRadians(360.0)))));
          q++;
        }

        path_q[q++] = box_q[2];
        break;
      }

      default:
        break;

    }

    else
      switch (draw_info->linejoin)
    {
      case BevelJoin:
      {
        path_p[p++] = box_p[1];
        path_p[p++] = box_p[2];
        dot_product = ((box_q[4].x - box_p[4].x) * (box_q[4].x - box_p[4].x)) + ((box_q[4].y - box_p[4].y) * (box_q[4].y - box_p[4].y));
        if (dot_product <= miterlimit)
          path_q[q++] = box_q[4];
        else
        {
          path_q[q++] = box_q[1];
          path_q[q++] = box_q[2];
        }

        break;
      }

      case MiterJoin:
      {
        dot_product = ((box_q[4].x - box_p[4].x) * (box_q[4].x - box_p[4].x)) + ((box_q[4].y - box_p[4].y) * (box_q[4].y - box_p[4].y));
        if (dot_product <= miterlimit)
        {
          path_q[q++] = box_q[4];
          path_p[p++] = box_p[4];
        }
        else
        {
          path_q[q++] = box_q[1];
          path_q[q++] = box_q[2];
          path_p[p++] = box_p[1];
          path_p[p++] = box_p[2];
        }

        break;
      }

      case RoundJoin:
      {
        dot_product = ((box_q[4].x - box_p[4].x) * (box_q[4].x - box_p[4].x)) + ((box_q[4].y - box_p[4].y) * (box_q[4].y - box_p[4].y));
        if (dot_product <= miterlimit)
          path_q[q++] = box_q[4];
        else
        {
          path_q[q++] = box_q[1];
          path_q[q++] = box_q[2];
        }

        center = polygon_primitive[n].point;
        theta.p = atan2(box_p[1].y - center.y, box_p[1].x - center.x);
        theta.q = atan2(box_p[2].y - center.y, box_p[2].x - center.x);
        if (theta.p < theta.q)
          theta.p += (MagickRealType) (2.0 * 3.14159265358979323846264338327950288419716939937510L);

        arc_segments = (size_t) ceil((double) ((theta.p - theta.q) / (2.0 * sqrt((double) (1.0 / mid)))));
        path_p[p++] = box_p[1];
        for (j = 1; j < ((ssize_t) arc_segments); j++)
        {
          delta_theta = (MagickRealType) ((j * (theta.q - theta.p)) / arc_segments);
          path_p[p].x = (double) (center.x + (mid * cos(fmod((double) (theta.p + delta_theta), DegreesToRadians(360.0)))));
          path_p[p].y = (double) (center.y + (mid * sin(fmod((double) (theta.p + delta_theta), DegreesToRadians(360.0)))));
          p++;
        }

        path_p[p++] = box_p[2];
        break;
      }

      default:
        break;

    }


    slope.p = slope.q;
    inverse_slope.p = inverse_slope.q;
    box_p[0] = box_p[2];
    box_p[1] = box_p[3];
    box_q[0] = box_q[2];
    box_q[1] = box_q[3];
    dx.p = dx.q;
    dy.p = dy.q;
    n = i;
  }

  path_p[p++] = box_p[1];
  path_q[q++] = box_q[1];
  stroke_polygon = (PrimitiveInfo *) AcquireQuantumMemory((size_t) (((p + q) + (2UL * closed_path)) + 2UL), sizeof(*stroke_polygon));
  if (stroke_polygon != ((PrimitiveInfo *) 0))
  {
    for (i = 0; i < ((ssize_t) p); i++)
    {
      stroke_polygon[i] = polygon_primitive[0];
      stroke_polygon[i].point = path_p[i];
    }

    if (closed_path != MagickFalse)
    {
      stroke_polygon[i] = polygon_primitive[0];
      stroke_polygon[i].point = stroke_polygon[0].point;
      i++;
    }

    for (; i < ((ssize_t) ((p + q) + closed_path)); i++)
    {
      stroke_polygon[i] = polygon_primitive[0];
      stroke_polygon[i].point = path_q[((p + q) + closed_path) - (i + 1)];
    }

    if (closed_path != MagickFalse)
    {
      stroke_polygon[i] = polygon_primitive[0];
      stroke_polygon[i].point = stroke_polygon[p + closed_path].point;
      i++;
    }

    stroke_polygon[i] = polygon_primitive[0];
    stroke_polygon[i].point = stroke_polygon[0].point;
    i++;
    stroke_polygon[i].primitive = UndefinedPrimitive;
    stroke_polygon[0].coordinates = (size_t) (((p + q) + (2 * closed_path)) + 1);
  }

  path_p = (PointInfo *) RelinquishMagickMemory(path_p);
  path_q = (PointInfo *) RelinquishMagickMemory(path_q);
  polygon_primitive = (PrimitiveInfo *) RelinquishMagickMemory(polygon_primitive);
  return stroke_polygon;
}


static MagickBooleanType DrawPolygonPrimitive(Image *image, const DrawInfo *draw_info, const PrimitiveInfo *primitive_info)
{
  CacheView *image_view;
  ExceptionInfo *exception;
  MagickBooleanType fill;
  MagickBooleanType status;
  MagickRealType mid;
  PolygonInfo ** restrict polygon_info;
  register EdgeInfo *p;
  register ssize_t i;
  SegmentInfo bounds;
  ssize_t start;
  ssize_t stop;
  ssize_t y;
  assert(image != ((Image *) 0));
  assert(image->signature == 0xabacadabUL);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(TraceEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 3837, "%s", image->filename);

  assert(draw_info != ((DrawInfo *) 0));
  assert(draw_info->signature == 0xabacadabUL);
  assert(primitive_info != ((PrimitiveInfo *) 0));
  if (primitive_info->coordinates == 0)
    return MagickTrue;

  polygon_info = AcquirePolygonThreadSet(draw_info, primitive_info);
  if (polygon_info == ((PolygonInfo **) 0))
    return MagickFalse;

  if (0)
    DrawBoundingRectangles(image, draw_info, polygon_info[0]);

  if (image->debug != MagickFalse)
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 3849, "    begin draw-polygon");

  fill = ((primitive_info->method == FillToBorderMethod) || (primitive_info->method == FloodfillMethod)) ? (MagickTrue) : (MagickFalse);
  mid = (ExpandAffine(&draw_info->affine) * draw_info->stroke_width) / 2.0;
  bounds = polygon_info[0]->edges[0].bounds;
  for (i = 1; i < ((ssize_t) polygon_info[0]->number_edges); i++)
  {
    p = polygon_info[0]->edges + i;
    if (p->bounds.x1 < bounds.x1)
      bounds.x1 = p->bounds.x1;

    if (p->bounds.y1 < bounds.y1)
      bounds.y1 = p->bounds.y1;

    if (p->bounds.x2 > bounds.x2)
      bounds.x2 = p->bounds.x2;

    if (p->bounds.y2 > bounds.y2)
      bounds.y2 = p->bounds.y2;

  }

  bounds.x1 -= mid + 1.0;
  bounds.x1 = (bounds.x1 < 0.0) ? (0.0) : ((((size_t) ceil(bounds.x1 - 0.5)) >= image->columns) ? (((double) image->columns) - 1.0) : (bounds.x1));
  bounds.y1 -= mid + 1.0;
  bounds.y1 = (bounds.y1 < 0.0) ? (0.0) : ((((size_t) ceil(bounds.y1 - 0.5)) >= image->rows) ? (((double) image->rows) - 1.0) : (bounds.y1));
  bounds.x2 += mid + 1.0;
  bounds.x2 = (bounds.x2 < 0.0) ? (0.0) : ((((size_t) floor(bounds.x2 + 0.5)) >= image->columns) ? (((double) image->columns) - 1.0) : (bounds.x2));
  bounds.y2 += mid + 1.0;
  bounds.y2 = (bounds.y2 < 0.0) ? (0.0) : ((((size_t) floor(bounds.y2 + 0.5)) >= image->rows) ? (((double) image->rows) - 1.0) : (bounds.y2));
  status = MagickTrue;
  exception = &image->exception;
  start = (ssize_t) ceil(bounds.x1 - 0.5);
  stop = (ssize_t) floor(bounds.x2 + 0.5);
  image_view = AcquireCacheView(image);
  if (primitive_info->coordinates == 1)
  {
    #pragma omp parallel for schedule(dynamic,4) shared(status)
    for (y = (ssize_t) ceil(bounds.y1 - 0.5); y <= ((ssize_t) floor(bounds.y2 + 0.5)); y++)
    {
      MagickBooleanType sync;
      register ssize_t x;
      register PixelPacket * restrict q;
      if (status == MagickFalse)
        continue;

      x = start;
      q = GetCacheViewAuthenticPixels(image_view, x, y, (size_t) ((stop - x) + 1), 1, exception);
      if (q == ((PixelPacket *) 0))
      {
        status = MagickFalse;
        continue;
      }

      for (; x <= stop; x++)
      {
        if ((x == ((ssize_t) ceil(primitive_info->point.x - 0.5))) && (y == ((ssize_t) ceil(primitive_info->point.y - 0.5))))
          (void) GetStrokeColor(draw_info, x, y, q);

        q++;
      }

      sync = SyncCacheViewAuthenticPixels(image_view, exception);
      if (sync == MagickFalse)
        status = MagickFalse;

    }

    image_view = DestroyCacheView(image_view);
    polygon_info = DestroyPolygonThreadSet(polygon_info);
    if (image->debug != MagickFalse)
      (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 3926, "    end draw-polygon");

    return status;
  }

  if (image->matte == MagickFalse)
    (void) SetImageAlphaChannel(image, OpaqueAlphaChannel);

  #pragma omp parallel for schedule(dynamic,4) shared(status)
  for (y = (ssize_t) ceil(bounds.y1 - 0.5); y <= ((ssize_t) floor(bounds.y2 + 0.5)); y++)
  {
    const int id = GetOpenMPThreadId();
    MagickRealType fill_opacity;
    MagickRealType stroke_opacity;
    PixelPacket fill_color;
    PixelPacket stroke_color;
    register PixelPacket * restrict q;
    register ssize_t x;
    if (status == MagickFalse)
      continue;

    q = GetCacheViewAuthenticPixels(image_view, start, y, (size_t) ((stop - start) + 1), 1, exception);
    if (q == ((PixelPacket *) 0))
    {
      status = MagickFalse;
      continue;
    }

    for (x = start; x <= stop; x++)
    {
      fill_opacity = GetOpacityPixel(polygon_info[id], mid, fill, draw_info->fill_rule, (double) x, (double) y, &stroke_opacity);
      if (draw_info->stroke_antialias == MagickFalse)
      {
        fill_opacity = (fill_opacity > 0.25) ? (1.0) : (0.0);
        stroke_opacity = (stroke_opacity > 0.25) ? (1.0) : (0.0);
      }

      (void) GetFillColor(draw_info, x, y, &fill_color);
      fill_opacity = (MagickRealType) (QuantumRange - (fill_opacity * (QuantumRange - fill_color.opacity)));
      MagickCompositeOver(&fill_color, fill_opacity, q, (MagickRealType) q->opacity, q);
      (void) GetStrokeColor(draw_info, x, y, &stroke_color);
      stroke_opacity = (MagickRealType) (QuantumRange - (stroke_opacity * (QuantumRange - stroke_color.opacity)));
      MagickCompositeOver(&stroke_color, stroke_opacity, q, (MagickRealType) q->opacity, q);
      q++;
    }

    if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
      status = MagickFalse;

  }

  image_view = DestroyCacheView(image_view);
  polygon_info = DestroyPolygonThreadSet(polygon_info);
  if (image->debug != MagickFalse)
    (void) LogMagickEvent(DrawEvent, "/home/reemh/CLPP/github-clone-all/repos_2022/SPEC_ACCEL/OMP2012/367.imagick/src/magick_draw.c", __func__, (unsigned long) 3996, "    end draw-polygon");

  return status;
}


static void DrawRoundLinecap(Image *image, const DrawInfo *draw_info, const PrimitiveInfo *primitive_info)
{
  PrimitiveInfo linecap[5];
  register ssize_t i;
  for (i = 0; i < 4; i++)
    linecap[i] = *primitive_info;

  linecap[0].coordinates = 4;
  linecap[1].point.x += (double) (10.0 * MagickEpsilon);
  linecap[2].point.x += (double) (10.0 * MagickEpsilon);
  linecap[2].point.y += (double) (10.0 * MagickEpsilon);
  linecap[3].point.y += (double) (10.0 * MagickEpsilon);
  linecap[4].primitive = UndefinedPrimitive;
  (void) DrawPolygonPrimitive(image, draw_info, linecap);
}


static void DrawRoundLinecap(Image *image, const DrawInfo *draw_info, const PrimitiveInfo *primitive_info)
{
  PrimitiveInfo linecap[5];
  register ssize_t i;
  for (i = 0; i < 4; i++)
    linecap[i] = *primitive_info;

  linecap[0].coordinates = 4;
  linecap[1].point.x += (double) (10.0 * MagickEpsilon);
  linecap[2].point.x += (double) (10.0 * MagickEpsilon);
  linecap[2].point.y += (double) (10.0 * MagickEpsilon);
  linecap[3].point.y += (double) (10.0 * MagickEpsilon);
  linecap[4].primitive = UndefinedPrimitive;
  (void) DrawPolygonPrimitive(image, draw_info, linecap);
}

