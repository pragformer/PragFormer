for (i = 0; i < nk; i++)
  for (j = 0; j < nj; j++)
  B[i][j] = (((double) i) * j) / ni;

