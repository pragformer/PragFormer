for (i = 0; i < 4; i++)
{
  register ssize_t x;
  for (x = 0; x < ((ssize_t) number_grays); x++)
  {
    variance.direction[i].red += density_xy[x].direction[i].red;
    variance.direction[i].green += density_xy[x].direction[i].green;
    variance.direction[i].blue += density_xy[x].direction[i].blue;
    if (image->colorspace == CMYKColorspace)
      variance.direction[i].index += density_xy[x].direction[i].index;

    if (image->matte != MagickFalse)
      variance.direction[i].opacity += density_xy[x].direction[i].opacity;

    sum_squares.direction[i].red += density_xy[x].direction[i].red * density_xy[x].direction[i].red;
    sum_squares.direction[i].green += density_xy[x].direction[i].green * density_xy[x].direction[i].green;
    sum_squares.direction[i].blue += density_xy[x].direction[i].blue * density_xy[x].direction[i].blue;
    if (image->colorspace == CMYKColorspace)
      sum_squares.direction[i].index += density_xy[x].direction[i].index * density_xy[x].direction[i].index;

    if (image->matte != MagickFalse)
      sum_squares.direction[i].opacity += density_xy[x].direction[i].opacity * density_xy[x].direction[i].opacity;

    channel_features[RedChannel].difference_entropy[i] -= density_xy[x].direction[i].red * log10(density_xy[x].direction[i].red + MagickEpsilon);
    channel_features[GreenChannel].difference_entropy[i] -= density_xy[x].direction[i].green * log10(density_xy[x].direction[i].green + MagickEpsilon);
    channel_features[BlueChannel].difference_entropy[i] -= density_xy[x].direction[i].blue * log10(density_xy[x].direction[i].blue + MagickEpsilon);
    if (image->colorspace == CMYKColorspace)
      channel_features[IndexChannel].difference_entropy[i] -= density_xy[x].direction[i].index * log10(density_xy[x].direction[i].index + MagickEpsilon);

    if (image->matte != MagickFalse)
      channel_features[OpacityChannel].difference_entropy[i] -= density_xy[x].direction[i].opacity * log10(density_xy[x].direction[i].opacity + MagickEpsilon);

    entropy_x.direction[i].red -= density_x[x].direction[i].red * log10(density_x[x].direction[i].red + MagickEpsilon);
    entropy_x.direction[i].green -= density_x[x].direction[i].green * log10(density_x[x].direction[i].green + MagickEpsilon);
    entropy_x.direction[i].blue -= density_x[x].direction[i].blue * log10(density_x[x].direction[i].blue + MagickEpsilon);
    if (image->colorspace == CMYKColorspace)
      entropy_x.direction[i].index -= density_x[x].direction[i].index * log10(density_x[x].direction[i].index + MagickEpsilon);

    if (image->matte != MagickFalse)
      entropy_x.direction[i].opacity -= density_x[x].direction[i].opacity * log10(density_x[x].direction[i].opacity + MagickEpsilon);

    entropy_y.direction[i].red -= density_y[x].direction[i].red * log10(density_y[x].direction[i].red + MagickEpsilon);
    entropy_y.direction[i].green -= density_y[x].direction[i].green * log10(density_y[x].direction[i].green + MagickEpsilon);
    entropy_y.direction[i].blue -= density_y[x].direction[i].blue * log10(density_y[x].direction[i].blue + MagickEpsilon);
    if (image->colorspace == CMYKColorspace)
      entropy_y.direction[i].index -= density_y[x].direction[i].index * log10(density_y[x].direction[i].index + MagickEpsilon);

    if (image->matte != MagickFalse)
      entropy_y.direction[i].opacity -= density_y[x].direction[i].opacity * log10(density_y[x].direction[i].opacity + MagickEpsilon);

  }

  channel_features[RedChannel].difference_variance[i] = (((((double) number_grays) * number_grays) * sum_squares.direction[i].red) - (variance.direction[i].red * variance.direction[i].red)) / (((((double) number_grays) * number_grays) * number_grays) * number_grays);
  channel_features[GreenChannel].difference_variance[i] = (((((double) number_grays) * number_grays) * sum_squares.direction[i].green) - (variance.direction[i].green * variance.direction[i].green)) / (((((double) number_grays) * number_grays) * number_grays) * number_grays);
  channel_features[BlueChannel].difference_variance[i] = (((((double) number_grays) * number_grays) * sum_squares.direction[i].blue) - (variance.direction[i].blue * variance.direction[i].blue)) / (((((double) number_grays) * number_grays) * number_grays) * number_grays);
  if (image->matte != MagickFalse)
    channel_features[OpacityChannel].difference_variance[i] = (((((double) number_grays) * number_grays) * sum_squares.direction[i].opacity) - (variance.direction[i].opacity * variance.direction[i].opacity)) / (((((double) number_grays) * number_grays) * number_grays) * number_grays);

  if (image->colorspace == CMYKColorspace)
    channel_features[IndexChannel].difference_variance[i] = (((((double) number_grays) * number_grays) * sum_squares.direction[i].index) - (variance.direction[i].index * variance.direction[i].index)) / (((((double) number_grays) * number_grays) * number_grays) * number_grays);

  channel_features[RedChannel].measure_of_correlation_1[i] = (entropy_xy.direction[i].red - entropy_xy1.direction[i].red) / ((entropy_x.direction[i].red > entropy_y.direction[i].red) ? (entropy_x.direction[i].red) : (entropy_y.direction[i].red));
  channel_features[GreenChannel].measure_of_correlation_1[i] = (entropy_xy.direction[i].green - entropy_xy1.direction[i].green) / ((entropy_x.direction[i].green > entropy_y.direction[i].green) ? (entropy_x.direction[i].green) : (entropy_y.direction[i].green));
  channel_features[BlueChannel].measure_of_correlation_1[i] = (entropy_xy.direction[i].blue - entropy_xy1.direction[i].blue) / ((entropy_x.direction[i].blue > entropy_y.direction[i].blue) ? (entropy_x.direction[i].blue) : (entropy_y.direction[i].blue));
  if (image->colorspace == CMYKColorspace)
    channel_features[IndexChannel].measure_of_correlation_1[i] = (entropy_xy.direction[i].index - entropy_xy1.direction[i].index) / ((entropy_x.direction[i].index > entropy_y.direction[i].index) ? (entropy_x.direction[i].index) : (entropy_y.direction[i].index));

  if (image->matte != MagickFalse)
    channel_features[OpacityChannel].measure_of_correlation_1[i] = (entropy_xy.direction[i].opacity - entropy_xy1.direction[i].opacity) / ((entropy_x.direction[i].opacity > entropy_y.direction[i].opacity) ? (entropy_x.direction[i].opacity) : (entropy_y.direction[i].opacity));

  channel_features[RedChannel].measure_of_correlation_2[i] = sqrt(fabs(1.0 - exp((-2.0) * (entropy_xy2.direction[i].red - entropy_xy.direction[i].red))));
  channel_features[GreenChannel].measure_of_correlation_2[i] = sqrt(fabs(1.0 - exp((-2.0) * (entropy_xy2.direction[i].green - entropy_xy.direction[i].green))));
  channel_features[BlueChannel].measure_of_correlation_2[i] = sqrt(fabs(1.0 - exp((-2.0) * (entropy_xy2.direction[i].blue - entropy_xy.direction[i].blue))));
  if (image->colorspace == CMYKColorspace)
    channel_features[IndexChannel].measure_of_correlation_2[i] = sqrt(fabs(1.0 - exp((-2.0) * (entropy_xy2.direction[i].index - entropy_xy.direction[i].index))));

  if (image->matte != MagickFalse)
    channel_features[OpacityChannel].measure_of_correlation_2[i] = sqrt(fabs(1.0 - exp((-2.0) * (entropy_xy2.direction[i].opacity - entropy_xy.direction[i].opacity))));

}
