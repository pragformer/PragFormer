for (y = 0; y < ((ssize_t) radon_info->height); y++)
{
  for (x = 0; x < ((ssize_t) radon_info->width); x++)
  {
    count = write(radon_info->file, &value, sizeof(*radon_info->cells));
    if (count != ((ssize_t) (sizeof(*radon_info->cells))))
      break;

  }

  if (x < ((ssize_t) radon_info->width))
    break;

}
