for (i = 0; i < ((ssize_t) length); i++)
  cube_info->cache[i] = -1;
