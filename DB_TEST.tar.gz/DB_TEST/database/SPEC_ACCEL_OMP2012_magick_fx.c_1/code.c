for (y = 0; y < ((ssize_t) random_image->rows); y++)
{
  const int id = GetOpenMPThreadId();
  MagickPixelPacket pixel;
  register IndexPacket * restrict indexes;
  register ssize_t x;
  register PixelPacket * restrict q;
  if (status == MagickFalse)
    continue;

  q = QueueCacheViewAuthenticPixels(random_view, 0, y, random_image->columns, 1, exception);
  if (q == ((PixelPacket *) 0))
  {
    status = MagickFalse;
    continue;
  }

  indexes = GetCacheViewAuthenticIndexQueue(random_view);
  pixel = zero;
  for (x = 0; x < ((ssize_t) random_image->columns); x++)
  {
    pixel.red = (MagickRealType) (QuantumRange * GetPseudoRandomValue(random_info[id]));
    pixel.green = pixel.red;
    pixel.blue = pixel.red;
    if (image->colorspace == CMYKColorspace)
      pixel.index = pixel.red;

    SetPixelPacket(random_image, &pixel, q, indexes + x);
    q++;
  }

  if (SyncCacheViewAuthenticPixels(random_view, exception) == MagickFalse)
    status = MagickFalse;

}

inline static int GetOpenMPThreadId(void)
{
  return 0;
}


inline static void SetPixelPacket(const Image *image, const MagickPixelPacket *pixel, PixelPacket *color, IndexPacket *index)
{
  SetPixelRed(color, ClampToQuantum(pixel->red));
  SetPixelGreen(color, ClampToQuantum(pixel->green));
  SetPixelBlue(color, ClampToQuantum(pixel->blue));
  SetPixelOpacity(color, ClampToQuantum(pixel->opacity));
  if ((image->colorspace == CMYKColorspace) || (image->storage_class == PseudoClass))
    SetPixelIndex(index, ClampToQuantum(pixel->index));

}

