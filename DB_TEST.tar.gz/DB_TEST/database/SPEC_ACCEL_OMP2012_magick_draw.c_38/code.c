for (i = 1; i <= (n - k); i++)
  r /= i;
