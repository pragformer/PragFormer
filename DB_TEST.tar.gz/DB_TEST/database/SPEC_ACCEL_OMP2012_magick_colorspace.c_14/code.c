for (i = 0; i <= ((ssize_t) MaxMap); i++)
{
  x_map[i].x = 0.4124564f * ((MagickRealType) i);
  y_map[i].x = 0.3575761f * ((MagickRealType) i);
  z_map[i].x = 0.1804375f * ((MagickRealType) i);
  x_map[i].y = 0.2126729f * ((MagickRealType) i);
  y_map[i].y = 0.7151522f * ((MagickRealType) i);
  z_map[i].y = 0.0721750f * ((MagickRealType) i);
  x_map[i].z = 0.0193339f * ((MagickRealType) i);
  y_map[i].z = 0.1191920f * ((MagickRealType) i);
  z_map[i].z = 0.9503041f * ((MagickRealType) i);
}
