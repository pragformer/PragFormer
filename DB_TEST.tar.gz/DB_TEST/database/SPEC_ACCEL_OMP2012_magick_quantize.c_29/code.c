for (; image != ((Image *) 0); image = GetNextImageInList(image))
{
  status = AssignImageColors(image, cube_info);
  if (status == MagickFalse)
    break;

}

static MagickBooleanType AssignImageColors(Image *image, CubeInfo *cube_info)
{
  ssize_t y;
  if ((cube_info->quantize_info->colorspace != UndefinedColorspace) && (cube_info->quantize_info->colorspace != CMYKColorspace))
    (void) TransformImageColorspace((Image *) image, cube_info->quantize_info->colorspace);
  else
    if (((image->colorspace != GRAYColorspace) && (IsRGBColorspace(image->colorspace) == MagickFalse)) && (image->colorspace != CMYColorspace))
    (void) TransformImageColorspace((Image *) image, RGBColorspace);


  if (AcquireImageColormap(image, cube_info->colors) == MagickFalse)
  {
    if (image != ((Image *) 0))
      (void) ThrowMagickException(&image->exception, GetMagickModule(), ResourceLimitError, ("MemoryAllocationFailed" == ((const char *) 0)) ? ("unknown") : ("MemoryAllocationFailed"), "`%s'", image->filename);

    return MagickFalse;
  }

  ;
  image->colors = 0;
  cube_info->transparent_pixels = 0;
  cube_info->transparent_index = -1;
  (void) DefineImageColormap(image, cube_info, cube_info->root);
  if ((cube_info->quantize_info->dither != MagickFalse) && (cube_info->quantize_info->dither_method != NoDitherMethod))
    (void) DitherImage(image, cube_info);
  else
  {
    CacheView *image_view;
    ExceptionInfo *exception;
    MagickBooleanType status;
    status = MagickTrue;
    exception = &image->exception;
    image_view = AcquireCacheView(image);
    #pragma omp parallel for schedule(dynamic,4) shared(status)
    for (y = 0; y < ((ssize_t) image->rows); y++)
    {
      CubeInfo cube;
      register IndexPacket * restrict indexes;
      register PixelPacket * restrict q;
      register ssize_t x;
      ssize_t count;
      if (status == MagickFalse)
        continue;

      q = GetCacheViewAuthenticPixels(image_view, 0, y, image->columns, 1, exception);
      if (q == ((PixelPacket *) 0))
      {
        status = MagickFalse;
        continue;
      }

      indexes = GetCacheViewAuthenticIndexQueue(image_view);
      cube = *cube_info;
      for (x = 0; x < ((ssize_t) image->columns); x += count)
      {
        RealPixelPacket pixel;
        register const NodeInfo *node_info;
        register ssize_t i;
        size_t id;
        size_t index;
        for (count = 1; (x + count) < ((ssize_t) image->columns); count++)
          if (IsSameColor(image, q, q + count) == MagickFalse)
          break;


        AssociateAlphaPixel(&cube, q, &pixel);
        node_info = cube.root;
        for (index = 8 - 1; ((ssize_t) index) > 0; index--)
        {
          id = ColorToNodeId(&cube, &pixel, index);
          if (node_info->child[id] == ((NodeInfo *) 0))
            break;

          node_info = node_info->child[id];
        }

        cube.target = pixel;
        cube.distance = (MagickRealType) (((4.0 * (QuantumRange + 1.0)) * (QuantumRange + 1.0)) + 1.0);
        ClosestColor(image, &cube, node_info->parent);
        index = cube.color_number;
        for (i = 0; i < ((ssize_t) count); i++)
        {
          if (image->storage_class == PseudoClass)
            SetPixelIndex((indexes + x) + i, index);

          if (cube.quantize_info->measure_error == MagickFalse)
          {
            SetPixelRGB(q, image->colormap + index);
            if (cube.associate_alpha != MagickFalse)
              SetPixelOpacity(q, image->colormap[index].opacity);

          }

          q++;
        }

      }

      if (SyncCacheViewAuthenticPixels(image_view, exception) == MagickFalse)
        status = MagickFalse;

      if (image->progress_monitor != ((MagickProgressMonitor) 0))
      {
        MagickBooleanType proceed;
        #pragma omp critical (MagickCore_AssignImageColors)
        proceed = SetImageProgress(image, "Assign/Image", (MagickOffsetType) y, image->rows);
        if (proceed == MagickFalse)
          status = MagickFalse;

      }

    }

    image_view = DestroyCacheView(image_view);
  }

  if (cube_info->quantize_info->measure_error != MagickFalse)
    (void) GetImageQuantizeError(image);

  if ((cube_info->quantize_info->number_colors == 2) && (cube_info->quantize_info->colorspace == GRAYColorspace))
  {
    Quantum intensity;
    register PixelPacket * restrict q;
    register ssize_t i;
    q = image->colormap;
    for (i = 0; i < ((ssize_t) image->colors); i++)
    {
      intensity = (Quantum) ((PixelIntensity(q) < (((MagickRealType) QuantumRange) / 2.0)) ? (0) : (QuantumRange));
      SetPixelRed(q, intensity);
      SetPixelGreen(q, intensity);
      SetPixelBlue(q, intensity);
      q++;
    }

  }

  (void) SyncImage(image);
  if ((cube_info->quantize_info->colorspace != UndefinedColorspace) && (cube_info->quantize_info->colorspace != CMYKColorspace))
    (void) TransformImageColorspace((Image *) image, RGBColorspace);

  return MagickTrue;
}

